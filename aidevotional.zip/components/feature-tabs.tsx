"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { BookOpen, Heart, Search, Loader2, Sparkles } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useAuth } from "@/components/auth/auth-provider"

const tabs = [
  {
    id: "search",
    label: "Bible Verse Search",
    title: "AI-Powered Bible Verse Search",
    description: "Search for Bible verses using natural language. Free for everyone - no sign-up required!",
    placeholder: "e.g., 'John 3:16', 'John3:16-18', 'Mark 1', 'Genesis', 'love'",
    icon: BookOpen,
    color: "amber",
    gradient: "from-amber-500 to-orange-500",
    emptyStateTitle: "Search the Bible with AI",
    emptyStateDescription:
      "Enter a verse reference, verse range, keyword, book, or book+chapter to find relevant verses",
  },
  {
    id: "concordance",
    label: "Bible Concordance",
    title: "Smart Bible Concordance",
    description: "Explore word meanings, cross-references, and biblical connections. Free for everyone!",
    placeholder: "e.g., 'love', 'faith', 'righteousness', 'covenant', 'grace', 'mercy'",
    icon: BookOpen,
    color: "blue",
    gradient: "from-blue-500 to-indigo-500",
    emptyStateTitle: "Explore Biblical Concepts",
    emptyStateDescription: "Search for any word or concept to discover its biblical meaning and connections",
  },
  {
    id: "devotional",
    label: "Devotional Outline",
    title: "AI Devotional Generator",
    description: "Generate personalized devotional outlines and study guides. Free for everyone!",
    placeholder: "e.g., 'dealing with anxiety', 'growing in faith', 'finding purpose'",
    icon: Heart,
    color: "green",
    gradient: "from-green-500 to-emerald-500",
    emptyStateTitle: "Create Personal Devotionals",
    emptyStateDescription: "Generate structured devotional studies with reflective questions and applications",
  },
]

export default function FeatureTabs() {
  const [activeTab, setActiveTab] = useState("search")
  const [searchQuery, setSearchQuery] = useState("")
  const [loading, setLoading] = useState(false)
  const [results, setResults] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)
  const { user } = useAuth()

  const currentTab = tabs.find((tab) => tab.id === activeTab) || tabs[0]
  const IconComponent = currentTab.icon

  const handleSearch = async () => {
    if (!searchQuery.trim()) return

    console.log(`🔍 Searching for: "${searchQuery}"`)

    // Reset state
    setLoading(true)
    setError(null)
    setResults(null)

    try {
      let endpoint = ""
      let body = {}

      switch (activeTab) {
        case "search":
          endpoint = "/api/ai/search-verses"
          body = { query: searchQuery }
          break
        case "concordance":
          endpoint = "/api/ai/search-concordance"
          body = { word: searchQuery, searchId: `concordance_${Date.now()}` }
          break
        case "devotional":
          endpoint = "/api/ai/generate-devotional"
          body = { topic: searchQuery }
          break
      }

      console.log(`🎯 Using endpoint: ${endpoint} for tab: ${activeTab}`)
      console.log(`📦 Request body:`, body)

      const response = await fetch(endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(body),
      })

      const data = await response.json()
      console.log(`📥 Received data:`, data)

      if (!response.ok) {
        throw new Error(data.error || "Search failed")
      }

      setResults(data)
    } catch (err) {
      console.error("Search error:", err)
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setLoading(false)
    }
  }

  const renderResults = () => {
    if (loading) {
      return (
        <div className="flex flex-col items-center justify-center py-16 px-4">
          <div className="relative">
            <div className="w-16 h-16 border-4 border-gray-200 border-t-amber-500 rounded-full animate-spin"></div>
            <Sparkles className="w-6 h-6 text-amber-500 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2" />
          </div>
          <p className="mt-4 text-lg font-medium text-gray-600">Searching the scriptures...</p>
          <p className="text-sm text-gray-500">AI is analyzing your request</p>
        </div>
      )
    }

    if (error) {
      return (
        <div className="text-center py-12">
          <div className="bg-red-50 border border-red-200 rounded-xl p-6 max-w-md mx-auto">
            <div className="text-red-600 font-medium mb-2">Search Error</div>
            <p className="text-red-700 text-sm">{error}</p>
          </div>
        </div>
      )
    }

    if (!results) {
      return null
    }

    if (activeTab === "search") {
      if (results.verses && results.verses.length > 0) {
        return (
          <div className="space-y-6">
            <div className="bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 rounded-xl p-4">
              <div className="flex items-center gap-3 mb-2">
                <BookOpen className="w-5 h-5 text-amber-600" />
                <h3 className="font-semibold text-amber-800">Search Results</h3>
              </div>
              <p className="text-amber-700 text-sm">
                Found {results.verses.length} verses for "{searchQuery}"
              </p>
            </div>

            <div className="grid gap-4">
              {results.verses.map((verse: any, index: number) => (
                <Card key={index} className="border-l-4 border-l-amber-500 shadow-sm hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <h4 className="font-bold text-amber-700 mb-3 text-lg">{verse.reference}</h4>
                    <p className="text-gray-800 text-lg leading-relaxed italic">"{verse.text}"</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )
      } else {
        return (
          <div className="text-center py-12">
            <div className="bg-gray-50 rounded-xl p-8">
              <BookOpen className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">No verses found for "{searchQuery}"</p>
            </div>
          </div>
        )
      }
    }

    if (activeTab === "concordance") {
      return (
        <div className="space-y-6">
          {/* Header */}
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-xl p-4">
            <div className="flex items-center gap-3 mb-2">
              <BookOpen className="w-5 h-5 text-blue-600" />
              <h3 className="font-semibold text-blue-800">Biblical Concordance Study</h3>
            </div>
            <p className="text-blue-700 text-sm">
              Comprehensive study for "{searchQuery}" • {results.keyVerses?.length || 0} key verses found
            </p>
          </div>

          {/* Definition Section */}
          {results.definition && (
            <Card className="border-l-4 border-l-blue-500 shadow-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg text-blue-700 flex items-center gap-2">📚 Biblical Definition</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-700 leading-relaxed text-lg">{results.definition}</p>
              </CardContent>
            </Card>
          )}

          {/* Key Verses Section */}
          {results.keyVerses && results.keyVerses.length > 0 && (
            <Card className="border-l-4 border-l-amber-500 shadow-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg text-amber-700 flex items-center gap-2">📖 Key Verses</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {results.keyVerses.map((verse: any, index: number) => (
                  <div key={index} className="bg-amber-50 rounded-lg p-4 border border-amber-100">
                    <h4 className="font-bold text-amber-700 mb-2">{verse.reference}</h4>
                    <p className="text-slate-800 italic text-lg leading-relaxed mb-3">"{verse.text}"</p>
                    {verse.explanation && (
                      <p className="text-slate-600 text-sm bg-white rounded p-3 border-l-2 border-amber-300">
                        {verse.explanation}
                      </p>
                    )}
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {/* Themes Section */}
          {results.themes && results.themes.length > 0 && (
            <Card className="border-l-4 border-l-green-500 shadow-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg text-green-700 flex items-center gap-2">🎯 Major Themes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-2">
                  {results.themes.map((theme: string, index: number) => (
                    <div key={index} className="bg-green-50 rounded-lg p-3 border border-green-100">
                      <p className="text-green-800 font-medium">{theme}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Original Language Section */}
          {results.originalLanguage && (
            <Card className="border-l-4 border-l-purple-500 shadow-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg text-purple-700 flex items-center gap-2">🔤 Original Language</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="bg-purple-50 rounded-lg p-4 border border-purple-100">
                  <p className="text-slate-700 leading-relaxed">{results.originalLanguage}</p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Practical Application Section */}
          {results.practicalApplication && (
            <Card className="border-l-4 border-l-orange-500 shadow-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg text-orange-700 flex items-center gap-2">
                  🎯 Practical Application
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="bg-orange-50 rounded-lg p-4 border border-orange-100">
                  <p className="text-slate-700 leading-relaxed">{results.practicalApplication}</p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Fallback if no results */}
          {!results.definition && !results.keyVerses && !results.themes && (
            <Card>
              <CardContent className="p-8 text-center">
                <BookOpen className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">No concordance results found for "{searchQuery}"</p>
              </CardContent>
            </Card>
          )}
        </div>
      )
    }

    if (activeTab === "devotional") {
      return (
        <div className="space-y-6">
          {/* Header */}
          <div className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-xl p-4">
            <div className="flex items-center gap-3 mb-2">
              <Heart className="w-5 h-5 text-green-600" />
              <h3 className="font-semibold text-green-800">Devotional Study</h3>
            </div>
            <p className="text-green-700 text-sm">Personal devotional outline for "{searchQuery}"</p>
          </div>

          <Card className="border-l-4 border-l-green-500 shadow-lg">
            <CardContent className="p-8">
              <h3 className="text-3xl font-bold text-green-600 mb-6 text-center">{results.title}</h3>

              {/* Main Scripture Section */}
              <div className="mb-8 p-6 bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl border-l-4 border-green-500">
                <h4 className="font-bold mb-3 text-green-700 flex items-center gap-2 text-lg">📖 Main Scripture</h4>
                <p className="text-green-700 font-bold text-lg mb-2">{results.mainScripture?.reference}</p>
                <p className="italic text-slate-800 text-xl leading-relaxed">"{results.mainScripture?.text}"</p>
              </div>

              <div className="space-y-6">
                {/* Introduction */}
                {results.outline?.introduction && (
                  <div className="bg-blue-50 rounded-lg p-5 border border-blue-100">
                    <h4 className="font-bold mb-3 text-blue-700 flex items-center gap-2">📝 Introduction</h4>
                    <p className="text-slate-700 leading-relaxed">{results.outline.introduction}</p>
                  </div>
                )}

                {/* Key Points */}
                {results.outline?.scriptureStudy?.keyPoints?.map((point: any, index: number) => (
                  <div key={index} className="bg-amber-50 rounded-lg p-5 border border-amber-100">
                    <h4 className="font-bold mb-3 text-amber-700">{point.point}</h4>
                    <p className="text-slate-700 leading-relaxed">{point.explanation}</p>
                  </div>
                ))}

                {/* Reflection Questions */}
                {results.outline?.reflection?.questions && (
                  <div className="bg-purple-50 rounded-lg p-5 border border-purple-100">
                    <h4 className="font-bold mb-4 text-purple-700 flex items-center gap-2">🤔 Reflection Questions</h4>
                    <div className="space-y-3">
                      {results.outline.reflection.questions.map((question: string, index: number) => (
                        <div key={index} className="bg-white rounded p-3 border-l-2 border-purple-300">
                          <p className="text-slate-700">{question}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Practical Application */}
                {results.outline?.application?.practicalSteps && (
                  <div className="bg-orange-50 rounded-lg p-5 border border-orange-100">
                    <h4 className="font-bold mb-4 text-orange-700 flex items-center gap-2">🎯 Practical Application</h4>
                    <div className="space-y-3">
                      {results.outline.application.practicalSteps.map((step: string, index: number) => (
                        <div key={index} className="bg-white rounded p-3 border-l-2 border-orange-300">
                          <p className="text-slate-700">{step}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Prayer */}
                {results.outline?.application?.prayer && (
                  <div className="bg-indigo-50 rounded-lg p-5 border border-indigo-100">
                    <h4 className="font-bold mb-3 text-indigo-700 flex items-center gap-2">🙏 Prayer</h4>
                    <p className="text-slate-700 italic leading-relaxed text-lg">
                      {results.outline.application.prayer}
                    </p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      )
    }

    return null
  }

  return (
    <div className="bg-gradient-to-br from-gray-50 to-white rounded-2xl p-8 shadow-lg border border-gray-100">
      {/* Tab Navigation */}
      <div className="flex flex-wrap justify-center gap-2 mb-8">
        {tabs.map((tab) => {
          const TabIcon = tab.icon
          const isActive = activeTab === tab.id
          return (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id)
                setResults(null)
                setError(null)
                setSearchQuery("")
                setLoading(false)
              }}
              className={`group relative px-6 py-4 rounded-xl font-medium transition-all duration-300 ${
                isActive
                  ? `bg-gradient-to-r ${tab.gradient} text-white shadow-lg transform scale-105`
                  : "bg-white text-slate-600 hover:text-slate-800 hover:bg-gray-50 border border-gray-200 hover:border-gray-300 hover:shadow-md"
              }`}
            >
              <div className="flex items-center gap-3">
                <TabIcon className={`w-5 h-5 ${isActive ? "text-white" : `text-${tab.color}-600`}`} />
                <span className="font-semibold">{tab.label}</span>
              </div>
              {isActive && <div className="absolute inset-0 bg-white/20 rounded-xl animate-pulse"></div>}
            </button>
          )
        })}
      </div>

      {/* Active Tab Content */}
      <div className="text-center mb-8">
        <div className="flex items-center justify-center gap-4 mb-4">
          <div className={`p-3 rounded-full bg-gradient-to-r ${currentTab.gradient}`}>
            <IconComponent className="w-8 h-8 text-white" />
          </div>
          <h3 className="text-3xl font-bold text-slate-800">{currentTab.title}</h3>
        </div>
        <p className="text-slate-600 max-w-3xl mx-auto mb-8 text-lg">{currentTab.description}</p>

        {/* Search Input */}
        <div className="max-w-4xl mx-auto">
          <div className="relative group">
            <Input
              type="text"
              placeholder={currentTab.placeholder}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="h-14 text-lg pl-6 pr-32 rounded-xl border-2 border-gray-200 focus:border-amber-400 focus:ring-4 focus:ring-amber-100 transition-all duration-300 shadow-sm"
              onKeyPress={(e) => e.key === "Enter" && !loading && handleSearch()}
            />
            <Button
              onClick={handleSearch}
              className={`absolute right-2 top-2 h-10 px-6 bg-gradient-to-r ${currentTab.gradient} hover:shadow-lg transition-all duration-300 transform hover:scale-105`}
              disabled={loading}
            >
              {loading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <>
                  <Search className="w-5 h-5 mr-2" />
                  Search
                </>
              )}
            </Button>
          </div>
        </div>
      </div>

      {/* Results Area */}
      <div className="min-h-[300px]">
        {error && (
          <div className="text-center py-8">
            <div className="bg-red-50 border border-red-200 rounded-xl p-6 max-w-md mx-auto">
              <p className="text-red-600 font-medium">{error}</p>
            </div>
          </div>
        )}

        {results && !error && <div className="max-w-5xl mx-auto">{renderResults()}</div>}

        {!results && !error && !loading && (
          <div className="text-center py-16 border-2 border-dashed border-gray-200 rounded-xl bg-gradient-to-br from-gray-50 to-white">
            <div
              className={`p-4 rounded-full bg-gradient-to-r ${currentTab.gradient} w-20 h-20 mx-auto mb-6 flex items-center justify-center`}
            >
              <IconComponent className="w-10 h-10 text-white" />
            </div>
            <h4 className="text-2xl font-bold text-gray-700 mb-3">{currentTab.emptyStateTitle}</h4>
            <p className="text-gray-500 max-w-md mx-auto text-lg">{currentTab.emptyStateDescription}</p>
          </div>
        )}
      </div>
    </div>
  )
}
