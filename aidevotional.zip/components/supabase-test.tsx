"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle, XCircle, Loader2, AlertTriangle } from "lucide-react"
import { auth } from "@/lib/auth"

export function SupabaseTest() {
  const [testResults, setTestResults] = useState<any[]>([])
  const [isRunning, setIsRunning] = useState(false)

  const runTests = async () => {
    setIsRunning(true)
    setTestResults([])

    const results: any[] = []

    // Test 1: Environment Variables Check
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "https://wvnydnkmzkuviknnsfsq.supabase.co"
    const supabaseAnonKey =
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ||
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Ind2bnlkbmttemt1dmlrbm5zZnNxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDgzODUwMTYsImV4cCI6MjA2Mzk2MTAxNn0.f_h8W445VJJNIsz0lFvwZXoqhNd0Bcre2DNc_VSeSh0"

    results.push({
      name: "Environment Variables",
      status: supabaseUrl && supabaseAnonKey ? "success" : "error",
      message:
        supabaseUrl && supabaseAnonKey
          ? `URL: ${supabaseUrl.substring(0, 30)}... | Key: ${supabaseAnonKey.substring(0, 20)}...`
          : "Missing Supabase environment variables",
    })

    // Test 2: URL Format Validation
    try {
      new URL(supabaseUrl)
      results.push({
        name: "URL Format",
        status: "success",
        message: "Supabase URL format is valid",
      })
    } catch (error) {
      results.push({
        name: "URL Format",
        status: "error",
        message: `Invalid URL format: ${supabaseUrl}`,
      })
    }

    // Test 3: Supabase Connection
    try {
      const connectionTest = await auth.testConnection()
      results.push({
        name: "Supabase Connection",
        status: connectionTest ? "success" : "error",
        message: connectionTest ? "Successfully connected to Supabase" : "Failed to connect to Supabase",
      })
    } catch (error) {
      results.push({
        name: "Supabase Connection",
        status: "error",
        message: `Connection failed: ${error}`,
      })
    }

    // Test 4: Auth Service - handle missing session gracefully
    try {
      const currentUser = await auth.getCurrentUser()
      results.push({
        name: "Auth Service",
        status: "success",
        message: currentUser ? `Current user: ${currentUser.email}` : "Auth service working (no user signed in)",
      })
    } catch (error) {
      results.push({
        name: "Auth Service",
        status: "warning",
        message: "Auth service accessible but no session found (normal when not signed in)",
      })
    }

    setTestResults(results)
    setIsRunning(false)
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "success":
        return <CheckCircle className="w-5 h-5 text-green-500" />
      case "error":
        return <XCircle className="w-5 h-5 text-red-500" />
      case "warning":
        return <AlertTriangle className="w-5 h-5 text-yellow-500" />
      default:
        return <Loader2 className="w-5 h-5 text-blue-500 animate-spin" />
    }
  }

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>🔧 Supabase Connection Test</CardTitle>
        <p className="text-sm text-gray-600">Test your Supabase configuration and connection</p>
      </CardHeader>
      <CardContent className="space-y-4">
        <Button onClick={runTests} disabled={isRunning} className="w-full">
          {isRunning ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Running Tests...
            </>
          ) : (
            "Test Supabase Connection"
          )}
        </Button>

        {testResults.length > 0 && (
          <div className="space-y-2">
            <h4 className="font-semibold">Test Results:</h4>
            {testResults.map((test, index) => (
              <div key={index} className="flex items-center gap-3 p-3 border rounded-lg">
                {getStatusIcon(test.status)}
                <div className="flex-1">
                  <div className="font-medium">{test.name}</div>
                  <div className="text-sm text-gray-600">{test.message}</div>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <h4 className="font-semibold text-green-800 mb-2">✅ Status: Ready for Testing</h4>
          <div className="text-sm text-green-700">
            <p>Your Supabase configuration looks good! You can now:</p>
            <ul className="mt-2 space-y-1">
              <li>• Try signing up for a new account</li>
              <li>• Test the sign-in functionality</li>
              <li>• Use all the free Bible study features</li>
            </ul>
          </div>
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <h4 className="font-semibold text-blue-800 mb-2">Current Configuration:</h4>
          <div className="text-sm space-y-1">
            <div>
              <strong>Supabase URL:</strong>{" "}
              {process.env.NEXT_PUBLIC_SUPABASE_URL || "https://wvnydnkmzkuviknnsfsq.supabase.co"}
            </div>
            <div>
              <strong>Anon Key:</strong>{" "}
              {(
                process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ||
                "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Ind2bnlkbmttemt1dmlrbm5zZnNxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDgzODUwMTYsImV4cCI6MjA2Mzk2MTAxNn0.f_h8W445VJJNIsz0lFvwZXoqhNd0Bcre2DNc_VSeSh0"
              ).substring(0, 20)}
              ...
            </div>
            <div className="mt-2 text-xs text-blue-600">Using fallback values from previous configuration</div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
