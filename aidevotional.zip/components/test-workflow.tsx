"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle, XCircle, Loader2 } from "lucide-react"
import { useAuth } from "@/components/auth/auth-provider"

interface TestResult {
  name: string
  status: "pending" | "success" | "error"
  message: string
}

export function TestWorkflow() {
  const [tests, setTests] = useState<TestResult[]>([])
  const [isRunning, setIsRunning] = useState(false)
  const { user } = useAuth()

  const updateTest = (name: string, status: "success" | "error", message: string) => {
    setTests((prev) => {
      const existing = prev.find((t) => t.name === name)
      if (existing) {
        existing.status = status
        existing.message = message
        return [...prev]
      }
      return [...prev, { name, status, message }]
    })
  }

  const runTests = async () => {
    setIsRunning(true)
    setTests([])

    // Test 1: Free Bible Search
    try {
      updateTest("Free Bible Search", "pending", "Testing...")
      const response = await fetch("/api/ai/search-verses", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: "John 3:16" }),
      })
      const data = await response.json()

      if (response.ok && data.verses?.length > 0) {
        updateTest("Free Bible Search", "success", `Found ${data.verses.length} verses`)
      } else {
        updateTest("Free Bible Search", "error", data.error || "No verses found")
      }
    } catch (error) {
      updateTest("Free Bible Search", "error", `Error: ${error}`)
    }

    // Test 2: Concordance Search
    try {
      updateTest("Concordance Search", "pending", "Testing...")
      const response = await fetch("/api/ai/search-concordance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ word: "love" }),
      })
      const data = await response.json()

      if (response.ok && data.keyVerses?.length > 0) {
        updateTest("Concordance Search", "success", `Found ${data.keyVerses.length} related verses`)
      } else {
        updateTest("Concordance Search", "error", data.error || "No verses found")
      }
    } catch (error) {
      updateTest("Concordance Search", "error", `Error: ${error}`)
    }

    // Test 3: Devotional Generation
    try {
      updateTest("Devotional Generation", "pending", "Testing...")
      const response = await fetch("/api/ai/generate-devotional", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ topic: "faith" }),
      })
      const data = await response.json()

      if (response.ok && data.title) {
        updateTest("Devotional Generation", "success", `Generated: "${data.title}"`)
      } else {
        updateTest("Devotional Generation", "error", data.error || "Failed to generate")
      }
    } catch (error) {
      updateTest("Devotional Generation", "error", `Error: ${error}`)
    }

    // Test 4: Authentication Status
    if (user) {
      updateTest("Authentication", "success", `Signed in as: ${user.email}`)

      // Test 5: Stripe Checkout (only if authenticated)
      try {
        updateTest("Stripe Checkout", "pending", "Testing...")
        const response = await fetch("/api/stripe/checkout", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
        })
        const data = await response.json()

        if (response.ok && data.url) {
          updateTest("Stripe Checkout", "success", "Checkout URL generated successfully")
        } else {
          updateTest("Stripe Checkout", "error", data.error || "Failed to create checkout")
        }
      } catch (error) {
        updateTest("Stripe Checkout", "error", `Error: ${error}`)
      }

      // Test 6: Stripe Portal (only if authenticated)
      try {
        updateTest("Stripe Portal", "pending", "Testing...")
        const response = await fetch("/api/stripe/portal", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
        })
        const data = await response.json()

        if (response.ok && data.url) {
          updateTest("Stripe Portal", "success", "Portal URL generated successfully")
        } else {
          updateTest("Stripe Portal", "error", data.error || "Failed to create portal session")
        }
      } catch (error) {
        updateTest("Stripe Portal", "error", `Error: ${error}`)
      }
    } else {
      updateTest("Authentication", "error", "Not signed in - sign in to test premium features")
    }

    setIsRunning(false)
  }

  const getStatusIcon = (status: TestResult["status"]) => {
    switch (status) {
      case "success":
        return <CheckCircle className="w-5 h-5 text-green-500" />
      case "error":
        return <XCircle className="w-5 h-5 text-red-500" />
      case "pending":
        return <Loader2 className="w-5 h-5 text-blue-500 animate-spin" />
    }
  }

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>🧪 Workflow Test Suite</CardTitle>
        <p className="text-sm text-gray-600">Test the complete workflow from app → Stripe → Supabase → app</p>
      </CardHeader>
      <CardContent className="space-y-4">
        <Button onClick={runTests} disabled={isRunning} className="w-full">
          {isRunning ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Running Tests...
            </>
          ) : (
            "Run All Tests"
          )}
        </Button>

        {tests.length > 0 && (
          <div className="space-y-2">
            <h4 className="font-semibold">Test Results:</h4>
            {tests.map((test, index) => (
              <div key={index} className="flex items-center gap-3 p-3 border rounded-lg">
                {getStatusIcon(test.status)}
                <div className="flex-1">
                  <div className="font-medium">{test.name}</div>
                  <div className="text-sm text-gray-600">{test.message}</div>
                </div>
              </div>
            ))}
          </div>
        )}

        {!user && (
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <p className="text-yellow-800 text-sm">
              💡 <strong>Tip:</strong> Sign in to test premium features like Stripe integration
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
