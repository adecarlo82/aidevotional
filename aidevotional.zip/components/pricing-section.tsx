"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Check } from "lucide-react"
import { useRouter } from "next/navigation"
import Link from "next/link"

interface PricingSectionProps {
  currentPlan?: "free" | "premium"
}

export function PricingSection({ currentPlan = "free" }: PricingSectionProps) {
  const [loading, setLoading] = useState(false)
  const router = useRouter()

  const handleSubscribe = () => {
    // Scroll to the premium signup component
    document.getElementById("premium-signup")?.scrollIntoView({ behavior: "smooth" })
  }

  const handleManageSubscription = async () => {
    try {
      setLoading(true)
      const response = await fetch("/api/stripe/portal", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      })

      const data = await response.json()
      if (data.url) {
        router.push(data.url)
      } else {
        throw new Error("Failed to create portal session")
      }
    } catch (error) {
      console.error("Error managing subscription:", error)
      alert("Failed to open subscription management. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold text-slate-800 mb-4">Simple, Transparent Pricing</h2>
        <p className="text-xl text-slate-600 max-w-2xl mx-auto">
          Use our free features without an account, or upgrade to premium for advanced tools
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
        {/* Free Features */}
        <Card>
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">Free Features</CardTitle>
            <CardDescription>
              <span className="text-3xl font-bold">$0</span>
              <span className="text-slate-600">/month</span>
            </CardDescription>
          </CardHeader>

          <CardContent className="min-h-[280px]">
            <ul className="space-y-3">
              <li className="flex items-center gap-3">
                <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                <span className="text-slate-700">Unlimited Bible verse search</span>
              </li>
              <li className="flex items-center gap-3">
                <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                <span className="text-slate-700">Unlimited AI concordance</span>
              </li>
              <li className="flex items-center gap-3">
                <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                <span className="text-slate-700">Basic devotional outlines</span>
              </li>
              <li className="flex items-center gap-3">
                <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                <span className="text-slate-700">No account required</span>
              </li>
            </ul>
          </CardContent>

          <CardFooter>
            <Button className="w-full" variant="outline" asChild>
              <Link href="/#features">Use Free Features</Link>
            </Button>
          </CardFooter>
        </Card>

        {/* Premium Plan */}
        <Card className="border-amber-500 shadow-lg">
          <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
            <span className="bg-amber-500 text-white px-3 py-1 rounded-full text-sm font-medium">Premium</span>
          </div>
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">Premium Subscription</CardTitle>
            <CardDescription>
              <span className="text-3xl font-bold">$4.99</span>
              <span className="text-slate-600">/month</span>
            </CardDescription>
          </CardHeader>

          <CardContent className="min-h-[280px]">
            <ul className="space-y-3">
              <li className="flex items-center gap-3">
                <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                <span className="text-slate-700">Everything in Free</span>
              </li>
              <li className="flex items-center gap-3">
                <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                <span className="text-slate-700">Complete devotional generation</span>
              </li>
              <li className="flex items-center gap-3">
                <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                <span className="text-slate-700">Personal prayer lists</span>
              </li>
              <li className="flex items-center gap-3">
                <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                <span className="text-slate-700">Bible reading plans</span>
              </li>
              <li className="flex items-center gap-3">
                <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                <span className="text-slate-700">Save and export features</span>
              </li>
              <li className="flex items-center gap-3">
                <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                <span className="text-slate-700">Priority support</span>
              </li>
            </ul>
          </CardContent>

          <CardFooter>
            <Button className="w-full" onClick={handleSubscribe} disabled={loading}>
              Get Started - $4.99/month
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
