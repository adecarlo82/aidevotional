"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useAuth } from "@/components/auth/auth-provider"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2 } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

interface SubscriptionGuardProps {
  children: React.ReactNode
  feature: string
}

export function SubscriptionGuard({ children, feature }: SubscriptionGuardProps) {
  const { user, loading: authLoading } = useAuth()
  const [hasAccess, setHasAccess] = useState<boolean | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [retryCount, setRetryCount] = useState(0)
  const router = useRouter()

  const checkSubscription = async () => {
    if (!user) return

    try {
      setLoading(true)
      setError(null)
      console.log("Checking subscription for user:", user.email)

      const response = await fetch("/api/user/subscription")

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}))
        console.error("Subscription API error:", response.status, errorData)

        if (response.status === 500 && retryCount < 3) {
          // For 500 errors, retry a few times
          setRetryCount((prev) => prev + 1)
          setTimeout(checkSubscription, 1000) // Retry after 1 second
          return
        }

        throw new Error(`API error: ${response.status}`)
      }

      const data = await response.json()
      console.log("Subscription data:", data)

      // Special case for alex.decarlo82@yahoo.com - always grant access
      if (user.email === "alex.decarlo82@yahoo.com") {
        console.log("Special case: Granting access to alex.decarlo82@yahoo.com")
        setHasAccess(true)
        return
      }

      setHasAccess(data.hasActiveSubscription)
    } catch (err) {
      console.error("Error checking subscription:", err)
      setError(err instanceof Error ? err.message : "Failed to check subscription")

      // For alex.decarlo82@yahoo.com, grant access even on error
      if (user.email === "alex.decarlo82@yahoo.com") {
        console.log("Special case on error: Granting access to alex.decarlo82@yahoo.com")
        setHasAccess(true)
      } else {
        setHasAccess(false)
      }
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (user && !authLoading) {
      checkSubscription()
    } else if (!authLoading && !user) {
      setLoading(false)
    }
  }, [user, authLoading, retryCount])

  // If still loading auth or subscription status
  if (authLoading || (user && loading)) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto text-amber-600" />
          <p className="mt-2 text-slate-600">Checking subscription...</p>
        </div>
      </div>
    )
  }

  // If not logged in
  if (!user) {
    return (
      <Card className="max-w-md mx-auto my-8">
        <CardHeader>
          <CardTitle>Sign in required</CardTitle>
          <CardDescription>You need to sign in to access {feature}</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-slate-600">Please sign in or create an account to access this premium feature.</p>
        </CardContent>
        <CardFooter className="flex flex-col gap-2">
          <Button className="w-full" onClick={() => router.push("/")}>
            Sign In
          </Button>
        </CardFooter>
      </Card>
    )
  }

  // Special case for alex.decarlo82@yahoo.com - always grant access
  if (user.email === "alex.decarlo82@yahoo.com") {
    return <>{children}</>
  }

  // If there was an error checking subscription
  if (error) {
    return (
      <Card className="max-w-md mx-auto my-8">
        <CardHeader>
          <CardTitle>Something went wrong</CardTitle>
          <CardDescription>We encountered an error checking your subscription</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-slate-600 mb-4">
            We're having trouble verifying your subscription status. Please try again later.
          </p>
          <Button onClick={checkSubscription} className="w-full">
            Try Again
          </Button>
        </CardContent>
      </Card>
    )
  }

  // If no subscription
  if (!hasAccess) {
    return (
      <Card className="max-w-md mx-auto my-8">
        <CardHeader>
          <CardTitle>Premium Feature</CardTitle>
          <CardDescription>{feature} is a premium feature</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-slate-600 mb-4">
            Upgrade to our Premium plan for just $4.99/month to access this and other premium features.
          </p>
        </CardContent>
        <CardFooter className="flex flex-col gap-2">
          <Button asChild className="w-full">
            <Link href="/pricing">Upgrade to Premium</Link>
          </Button>
        </CardFooter>
      </Card>
    )
  }

  // If has access
  return <>{children}</>
}
