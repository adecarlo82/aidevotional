"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Check } from "lucide-react"
import { SUBSCRIPTION_PLANS, type SubscriptionPlan } from "@/lib/stripe"

interface PricingCardProps {
  plan: SubscriptionPlan
  isCurrentPlan?: boolean
  onSelectPlan: (plan: SubscriptionPlan) => void
  loading?: boolean
}

export function PricingCard({ plan, isCurrentPlan, onSelectPlan, loading }: PricingCardProps) {
  const planConfig = SUBSCRIPTION_PLANS[plan]

  return (
    <Card className={`relative ${plan === "premium" ? "border-amber-500 shadow-lg" : ""}`}>
      {plan === "premium" && (
        <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
          <span className="bg-amber-500 text-white px-3 py-1 rounded-full text-sm font-medium">Most Popular</span>
        </div>
      )}

      <CardHeader className="text-center">
        <CardTitle className="text-2xl">{planConfig.name}</CardTitle>
        <CardDescription>
          <span className="text-3xl font-bold">${planConfig.price}</span>
          {planConfig.price > 0 && <span className="text-slate-600">/month</span>}
        </CardDescription>
      </CardHeader>

      <CardContent>
        <ul className="space-y-3">
          {planConfig.features.map((feature, index) => (
            <li key={index} className="flex items-center gap-3">
              <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
              <span className="text-slate-700">{feature}</span>
            </li>
          ))}
        </ul>
      </CardContent>

      <CardFooter>
        <Button
          className="w-full"
          variant={isCurrentPlan ? "outline" : plan === "premium" ? "default" : "outline"}
          onClick={() => onSelectPlan(plan)}
          disabled={isCurrentPlan || loading}
        >
          {isCurrentPlan ? "Current Plan" : loading ? "Loading..." : `Choose ${planConfig.name}`}
        </Button>
      </CardFooter>
    </Card>
  )
}
