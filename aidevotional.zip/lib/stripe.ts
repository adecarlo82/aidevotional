import Stripe from "stripe"

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error("STRIPE_SECRET_KEY is not set")
}

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2024-06-20",
})

// Subscription plans configuration
export const SUBSCRIPTION_PLANS = {
  free: {
    name: "Free",
    price: 0,
    features: ["Basic Bible search", "Limited AI devotionals (5/month)", "Basic concordance"],
    limits: {
      devotionals: 5,
      searches: 50,
    },
  },
  premium: {
    name: "Premium",
    price: 4.99, // Updated from 9.99 to 4.99
    priceId: process.env.STRIPE_PREMIUM_PRICE_ID,
    features: [
      "Unlimited Bible search",
      "Unlimited AI devotionals",
      "Advanced concordance",
      "Save devotionals",
      "Search history",
      "Export features",
      "Priority support",
      "Custom Bible versions",
    ],
    limits: {
      devotionals: -1, // unlimited
      searches: -1, // unlimited
    },
  },
}

export type SubscriptionPlan = keyof typeof SUBSCRIPTION_PLANS
