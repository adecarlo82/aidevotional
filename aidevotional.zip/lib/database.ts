import { supabase } from "./supabase"
import type { UserProfile, SavedSearch, SavedDevotional } from "./supabase"

export const database = {
  // User Profile operations
  async createUserProfile(userId: string, data: Partial<UserProfile>) {
    const { data: profile, error } = await supabase
      .from("user_profiles")
      .insert({
        user_id: userId,
        ...data,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })
      .select()
      .single()

    if (error) throw error
    return profile
  },

  async getUserProfile(userId: string) {
    const { data, error } = await supabase.from("user_profiles").select("*").eq("user_id", userId).single()

    if (error && error.code !== "PGRST116") throw error
    return data
  },

  async updateUserProfile(userId: string, updates: Partial<UserProfile>) {
    const { data, error } = await supabase
      .from("user_profiles")
      .update({
        ...updates,
        updated_at: new Date().toISOString(),
      })
      .eq("user_id", userId)
      .select()
      .single()

    if (error) throw error
    return data
  },

  // Saved Search operations
  async saveSearch(userId: string, searchData: Omit<SavedSearch, "id" | "user_id" | "created_at">) {
    const { data, error } = await supabase
      .from("saved_searches")
      .insert({
        user_id: userId,
        ...searchData,
        created_at: new Date().toISOString(),
      })
      .select()
      .single()

    if (error) throw error
    return data
  },

  async getUserSearches(userId: string, searchType?: string) {
    let query = supabase
      .from("saved_searches")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })

    if (searchType) {
      query = query.eq("search_type", searchType)
    }

    const { data, error } = await query
    if (error) throw error
    return data
  },

  // Saved Devotional operations
  async saveDevotional(
    userId: string,
    devotionalData: Omit<SavedDevotional, "id" | "user_id" | "created_at" | "updated_at">,
  ) {
    const { data, error } = await supabase
      .from("saved_devotionals")
      .insert({
        user_id: userId,
        ...devotionalData,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })
      .select()
      .single()

    if (error) throw error
    return data
  },

  async getUserDevotionals(userId: string) {
    const { data, error } = await supabase
      .from("saved_devotionals")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })

    if (error) throw error
    return data
  },

  async deleteDevotional(userId: string, devotionalId: string) {
    const { error } = await supabase.from("saved_devotionals").delete().eq("id", devotionalId).eq("user_id", userId)

    if (error) throw error
  },
}
