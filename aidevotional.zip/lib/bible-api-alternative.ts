// Alternative Bible API using bible-api.com (free and reliable)
interface BibleVerse {
  reference: string
  text: string
  id?: string
}

export const alternativeBibleAPI = {
  // Test connection
  async testConnection(): Promise<{ success: boolean; details: string; data?: any }> {
    try {
      console.log("🔍 Testing Bible-API.com connection...")

      const response = await fetch("https://bible-api.com/john 3:16")

      if (!response.ok) {
        return {
          success: false,
          details: `API returned ${response.status}`,
        }
      }

      const data = await response.json()
      console.log("✅ Bible-API.com test successful:", data)

      return {
        success: true,
        details: "Bible-API.com connection successful",
        data: data,
      }
    } catch (error) {
      console.error("❌ Bible-API.com test failed:", error)
      return {
        success: false,
        details: `Connection failed: ${error instanceof Error ? error.message : "Unknown error"}`,
      }
    }
  },

  // Get verse using bible-api.com
  async getVerse(book: string, chapter: number, verse: number): Promise<BibleVerse | null> {
    try {
      console.log(`📖 Fetching ${book} ${chapter}:${verse} from Bible-API.com...`)

      // Format: "john 3:16" or "1 corinthians 13:4"
      const reference = `${book} ${chapter}:${verse}`.toLowerCase()
      const url = `https://bible-api.com/${encodeURIComponent(reference)}`

      console.log(`📡 API Request URL: ${url}`)

      const response = await fetch(url)

      if (!response.ok) {
        console.log(`❌ API returned status ${response.status}`)
        return null
      }

      const data = await response.json()
      console.log(`📊 API Response:`, data)

      if (data && data.verses && Array.isArray(data.verses) && data.verses.length > 0) {
        const verseData = data.verses[0]

        if (verseData && verseData.text && verseData.text.trim().length > 5) {
          const result = {
            reference: `${book} ${chapter}:${verse}`,
            text: verseData.text.trim(),
            id: verseData.book_id || `${book}_${chapter}_${verse}`,
          }
          console.log(`✅ Successfully fetched verse:`, result)
          return result
        }
      }

      // Try alternative format if first attempt fails
      if (data && data.text && data.text.trim().length > 5) {
        const result = {
          reference: `${book} ${chapter}:${verse}`,
          text: data.text.trim(),
          id: data.reference || `${book}_${chapter}_${verse}`,
        }
        console.log(`✅ Successfully fetched verse (alternative format):`, result)
        return result
      }

      console.log(`❌ No valid verse text found for ${book} ${chapter}:${verse}`)
      return null
    } catch (error) {
      console.error(`❌ Error fetching verse ${book} ${chapter}:${verse}:`, error)
      return null
    }
  },

  // Parse verse reference
  parseVerseReference(reference: string): { book: string; chapter: number; verse: number } | null {
    console.log(`🔍 Parsing verse reference: "${reference}"`)

    const match = reference.match(/^(\d{0,2}\s*[a-zA-Z]+)\s*(\d+)\s*:\s*(\d+)$/i)

    if (match) {
      const [, book, chapter, verse] = match
      const result = {
        book: book.trim().replace(/(\d)([a-zA-Z])/, "$1 $2"),
        chapter: Number.parseInt(chapter),
        verse: Number.parseInt(verse),
      }
      console.log(`✅ Successfully parsed verse reference:`, result)
      return result
    }

    console.log(`❌ Could not parse as verse reference: "${reference}"`)
    return null
  },
}
