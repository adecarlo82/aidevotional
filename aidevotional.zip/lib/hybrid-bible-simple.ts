import { rapidApiVerse } from "./rapidapi-verse"
import { bibleAPI } from "./bible-api"

interface BibleVerse {
  reference: string
  text: string
  id?: string
}

interface SearchResult {
  verses: BibleVerse[]
  summary?: string
  source: string
  query: string
  timestamp: string
}

export const hybridBibleSimple = {
  // Enhanced verse reference detection and parsing
  parseVerseReference(query: string): { isVerse: boolean; references: string[] } {
    const cleanQuery = query.trim().replace(/\s+/g, " ")

    // Skip verse detection for single words (likely text searches)
    if (!cleanQuery.includes(" ") && !cleanQuery.includes(":") && !cleanQuery.includes("-")) {
      console.log(`📝 Single word "${cleanQuery}" - treating as text search, not verse reference`)
      return { isVerse: false, references: [] }
    }

    // Enhanced patterns for verse references
    const patterns = [
      // Single verse: "John 3:16", "1 John 2:3", "2 Corinthians 5:17"
      /^(\d?\s*[a-zA-Z]+(?:\s+[a-zA-Z]+)*)\s*(\d+)\s*:\s*(\d+)$/i,

      // Verse range: "John 3:16-18", "Mark 1:1-5", "1 John 2:3-7"
      /^(\d?\s*[a-zA-Z]+(?:\s+[a-zA-Z]+)*)\s*(\d+)\s*:\s*(\d+)\s*-\s*(\d+)$/i,

      // Chapter range: "John 3:16-4:2", "Mark 1:1-2:5"
      /^(\d?\s*[a-zA-Z]+(?:\s+[a-zA-Z]+)*)\s*(\d+)\s*:\s*(\d+)\s*-\s*(\d+)\s*:\s*(\d+)$/i,

      // Multiple verses: "John 3:16,17,18" or "John 3:16, 17, 18"
      /^(\d?\s*[a-zA-Z]+(?:\s+[a-zA-Z]+)*)\s*(\d+)\s*:\s*(\d+(?:\s*,\s*\d+)*)$/i,

      // Chapter only: "John 3", "1 John 2"
      /^(\d?\s*[a-zA-Z]+(?:\s+[a-zA-Z]+)*)\s*(\d+)$/i,

      // Book only: "John", "1 John", "2 Corinthians"
      /^(\d?\s*[a-zA-Z]+(?:\s+[a-zA-Z]+)*)$/i,
    ]

    for (const pattern of patterns) {
      const match = cleanQuery.match(pattern)
      if (match) {
        console.log(`📖 Matched verse pattern:`, match)
        return {
          isVerse: true,
          references: this.expandVerseReference(match, cleanQuery),
        }
      }
    }

    return { isVerse: false, references: [] }
  },

  // Expand verse references into individual verse strings
  expandVerseReference(match: RegExpMatchArray, originalQuery: string): string[] {
    const references: string[] = []

    try {
      if (match.length === 4) {
        // Single verse: John 3:16
        const [, book, chapter, verse] = match
        references.push(`${book.trim()} ${chapter}:${verse}`)
      } else if (match.length === 5) {
        // Verse range: John 3:16-18
        const [, book, chapter, startVerse, endVerse] = match
        const start = Number.parseInt(startVerse)
        const end = Number.parseInt(endVerse)

        for (let v = start; v <= end && v <= start + 20; v++) {
          // Limit to 20 verses max
          references.push(`${book.trim()} ${chapter}:${v}`)
        }
      } else if (match.length === 6) {
        // Chapter range: John 3:16-4:2
        const [, book, startChapter, startVerse, endChapter, endVerse] = match

        // For now, just get the first verse of the range
        references.push(`${book.trim()} ${startChapter}:${startVerse}`)
        references.push(`${book.trim()} ${endChapter}:${endVerse}`)
      } else if (match[3] && match[3].includes(",")) {
        // Multiple verses: John 3:16,17,18
        const [, book, chapter, versesStr] = match
        const verses = versesStr.split(",").map((v) => v.trim())

        verses.forEach((verse) => {
          if (verse && !isNaN(Number.parseInt(verse))) {
            references.push(`${book.trim()} ${chapter}:${verse}`)
          }
        })
      } else if (match.length === 3) {
        // Chapter only: John 3 (get first 5 verses)
        const [, book, chapter] = match
        for (let v = 1; v <= 5; v++) {
          references.push(`${book.trim()} ${chapter}:${v}`)
        }
      } else if (match.length === 2) {
        // Book only: John (get first chapter, first 5 verses)
        const [, book] = match
        for (let v = 1; v <= 5; v++) {
          references.push(`${book.trim()} 1:${v}`)
        }
      }
    } catch (error) {
      console.error("Error expanding verse reference:", error)
      // Fallback to original query
      references.push(originalQuery)
    }

    console.log(`📖 Expanded to ${references.length} references:`, references)
    return references
  },

  // Main search function with enhanced verse detection
  async searchVerses(query: string): Promise<SearchResult> {
    console.log(`🔍 HYBRID SEARCH for: "${query}"`)

    // Enhanced verse reference detection
    const { isVerse, references } = this.parseVerseReference(query)

    if (isVerse && references.length > 0) {
      console.log(`📖 Detected verse reference(s): ${references.length} verses`)
      return await this.getMultipleVerses(references, query)
    }

    // For text/topic searches, use the dedicated text search API
    try {
      console.log(`🔤 Using dedicated text search API for: "${query}"`)

      const response = await fetch("/api/ai/search-text", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ query }),
      })

      if (response.ok) {
        const textSearchResult = await response.json()
        console.log(`✅ Text search API success:`, textSearchResult)

        // Combine literal and thematic matches
        const allVerses = [...textSearchResult.literalMatches, ...textSearchResult.thematicMatches]

        return {
          verses: allVerses,
          summary: textSearchResult.summary,
          source: textSearchResult.source + " (text search)",
          query,
          timestamp: new Date().toISOString(),
        }
      }
    } catch (error) {
      console.error(`❌ Text search API failed for "${query}":`, error)
    }

    // Fallback to local database
    try {
      console.log(`💾 Using local database fallback for: "${query}"`)
      const localVerses = await bibleAPI.findVerses(query)

      return {
        verses: localVerses,
        summary: `Found ${localVerses.length} verses for "${query}" from local database`,
        source: "Local Bible Database (fallback)",
        query,
        timestamp: new Date().toISOString(),
      }
    } catch (error) {
      console.error(`❌ Local database also failed for "${query}":`, error)

      // Final fallback
      return {
        verses: [
          {
            reference: "Search Help",
            text: `No results found for "${query}". Try searching for specific verses like "John 3:16", verse ranges like "John 3:16-18", or topics like "love" or "faith".`,
            id: "help_message",
          },
        ],
        summary: "Search assistance",
        source: "Help system",
        query,
        timestamp: new Date().toISOString(),
      }
    }
  },

  // Get multiple verses (for ranges and multiple references)
  async getMultipleVerses(references: string[], originalQuery: string): Promise<SearchResult> {
    console.log(`📖 Getting ${references.length} verses for: "${originalQuery}"`)

    const verses: BibleVerse[] = []
    let successCount = 0
    let rapidApiUsed = false

    for (const reference of references) {
      try {
        // Try RapidAPI first
        const rapidApiVerseResult = await rapidApiVerse.getExactVerse(reference)
        if (rapidApiVerseResult) {
          verses.push(rapidApiVerseResult)
          successCount++
          rapidApiUsed = true
          console.log(`✅ RapidAPI found: ${rapidApiVerseResult.reference}`)
          continue
        }
      } catch (error) {
        console.error(`❌ RapidAPI failed for "${reference}":`, error)
      }

      // Fallback to local database
      try {
        const localVerse = await bibleAPI.getVerse(reference)
        if (localVerse) {
          verses.push(localVerse)
          successCount++
          console.log(`✅ Local database found: ${localVerse.reference}`)
        }
      } catch (error) {
        console.error(`❌ Local database failed for "${reference}":`, error)
      }
    }

    if (verses.length > 0) {
      const source = rapidApiUsed ? "RapidAPI Bible Service (exact verses)" : "Local Bible Database (fallback)"

      return {
        verses,
        summary: `Retrieved ${verses.length} verses for "${originalQuery}"`,
        source,
        query: originalQuery,
        timestamp: new Date().toISOString(),
      }
    }

    // No verses found
    return {
      verses: [
        {
          reference: "Verses Not Found",
          text: `Could not find verses for "${originalQuery}". Please check the reference format (e.g., "John 3:16", "John 3:16-18").`,
          id: "not_found",
        },
      ],
      summary: "Verses not found",
      source: "Error message",
      query: originalQuery,
      timestamp: new Date().toISOString(),
    }
  },

  // Get specific verse using our working RapidAPI implementation
  async getSpecificVerse(reference: string): Promise<SearchResult> {
    console.log(`📖 Getting specific verse: "${reference}"`)

    // Try RapidAPI first
    try {
      const rapidApiVerseResult = await rapidApiVerse.getExactVerse(reference)
      if (rapidApiVerseResult) {
        console.log(`✅ RapidAPI found verse: ${rapidApiVerseResult.reference}`)
        return {
          verses: [rapidApiVerseResult],
          summary: `Retrieved ${rapidApiVerseResult.reference} from RapidAPI`,
          source: "RapidAPI Bible Service (exact verse)",
          query: reference,
          timestamp: new Date().toISOString(),
        }
      }
    } catch (error) {
      console.error(`❌ RapidAPI getVerse failed for "${reference}":`, error)
    }

    // Fallback to local database
    try {
      const localVerse = await bibleAPI.getVerse(reference)
      if (localVerse) {
        console.log(`✅ Local database found verse: ${localVerse.reference}`)
        return {
          verses: [localVerse],
          summary: `Retrieved ${localVerse.reference} from local database`,
          source: "Local Bible Database (fallback)",
          query: reference,
          timestamp: new Date().toISOString(),
        }
      }
    } catch (error) {
      console.error(`❌ Local database getVerse failed for "${reference}":`, error)
    }

    // No verse found
    return {
      verses: [
        {
          reference: "Verse Not Found",
          text: `Could not find "${reference}". Please check the reference format (e.g., "John 3:16").`,
          id: "not_found",
        },
      ],
      summary: "Verse not found",
      source: "Error message",
      query: reference,
      timestamp: new Date().toISOString(),
    }
  },

  // Search using RapidAPI GetSearch endpoint
  async searchWithRapidAPI(query: string): Promise<SearchResult> {
    const RAPIDAPI_KEY = "4f9153d221msh9e9473de1ec4e29p1732b3jsna37f84ab53e1"
    const RAPIDAPI_HOST = "iq-bible.p.rapidapi.com"
    const BASE_URL = `https://${RAPIDAPI_HOST}`

    try {
      const url = `${BASE_URL}/GetSearch?query=${encodeURIComponent(query)}&versionId=kjv`
      console.log(`📡 RapidAPI search request: ${url}`)

      const response = await fetch(url, {
        method: "GET",
        headers: {
          "x-rapidapi-key": RAPIDAPI_KEY,
          "x-rapidapi-host": RAPIDAPI_HOST,
        },
      })

      if (!response.ok) {
        throw new Error(`RapidAPI search failed: ${response.status} ${response.statusText}`)
      }

      const data = await response.json()
      console.log(`📊 RapidAPI search raw response:`, data)
      console.log(`📊 Response type:`, typeof data, `Array:`, Array.isArray(data), `Length:`, data?.length)

      // Handle different response formats
      let searchResults = []

      if (Array.isArray(data)) {
        searchResults = data
      } else if (data && typeof data === "object" && data.results && Array.isArray(data.results)) {
        searchResults = data.results
      } else if (data && typeof data === "object" && data.verses && Array.isArray(data.verses)) {
        searchResults = data.verses
      } else {
        console.log(`⚠️ Unexpected response format for "${query}":`, data)
        throw new Error("Unexpected response format from RapidAPI")
      }

      console.log(`📊 Processed search results:`, searchResults.length, "items")

      if (searchResults.length > 0) {
        // Take first 10 results and format them
        const verses = searchResults.slice(0, 10).map((item: any, index: number) => {
          console.log(`📝 Processing item ${index}:`, item)

          return {
            reference: `${this.getBookName(item.b || item.book)} ${Number.parseInt(item.c || item.chapter || "1")}:${Number.parseInt(item.v || item.verse || "1")}`,
            text: item.t || item.text || "Text not available",
            id: item.id || `search_${index}`,
          }
        })

        console.log(`✅ Formatted ${verses.length} verses for "${query}"`)

        return {
          verses,
          summary: `Found ${verses.length} verses for "${query}" from RapidAPI search`,
          source: "RapidAPI Bible Service (search)",
          query,
          timestamp: new Date().toISOString(),
        }
      }

      console.log(`⚠️ No results in response for "${query}"`)
      throw new Error("No results from RapidAPI search")
    } catch (error) {
      console.error(`❌ RapidAPI search error for "${query}":`, error)
      throw error
    }
  },

  // Get book name from book ID
  getBookName(bookId: string | number): string {
    const bookIdStr = String(bookId)
    const books: Record<string, string> = {
      "1": "Genesis",
      "2": "Exodus",
      "3": "Leviticus",
      "4": "Numbers",
      "5": "Deuteronomy",
      "6": "Joshua",
      "7": "Judges",
      "8": "Ruth",
      "9": "1 Samuel",
      "10": "2 Samuel",
      "11": "1 Kings",
      "12": "2 Kings",
      "13": "1 Chronicles",
      "14": "2 Chronicles",
      "15": "Ezra",
      "16": "Nehemiah",
      "17": "Esther",
      "18": "Job",
      "19": "Psalms",
      "20": "Proverbs",
      "21": "Ecclesiastes",
      "22": "Song of Solomon",
      "23": "Isaiah",
      "24": "Jeremiah",
      "25": "Lamentations",
      "26": "Ezekiel",
      "27": "Daniel",
      "28": "Hosea",
      "29": "Joel",
      "30": "Amos",
      "31": "Obadiah",
      "32": "Jonah",
      "33": "Micah",
      "34": "Nahum",
      "35": "Habakkuk",
      "36": "Zephaniah",
      "37": "Haggai",
      "38": "Zechariah",
      "39": "Malachi",
      "40": "Matthew",
      "41": "Mark",
      "42": "Luke",
      "43": "John",
      "44": "Acts",
      "45": "Romans",
      "46": "1 Corinthians",
      "47": "2 Corinthians",
      "48": "Galatians",
      "49": "Ephesians",
      "50": "Philippians",
      "51": "Colossians",
      "52": "1 Thessalonians",
      "53": "2 Thessalonians",
      "54": "1 Timothy",
      "55": "2 Timothy",
      "56": "Titus",
      "57": "Philemon",
      "58": "Hebrews",
      "59": "James",
      "60": "1 Peter",
      "61": "2 Peter",
      "62": "1 John",
      "63": "2 John",
      "64": "3 John",
      "65": "Jude",
      "66": "Revelation",
    }
    return books[bookIdStr] || `Book ${bookIdStr}`
  },

  // Get random verse using RapidAPI
  async getRandomVerse(): Promise<BibleVerse> {
    const RAPIDAPI_KEY = "4f9153d221msh9e9473de1ec4e29p1732b3jsna37f84ab53e1"
    const RAPIDAPI_HOST = "iq-bible.p.rapidapi.com"
    const BASE_URL = `https://${RAPIDAPI_HOST}`

    try {
      const url = `${BASE_URL}/GetRandomVerse?versionId=kjv`
      console.log(`📡 RapidAPI random verse request: ${url}`)

      const response = await fetch(url, {
        method: "GET",
        headers: {
          "x-rapidapi-key": RAPIDAPI_KEY,
          "x-rapidapi-host": RAPIDAPI_HOST,
        },
      })

      if (!response.ok) {
        throw new Error(`RapidAPI random verse failed: ${response.status}`)
      }

      const data = await response.json()
      console.log(`✅ RapidAPI random verse response:`, data)

      if (data && data.length > 0) {
        const item = data[0]
        return {
          reference: `${this.getBookName(item.b)} ${Number.parseInt(item.c)}:${Number.parseInt(item.v)}`,
          text: item.t,
          id: item.id,
        }
      }

      throw new Error("No random verse from RapidAPI")
    } catch (error) {
      console.error(`❌ RapidAPI random verse error:`, error)
      // Fallback to local database
      return await bibleAPI.getRandomVerse()
    }
  },

  // Test both systems
  async testConnection(): Promise<{ rapidApi: any; local: any }> {
    console.log(`🧪 Testing both systems`)

    // Test RapidAPI with a simple verse
    let rapidApiTest
    try {
      const testVerse = await rapidApiVerse.getExactVerse("John 3:16")
      rapidApiTest = {
        success: !!testVerse,
        details: testVerse ? `Found: ${testVerse.reference}` : "No verse returned",
        verse: testVerse,
      }
    } catch (error) {
      rapidApiTest = {
        success: false,
        details: `Error: ${error instanceof Error ? error.message : "Unknown error"}`,
      }
    }

    const localTest = {
      success: true,
      details: "Local database available",
    }

    return {
      rapidApi: rapidApiTest,
      local: localTest,
    }
  },
}
