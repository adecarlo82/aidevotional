// Fixed RapidAPI Bible service with correct endpoints
const RAPIDAPI_KEY = "4f9153d221msh9e9473de1ec4e29p1732b3jsna37f84ab53e1"
const RAPIDAPI_HOST = "iq-bible.p.rapidapi.com"
const BASE_URL = "https://iq-bible.p.rapidapi.com"

interface BibleVerse {
  reference: string
  text: string
  id?: string
}

interface SearchResult {
  verses: BibleVerse[]
  summary?: string
  source: string
  query: string
  timestamp: string
}

export const rapidApiBibleFixed = {
  // Test API connection with correct endpoint
  async testConnection(): Promise<{ success: boolean; details: string; data?: any }> {
    try {
      console.log("🔍 Testing RapidAPI Bible connection...")

      // Try the books endpoint first
      const response = await fetch(`${BASE_URL}/GetBooks?language=english`, {
        method: "GET",
        headers: {
          "X-RapidAPI-Key": RAPIDAPI_KEY,
          "X-RapidAPI-Host": RAPIDAPI_HOST,
        },
      })

      if (!response.ok) {
        console.log(`❌ GetBooks failed: ${response.status}`)

        // Try alternative endpoint
        const altResponse = await fetch(`${BASE_URL}/books`, {
          method: "GET",
          headers: {
            "X-RapidAPI-Key": RAPIDAPI_KEY,
            "X-RapidAPI-Host": RAPIDAPI_HOST,
          },
        })

        if (!altResponse.ok) {
          return {
            success: false,
            details: `Both endpoints failed. Primary: ${response.status}, Alt: ${altResponse.status}`,
          }
        }

        const altData = await altResponse.json()
        return {
          success: true,
          details: "Alternative endpoint working",
          data: Array.isArray(altData) ? altData.slice(0, 5) : altData,
        }
      }

      const data = await response.json()
      console.log("✅ RapidAPI connection successful:", data)

      return {
        success: true,
        details: "RapidAPI connection successful",
        data: Array.isArray(data) ? data.slice(0, 5) : data,
      }
    } catch (error) {
      console.error("❌ RapidAPI connection test failed:", error)
      return {
        success: false,
        details: `Connection failed: ${error instanceof Error ? error.message : "Unknown error"}`,
      }
    }
  },

  // Enhanced search function with multiple endpoint strategies
  async searchVerses(query: string, version = "1"): Promise<SearchResult> {
    console.log(`🔍 RapidAPI searching for: "${query}"`)

    try {
      // Strategy 1: Try exact verse reference search
      const verseMatch = this.parseVerseReference(query)
      if (verseMatch) {
        console.log(`📖 Detected verse reference:`, verseMatch)
        const verse = await this.getSpecificVerse(verseMatch.book, verseMatch.chapter, verseMatch.verse, version)
        if (verse) {
          return {
            verses: [verse],
            summary: `Found the specific verse: ${verse.reference}`,
            source: "RapidAPI - Specific Verse",
            query: query,
            timestamp: new Date().toISOString(),
          }
        }
      }

      // Strategy 2: Try different search endpoints
      console.log(`🔍 Trying multiple search strategies for: "${query}"`)

      // Try search endpoint variations
      const searchEndpoints = [
        `${BASE_URL}/search?query=${encodeURIComponent(query)}`,
        `${BASE_URL}/SearchVerses?query=${encodeURIComponent(query)}&versionId=${version}`,
        `${BASE_URL}/verses/search?q=${encodeURIComponent(query)}`,
        `${BASE_URL}/search?q=${encodeURIComponent(query)}&version=${version}`,
      ]

      for (const endpoint of searchEndpoints) {
        try {
          console.log(`📡 Trying endpoint: ${endpoint}`)

          const response = await fetch(endpoint, {
            method: "GET",
            headers: {
              "X-RapidAPI-Key": RAPIDAPI_KEY,
              "X-RapidAPI-Host": RAPIDAPI_HOST,
            },
          })

          if (response.ok) {
            const data = await response.json()
            console.log(`✅ Endpoint worked: ${endpoint}`, data)

            const verses = this.parseSearchResponse(data, query)
            if (verses.length > 0) {
              return {
                verses: verses,
                summary: `Found ${verses.length} verses related to "${query}"`,
                source: "RapidAPI - Search",
                query: query,
                timestamp: new Date().toISOString(),
              }
            }
          } else {
            console.log(`❌ Endpoint failed: ${endpoint} - ${response.status}`)
          }
        } catch (endpointError) {
          console.log(`❌ Endpoint error: ${endpoint}`, endpointError)
        }
      }

      // Strategy 3: Try chapter search if it's a book + chapter
      const chapterMatch = this.parseChapterReference(query)
      if (chapterMatch) {
        console.log(`📖 Detected chapter reference:`, chapterMatch)
        const chapterVerses = await this.getChapterVerses(chapterMatch.book, chapterMatch.chapter, version)
        if (chapterVerses.length > 0) {
          return {
            verses: chapterVerses.slice(0, 5), // Limit to first 5 verses
            summary: `Found ${chapterVerses.length} verses from ${chapterMatch.book} ${chapterMatch.chapter}`,
            source: "RapidAPI - Chapter",
            query: query,
            timestamp: new Date().toISOString(),
          }
        }
      }

      // If all strategies fail, return empty result
      console.log(`❌ No results found for: "${query}"`)
      return {
        verses: [],
        summary: `No verses found for "${query}" in RapidAPI`,
        source: "RapidAPI - No Results",
        query: query,
        timestamp: new Date().toISOString(),
      }
    } catch (error) {
      console.error(`❌ RapidAPI search error for "${query}":`, error)
      throw error // Let the hybrid system handle the fallback
    }
  },

  // Parse different response formats
  parseSearchResponse(data: any, query: string): BibleVerse[] {
    console.log(`📊 Parsing search response:`, data)

    if (!data) return []

    // Handle array response
    if (Array.isArray(data)) {
      return data
        .filter((item) => item && (item.text || item.t || item.verse))
        .map((item) => ({
          reference: this.formatReference(item),
          text: (item.text || item.t || item.verse || "").trim(),
          id: `rapidapi_${item.id || Date.now()}`,
        }))
        .filter((verse) => verse.text.length > 5)
    }

    // Handle object with verses array
    if (data.verses && Array.isArray(data.verses)) {
      return this.parseSearchResponse(data.verses, query)
    }

    // Handle object with results array
    if (data.results && Array.isArray(data.results)) {
      return this.parseSearchResponse(data.results, query)
    }

    // Handle single verse object
    if (data.text || data.t) {
      return [
        {
          reference: this.formatReference(data),
          text: (data.text || data.t || "").trim(),
          id: `rapidapi_${data.id || Date.now()}`,
        },
      ]
    }

    console.log(`⚠️ Unknown response format:`, data)
    return []
  },

  // Get specific verse with multiple endpoint attempts
  async getSpecificVerse(book: string, chapter: number, verse: number, version = "1"): Promise<BibleVerse | null> {
    try {
      console.log(`📖 Getting specific verse: ${book} ${chapter}:${verse}`)

      const bookId = this.getBookId(book)

      // Try multiple endpoint formats
      const verseEndpoints = [
        `${BASE_URL}/GetVerse?bookId=${bookId}&chapterId=${chapter}&verseId=${verse}&versionId=${version}`,
        `${BASE_URL}/verse?book=${bookId}&chapter=${chapter}&verse=${verse}&version=${version}`,
        `${BASE_URL}/verses/${bookId}/${chapter}/${verse}?version=${version}`,
        `${BASE_URL}/bible/${version}/${bookId}/${chapter}/${verse}`,
      ]

      for (const endpoint of verseEndpoints) {
        try {
          console.log(`📡 Trying verse endpoint: ${endpoint}`)

          const response = await fetch(endpoint, {
            method: "GET",
            headers: {
              "X-RapidAPI-Key": RAPIDAPI_KEY,
              "X-RapidAPI-Host": RAPIDAPI_HOST,
            },
          })

          if (response.ok) {
            const data = await response.json()
            console.log(`✅ Verse endpoint worked: ${endpoint}`, data)

            if (data && (data.text || data.t)) {
              return {
                reference: `${book} ${chapter}:${verse}`,
                text: (data.text || data.t).trim(),
                id: `rapidapi_${data.id || `${book}_${chapter}_${verse}`}`,
              }
            }
          } else {
            console.log(`❌ Verse endpoint failed: ${endpoint} - ${response.status}`)
          }
        } catch (endpointError) {
          console.log(`❌ Verse endpoint error: ${endpoint}`, endpointError)
        }
      }

      console.log(`❌ Could not find verse: ${book} ${chapter}:${verse}`)
      return null
    } catch (error) {
      console.error(`❌ Error getting specific verse ${book} ${chapter}:${verse}:`, error)
      return null
    }
  },

  // Get chapter verses with multiple endpoint attempts
  async getChapterVerses(book: string, chapter: number, version = "1"): Promise<BibleVerse[]> {
    try {
      console.log(`📖 Getting chapter: ${book} ${chapter}`)

      const bookId = this.getBookId(book)
      if (!bookId) {
        console.log(`❌ Unknown book: ${book}`)
        return []
      }

      // Try multiple endpoint formats
      const chapterEndpoints = [
        `${BASE_URL}/GetChapter?bookId=${bookId}&chapterId=${chapter}&versionId=${version}`,
        `${BASE_URL}/chapter?book=${bookId}&chapter=${chapter}&version=${version}`,
        `${BASE_URL}/chapters/${bookId}/${chapter}?version=${version}`,
        `${BASE_URL}/bible/${version}/${bookId}/${chapter}`,
      ]

      for (const endpoint of chapterEndpoints) {
        try {
          console.log(`📡 Trying chapter endpoint: ${endpoint}`)

          const response = await fetch(endpoint, {
            method: "GET",
            headers: {
              "X-RapidAPI-Key": RAPIDAPI_KEY,
              "X-RapidAPI-Host": RAPIDAPI_HOST,
            },
          })

          if (response.ok) {
            const data = await response.json()
            console.log(`✅ Chapter endpoint worked: ${endpoint}`, data)

            const verses = this.parseSearchResponse(data, `${book} ${chapter}`)
            if (verses.length > 0) {
              return verses
            }
          } else {
            console.log(`❌ Chapter endpoint failed: ${endpoint} - ${response.status}`)
          }
        } catch (endpointError) {
          console.log(`❌ Chapter endpoint error: ${endpoint}`, endpointError)
        }
      }

      console.log(`❌ Could not find chapter: ${book} ${chapter}`)
      return []
    } catch (error) {
      console.error(`❌ Error getting chapter ${book} ${chapter}:`, error)
      return []
    }
  },

  // Parse verse reference (e.g., "John 3:16")
  parseVerseReference(reference: string): { book: string; chapter: number; verse: number } | null {
    const match = reference.match(/^(\d{0,2}\s*[a-zA-Z]+)\s*(\d+)\s*:\s*(\d+)$/i)
    if (match) {
      const [, book, chapter, verse] = match
      return {
        book: book.trim().replace(/(\d)([a-zA-Z])/, "$1 $2"),
        chapter: Number.parseInt(chapter),
        verse: Number.parseInt(verse),
      }
    }
    return null
  },

  // Parse chapter reference (e.g., "John 3")
  parseChapterReference(reference: string): { book: string; chapter: number } | null {
    const match = reference.match(/^(\d{0,2}\s*[a-zA-Z]+)\s*(\d+)$/i)
    if (match) {
      const [, book, chapter] = match
      return {
        book: book.trim().replace(/(\d)([a-zA-Z])/, "$1 $2"),
        chapter: Number.parseInt(chapter),
      }
    }
    return null
  },

  // Format reference from API response
  formatReference(item: any): string {
    if (item.reference) return item.reference
    if (item.r) return item.r

    // Try to construct from parts
    const book = item.book || item.b || item.bookName || "Unknown"
    const chapter = item.chapter || item.c || item.chapterNumber || "?"
    const verse = item.verse || item.v || item.verseNumber || "?"

    return `${book} ${chapter}:${verse}`
  },

  // Get book ID for RapidAPI (simplified mapping)
  getBookId(book: string): number | null {
    const bookName = book.toLowerCase().trim()
    const bookIds: Record<string, number> = {
      // New Testament
      matthew: 40,
      matt: 40,
      mark: 41,
      mrk: 41,
      luke: 42,
      luk: 42,
      john: 43,
      jhn: 43,
      acts: 44,
      romans: 45,
      rom: 45,
      "1 corinthians": 46,
      "1 cor": 46,
      "2 corinthians": 47,
      "2 cor": 47,
      galatians: 48,
      gal: 48,
      ephesians: 49,
      eph: 49,
      philippians: 50,
      phil: 50,
      colossians: 51,
      col: 51,
      "1 thessalonians": 52,
      "1 thess": 52,
      "2 thessalonians": 53,
      "2 thess": 53,
      "1 timothy": 54,
      "1 tim": 54,
      "2 timothy": 55,
      "2 tim": 55,
      titus: 56,
      tit: 56,
      philemon: 57,
      phlm: 57,
      hebrews: 58,
      heb: 58,
      james: 59,
      jas: 59,
      "1 peter": 60,
      "1 pet": 60,
      "2 peter": 61,
      "2 pet": 61,
      "1 john": 62,
      "1 jhn": 62,
      "2 john": 63,
      "2 jhn": 63,
      "3 john": 64,
      "3 jhn": 64,
      jude: 65,
      revelation: 66,
      rev: 66,
      // Old Testament
      genesis: 1,
      gen: 1,
      exodus: 2,
      exod: 2,
      leviticus: 3,
      lev: 3,
      numbers: 4,
      num: 4,
      deuteronomy: 5,
      deut: 5,
      joshua: 6,
      josh: 6,
      judges: 7,
      judg: 7,
      ruth: 8,
      "1 samuel": 9,
      "1 sam": 9,
      "2 samuel": 10,
      "2 sam": 10,
      "1 kings": 11,
      "1 kgs": 11,
      "2 kings": 12,
      "2 kgs": 12,
      "1 chronicles": 13,
      "1 chr": 13,
      "2 chronicles": 14,
      "2 chr": 14,
      ezra: 15,
      nehemiah: 16,
      neh: 16,
      esther: 17,
      esth: 17,
      job: 18,
      psalms: 19,
      psalm: 19,
      ps: 19,
      proverbs: 20,
      prov: 20,
      ecclesiastes: 21,
      eccl: 21,
      "song of solomon": 22,
      song: 22,
      isaiah: 23,
      isa: 23,
      jeremiah: 24,
      jer: 24,
      lamentations: 25,
      lam: 25,
      ezekiel: 26,
      ezek: 26,
      daniel: 27,
      dan: 27,
      hosea: 28,
      hos: 28,
      joel: 29,
      amos: 30,
      obadiah: 31,
      obad: 31,
      jonah: 32,
      micah: 33,
      mic: 33,
      nahum: 34,
      nah: 34,
      habakkuk: 35,
      hab: 35,
      zephaniah: 36,
      zeph: 36,
      haggai: 37,
      hag: 37,
      zechariah: 38,
      zech: 38,
      malachi: 39,
      mal: 39,
    }

    return bookIds[bookName] || null
  },
}
