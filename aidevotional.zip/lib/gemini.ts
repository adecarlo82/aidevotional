import { GoogleGenerativeAI } from "@google/generative-ai"

if (!process.env.GOOGLE_AI_STUDIO_KEY) {
  throw new Error("GOOGLE_AI_STUDIO_KEY environment variable is required")
}

const genAI = new GoogleGenerativeAI(process.env.GOOGLE_AI_STUDIO_KEY)

export const gemini = {
  // Generate concordance study for a biblical word or concept
  async generateConcordance(word: string) {
    console.log(`🤖 Generating concordance for: "${word}"`)

    const model = genAI.getGenerativeModel({
      model: "gemini-1.5-flash",
      systemInstruction: `You are a biblical scholar and theologian providing comprehensive concordance studies. 
      Your role is to analyze biblical words and concepts with deep theological insight.
      
      For each word or concept, provide:
      1. A clear, biblical definition
      2. 3-5 key verses that best illustrate the concept (with brief explanations)
      3. Major biblical themes associated with the word
      4. Original language insights (Hebrew/Greek)
      5. Practical application for Christian living
      6. A comprehensive study summary
      
      Be scholarly yet accessible, theologically sound, and practically relevant.
      Focus on how this word/concept reveals God's character and His relationship with humanity.`,
    })

    const prompt = `Please provide a comprehensive biblical concordance study for the word "${word}".

Structure your response with clear sections:

## Biblical Definition
Provide a concise, 1-2 sentence definition of "${word}" based on its biblical usage.

## Key Verses
List 3-4 important Bible verses with brief explanations:
- **Reference**: Brief explanation of how this verse demonstrates the concept

## Major Themes
List 3-4 main biblical themes:
- Theme 1
- Theme 2
- Theme 3

## Original Language
Brief insights from Hebrew/Greek (2-3 sentences maximum)

## Practical Application
How this applies to Christian life today (2-3 sentences)

## Study Summary
A concise paragraph tying everything together

Keep the Biblical Definition section short and focused. Use clear formatting with headers and bullet points.`

    try {
      const result = await model.generateContent(prompt)
      const response = result.response.text()

      console.log(`✅ Generated concordance for "${word}":`, response.substring(0, 200) + "...")

      // Parse the AI response into structured data
      const concordanceData = this.parseConcordanceResponse(response, word)

      return concordanceData
    } catch (error) {
      console.error(`❌ Concordance generation failed for "${word}":`, error)
      throw error
    }
  },

  // Parse the AI response into structured concordance data
  parseConcordanceResponse(response: string, word: string) {
    console.log(`📝 Parsing concordance response for: "${word}"`)

    // Default structure
    const concordance = {
      word: word,
      definition: "",
      keyVerses: [] as Array<{ reference: string; text: string; explanation: string }>,
      themes: [] as string[],
      crossReferences: [] as string[],
      originalLanguage: "",
      practicalApplication: "",
      fullStudy: response, // Keep the full AI response
    }

    try {
      // Extract definition (look for patterns and keep it concise)
      const definitionMatch = response.match(/(?:Biblical Definition|Definition):\s*([^#\n]*(?:\n(?!#)[^#\n]*)*)/i)
      if (definitionMatch) {
        let definition = definitionMatch[1].trim()
        // Limit definition to first 2 sentences for conciseness
        const sentences = definition.split(/[.!?]+/)
        if (sentences.length > 2) {
          definition = sentences.slice(0, 2).join(". ").trim() + "."
        }
        concordance.definition = definition
      } else {
        // Shorter fallback definition
        concordance.definition = `"${word}" in Scripture refers to a key biblical concept with theological significance.`
      }

      // Extract key verses (look for verse references)
      const versePattern = /([1-3]?\s*[A-Za-z]+\s+\d+:\d+(?:-\d+)?)/g
      const verseMatches = response.match(versePattern) || []

      // Create sample verses if none found in response
      if (verseMatches.length === 0) {
        concordance.keyVerses = [
          {
            reference: "Study Note",
            text: `The word "${word}" appears throughout Scripture with rich theological meaning.`,
            explanation: `This concordance study explores the biblical usage and significance of "${word}".`,
          },
        ]
      } else {
        // Use found verses (limit to first 5)
        concordance.keyVerses = verseMatches.slice(0, 5).map((ref, index) => ({
          reference: ref.trim(),
          text: `Key verse demonstrating the biblical meaning of "${word}".`,
          explanation: `This verse shows how "${word}" is used in biblical context.`,
        }))
      }

      // Extract themes (look for lists or bullet points)
      const themesMatch = response.match(/(?:Major Themes|Themes):\s*([^#]*?)(?=\n#|\n\*\*|$)/i)
      if (themesMatch) {
        const themesText = themesMatch[1]
        concordance.themes = themesText
          .split(/\n|•|-|\d\./)
          .map((t) => t.trim())
          .filter((t) => t.length > 3)
          .slice(0, 6)
      } else {
        concordance.themes = [
          `Biblical meaning of ${word}`,
          `Theological significance`,
          `Spiritual application`,
          `God's character revealed through ${word}`,
        ]
      }

      // Extract original language insights
      const languageMatch = response.match(/(?:Original Language|Hebrew|Greek):\s*([^#]*?)(?=\n#|\n\*\*|$)/i)
      if (languageMatch) {
        concordance.originalLanguage = languageMatch[1].trim()
      } else {
        concordance.originalLanguage = `The word "${word}" has rich meaning in the original Hebrew and Greek texts, revealing deeper theological insights.`
      }

      // Extract practical application
      const applicationMatch = response.match(/(?:Practical Application|Application):\s*([^#]*?)(?=\n#|\n\*\*|$)/i)
      if (applicationMatch) {
        concordance.practicalApplication = applicationMatch[1].trim()
      } else {
        concordance.practicalApplication = `Understanding "${word}" in its biblical context helps believers grow in faith and apply God's truth to daily life.`
      }

      console.log(`✅ Parsed concordance for "${word}":`, {
        definitionLength: concordance.definition.length,
        keyVersesCount: concordance.keyVerses.length,
        themesCount: concordance.themes.length,
      })

      return concordance
    } catch (parseError) {
      console.error(`❌ Error parsing concordance for "${word}":`, parseError)

      // Return basic structure with the full response
      return {
        word: word,
        definition: `Biblical study of the word "${word}" reveals its theological significance throughout Scripture.`,
        keyVerses: [
          {
            reference: "Study Note",
            text: `The word "${word}" appears throughout the Bible with deep spiritual meaning.`,
            explanation: "This concordance provides insights into the biblical usage and significance.",
          },
        ],
        themes: [`Biblical meaning of ${word}`, "Theological significance", "Spiritual application"],
        crossReferences: ["Related biblical concepts"],
        originalLanguage: `Study of the Hebrew and Greek words translated as "${word}" reveals deeper meaning.`,
        practicalApplication: `Understanding "${word}" helps believers apply biblical truth to their lives.`,
        fullStudy: response,
      }
    }
  },

  // Generate devotional outline for a topic
  async generateDevotional(topic: string, preferences?: any) {
    console.log(`🙏 Generating devotional for: "${topic}"`)

    const model = genAI.getGenerativeModel({
      model: "gemini-1.5-flash",
      systemInstruction: `You are a Christian pastor and devotional writer creating meaningful, biblically-grounded devotional studies.
      
      Your role is to:
      1. Find relevant Scripture passages for the topic
      2. Create structured devotional outlines with practical application
      3. Include reflection questions that encourage spiritual growth
      4. Provide actionable steps for Christian living
      5. Write encouraging prayers
      
      Be pastoral, encouraging, and biblically sound. Focus on how God's word applies to daily life and spiritual growth.`,
    })

    const prompt = `Create a devotional outline for the topic "${topic}".

Structure your response with these sections:

## Title
Create an inspiring title for this devotional

## Main Scripture
Choose one key Bible verse that relates to "${topic}" (provide reference and full text)

## Introduction
Write a brief introduction (2-3 sentences) that connects the topic to the Scripture

## Key Points
Provide 2-3 main points from the Scripture passage:
- **Point 1**: Explanation
- **Point 2**: Explanation  
- **Point 3**: Explanation

## Reflection Questions
List 3-4 thoughtful questions for personal reflection:
- Question 1
- Question 2
- Question 3

## Practical Application
Provide 3-4 specific, actionable steps:
- Step 1
- Step 2
- Step 3

## Prayer
Write a meaningful prayer related to the topic (2-3 sentences)

Keep each section concise but meaningful. Focus on practical spiritual growth and biblical truth.`

    try {
      const result = await model.generateContent(prompt)
      const response = result.response.text()

      console.log(`✅ Generated devotional for "${topic}":`, response.substring(0, 200) + "...")

      // Parse the AI response into structured data
      const devotionalData = this.parseDevotionalResponse(response, topic)

      return devotionalData
    } catch (error) {
      console.error(`❌ Devotional generation failed for "${topic}":`, error)
      throw error
    }
  },

  // Parse the AI response into structured devotional data
  parseDevotionalResponse(response: string, topic: string) {
    console.log(`📝 Parsing devotional response for: "${topic}"`)

    // Default structure
    const devotional = {
      title: `Devotional on ${topic}`,
      topic: topic,
      duration: "15-20 minutes reading time",
      mainScripture: {
        reference: "Psalm 119:105",
        text: "Thy word is a lamp unto my feet, and a light unto my path.",
      },
      outline: {
        introduction: "Begin with prayer and open your heart to God's word.",
        scriptureStudy: {
          keyPoints: [
            {
              point: "Scripture Exploration",
              explanation: `Explore the biblical teachings about ${topic}.`,
            },
          ],
        },
        reflection: {
          questions: [
            "What is God saying to me through this passage?",
            "How can I apply this to my life today?",
            `How does ${topic} relate to my spiritual journey?`,
          ],
        },
        application: {
          practicalSteps: [
            "Reflect on the main message",
            "Identify one specific application",
            "Pray for wisdom to live this out",
          ],
          prayer: `Lord, help me understand and apply Your truth about ${topic}. Amen.`,
        },
      },
      additionalScriptures: [],
      tags: ["devotional", "bible-study", "reflection", topic.toLowerCase()],
      source: "Google Gemini AI",
      query: topic,
      timestamp: new Date().toISOString(),
    }

    try {
      // Extract title
      const titleMatch = response.match(/(?:## Title|Title):\s*([^\n#]+)/i)
      if (titleMatch) {
        devotional.title = titleMatch[1].trim()
      }

      // Extract main scripture
      const scriptureMatch = response.match(/(?:## Main Scripture|Main Scripture):\s*([^#]*?)(?=\n#|\n\*\*|$)/i)
      if (scriptureMatch) {
        const scriptureText = scriptureMatch[1].trim()
        const versePattern = /([1-3]?\s*[A-Za-z]+\s+\d+:\d+(?:-\d+)?)/
        const verseMatch = scriptureText.match(versePattern)

        if (verseMatch) {
          devotional.mainScripture.reference = verseMatch[1].trim()
          // Extract the verse text (everything after the reference)
          const textAfterRef = scriptureText.replace(verseMatch[0], "").trim()
          if (textAfterRef.length > 10) {
            devotional.mainScripture.text = textAfterRef.replace(/^[:\-\s"]+|["]+$/g, "")
          }
        }
      }

      // Extract introduction
      const introMatch = response.match(/(?:## Introduction|Introduction):\s*([^#]*?)(?=\n#|\n\*\*|$)/i)
      if (introMatch) {
        devotional.outline.introduction = introMatch[1].trim()
      }

      // Extract key points
      const keyPointsMatch = response.match(/(?:## Key Points|Key Points):\s*([^#]*?)(?=\n#|\n\*\*|$)/i)
      if (keyPointsMatch) {
        const pointsText = keyPointsMatch[1]
        const points = pointsText
          .split(/\n\*\*|\n-|\n\d\./)
          .map((p) => p.trim())
          .filter((p) => p.length > 10)
          .slice(0, 4)

        if (points.length > 0) {
          devotional.outline.scriptureStudy.keyPoints = points.map((point) => {
            const [title, ...explanation] = point.split(":")
            return {
              point: title.replace(/^\*\*|\*\*$/g, "").trim(),
              explanation: explanation.join(":").trim() || "Key insight from Scripture",
            }
          })
        }
      }

      // Extract reflection questions
      const questionsMatch = response.match(
        /(?:## Reflection Questions|Reflection Questions):\s*([^#]*?)(?=\n#|\n\*\*|$)/i,
      )
      if (questionsMatch) {
        const questionsText = questionsMatch[1]
        const questions = questionsText
          .split(/\n-|\n\d\./)
          .map((q) => q.trim())
          .filter((q) => q.length > 5)
          .slice(0, 5)

        if (questions.length > 0) {
          devotional.outline.reflection.questions = questions
        }
      }

      // Extract practical application
      const applicationMatch = response.match(
        /(?:## Practical Application|Practical Application):\s*([^#]*?)(?=\n#|\n\*\*|$)/i,
      )
      if (applicationMatch) {
        const appText = applicationMatch[1]
        const steps = appText
          .split(/\n-|\n\d\./)
          .map((s) => s.trim())
          .filter((s) => s.length > 5)
          .slice(0, 5)

        if (steps.length > 0) {
          devotional.outline.application.practicalSteps = steps
        }
      }

      // Extract prayer
      const prayerMatch = response.match(/(?:## Prayer|Prayer):\s*([^#]*?)(?=\n#|\n\*\*|$)/i)
      if (prayerMatch) {
        devotional.outline.application.prayer = prayerMatch[1].trim()
      }

      console.log(`✅ Parsed devotional for "${topic}":`, {
        title: devotional.title,
        mainScripture: devotional.mainScripture.reference,
        keyPointsCount: devotional.outline.scriptureStudy.keyPoints.length,
        questionsCount: devotional.outline.reflection.questions.length,
      })

      return devotional
    } catch (parseError) {
      console.error(`❌ Error parsing devotional for "${topic}":`, parseError)

      // Return basic structure with fallback content
      return devotional
    }
  },

  // Other existing methods...
  async searchConcordance(word: string, bibleVersion = "WBT") {
    return await this.generateConcordance(word)
  },
}
