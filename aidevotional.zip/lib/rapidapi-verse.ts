// Simple focused implementation to get exact verses from RapidAPI
const RAPIDAPI_KEY = "4f9153d221msh9e9473de1ec4e29p1732b3jsna37f84ab53e1"
const RAPIDAPI_HOST = "iq-bible.p.rapidapi.com"
const BASE_URL = `https://${RAPIDAPI_HOST}`

// Book ID mapping (exact format needed for RapidAPI)
const BOOK_IDS: Record<string, string> = {
  genesis: "01",
  exodus: "02",
  leviticus: "03",
  numbers: "04",
  deuteronomy: "05",
  joshua: "06",
  judges: "07",
  ruth: "08",
  "1 samuel": "09",
  "2 samuel": "10",
  "1 kings": "11",
  "2 kings": "12",
  "1 chronicles": "13",
  "2 chronicles": "14",
  ezra: "15",
  nehemiah: "16",
  esther: "17",
  job: "18",
  psalms: "19",
  psalm: "19",
  proverbs: "20",
  ecclesiastes: "21",
  "song of solomon": "22",
  isaiah: "23",
  jeremiah: "24",
  lamentations: "25",
  ezekiel: "26",
  daniel: "27",
  hosea: "28",
  joel: "29",
  amos: "30",
  obadiah: "31",
  jonah: "32",
  micah: "33",
  nahum: "34",
  habakkuk: "35",
  zephaniah: "36",
  haggai: "37",
  zechariah: "38",
  malachi: "39",
  matthew: "40",
  mark: "41",
  luke: "42",
  john: "43",
  acts: "44",
  romans: "45",
  "1 corinthians": "46",
  "2 corinthians": "47",
  galatians: "48",
  ephesians: "49",
  philippians: "50",
  colossians: "51",
  "1 thessalonians": "52",
  "2 thessalonians": "53",
  "1 timothy": "54",
  "2 timothy": "55",
  titus: "56",
  philemon: "57",
  hebrews: "58",
  james: "59",
  "1 peter": "60",
  "2 peter": "61",
  "1 john": "62",
  "2 john": "63",
  "3 john": "64",
  jude: "65",
  revelation: "66",
}

export const rapidApiVerse = {
  // Get exact verse by reference (e.g., "John 3:16")
  async getExactVerse(reference: string, versionId = "kjv") {
    try {
      console.log(`🔍 Getting exact verse: "${reference}"`)

      // Parse the reference (e.g., "John 3:16" -> book="john", chapter=3, verse=16)
      const parts = reference.match(/^(\d?\s*[a-zA-Z]+)\s*(\d+):(\d+)$/i)
      if (!parts) {
        console.error(`❌ Invalid reference format: "${reference}"`)
        return null
      }

      const [, bookName, chapter, verse] = parts
      const bookId = BOOK_IDS[bookName.trim().toLowerCase()]

      if (!bookId) {
        console.error(`❌ Unknown book: "${bookName}"`)
        return null
      }

      // Format as 8-digit verseId: BBCCCVVV
      const verseId = `${bookId}${chapter.padStart(3, "0")}${verse.padStart(3, "0")}`
      console.log(`📝 Parsed "${reference}" to verseId: ${verseId}`)

      // Make the API request
      const url = `${BASE_URL}/GetVerse?verseId=${verseId}&versionId=${versionId}`
      console.log(`📡 RapidAPI request: ${url}`)

      const response = await fetch(url, {
        method: "GET",
        headers: {
          "x-rapidapi-key": RAPIDAPI_KEY,
          "x-rapidapi-host": RAPIDAPI_HOST,
        },
      })

      if (!response.ok) {
        throw new Error(`RapidAPI request failed: ${response.status} ${response.statusText}`)
      }

      const data = await response.json()
      console.log(`✅ RapidAPI response:`, data)

      if (data && data.length > 0) {
        const item = data[0]
        return {
          reference: `${this.getBookName(item.b)} ${Number.parseInt(item.c)}:${Number.parseInt(item.v)}`,
          text: item.t,
          id: item.id,
        }
      }

      console.error(`❌ No verse found for "${reference}" (verseId: ${verseId})`)
      return null
    } catch (error) {
      console.error(`❌ Error getting verse "${reference}":`, error)
      return null
    }
  },

  // Get book name from book ID
  getBookName(bookId: string): string {
    const books: Record<string, string> = {
      "1": "Genesis",
      "2": "Exodus",
      "3": "Leviticus",
      "4": "Numbers",
      "5": "Deuteronomy",
      "6": "Joshua",
      "7": "Judges",
      "8": "Ruth",
      "9": "1 Samuel",
      "10": "2 Samuel",
      "11": "1 Kings",
      "12": "2 Kings",
      "13": "1 Chronicles",
      "14": "2 Chronicles",
      "15": "Ezra",
      "16": "Nehemiah",
      "17": "Esther",
      "18": "Job",
      "19": "Psalms",
      "20": "Proverbs",
      "21": "Ecclesiastes",
      "22": "Song of Solomon",
      "23": "Isaiah",
      "24": "Jeremiah",
      "25": "Lamentations",
      "26": "Ezekiel",
      "27": "Daniel",
      "28": "Hosea",
      "29": "Joel",
      "30": "Amos",
      "31": "Obadiah",
      "32": "Jonah",
      "33": "Micah",
      "34": "Nahum",
      "35": "Habakkuk",
      "36": "Zephaniah",
      "37": "Haggai",
      "38": "Zechariah",
      "39": "Malachi",
      "40": "Matthew",
      "41": "Mark",
      "42": "Luke",
      "43": "John",
      "44": "Acts",
      "45": "Romans",
      "46": "1 Corinthians",
      "47": "2 Corinthians",
      "48": "Galatians",
      "49": "Ephesians",
      "50": "Philippians",
      "51": "Colossians",
      "52": "1 Thessalonians",
      "53": "2 Thessalonians",
      "54": "1 Timothy",
      "55": "2 Timothy",
      "56": "Titus",
      "57": "Philemon",
      "58": "Hebrews",
      "59": "James",
      "60": "1 Peter",
      "61": "2 Peter",
      "62": "1 John",
      "63": "2 John",
      "64": "3 John",
      "65": "Jude",
      "66": "Revelation",
    }
    return books[bookId] || `Book ${bookId}`
  },
}
