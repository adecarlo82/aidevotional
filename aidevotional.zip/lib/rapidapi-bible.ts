// RapidAPI Bible service integration - Alternative Approach
const RAPIDAPI_KEY = "4f9153d221msh9e9473de1ec4e29p1732b3jsna37f84ab53e1"
const RAPIDAPI_HOST = "iq-bible.p.rapidapi.com"
const BASE_URL = "https://iq-bible.p.rapidapi.com"

interface BibleVerse {
  reference: string
  text: string
  id?: string
}

export const rapidApiBible = {
  // Test API connection with different endpoints
  async testConnection(): Promise<{ success: boolean; details: string; data?: any }> {
    try {
      console.log("🔍 Testing RapidAPI Bible connection with different endpoints...")

      // Test 1: Try GetBooks endpoint
      console.log("📚 Testing GetBooks endpoint...")
      const booksResponse = await fetch(`${BASE_URL}/GetBooks?language=english`, {
        method: "GET",
        headers: {
          "X-RapidAPI-Key": RAPIDAPI_KEY,
          "X-RapidAPI-Host": RAPIDAPI_HOST,
        },
      })

      console.log(`📊 Books Response Status: ${booksResponse.status}`)

      if (booksResponse.ok) {
        const booksData = await booksResponse.json()
        console.log("✅ Books API Success:", booksData)
      }

      // Test 2: Try SearchVerses endpoint
      console.log("🔍 Testing SearchVerses endpoint...")
      const searchResponse = await fetch(`${BASE_URL}/SearchVerses?query=John 3:16&versionId=1`, {
        method: "GET",
        headers: {
          "X-RapidAPI-Key": RAPIDAPI_KEY,
          "X-RapidAPI-Host": RAPIDAPI_HOST,
        },
      })

      console.log(`📊 Search Response Status: ${searchResponse.status}`)

      if (searchResponse.ok) {
        const searchData = await searchResponse.json()
        console.log("✅ Search API Success:", searchData)

        if (searchData && Array.isArray(searchData) && searchData.length > 0) {
          return {
            success: true,
            details: "RapidAPI connection successful via SearchVerses",
            data: searchData,
          }
        }
      }

      // Test 3: Try GetChapter endpoint
      console.log("📖 Testing GetChapter endpoint...")
      const chapterResponse = await fetch(`${BASE_URL}/GetChapter?bookId=43&chapterId=3&versionId=1`, {
        method: "GET",
        headers: {
          "X-RapidAPI-Key": RAPIDAPI_KEY,
          "X-RapidAPI-Host": RAPIDAPI_HOST,
        },
      })

      console.log(`📊 Chapter Response Status: ${chapterResponse.status}`)

      if (chapterResponse.ok) {
        const chapterData = await chapterResponse.json()
        console.log("✅ Chapter API Success:", chapterData)

        if (chapterData && Array.isArray(chapterData) && chapterData.length > 0) {
          return {
            success: true,
            details: "RapidAPI connection successful via GetChapter",
            data: chapterData,
          }
        }
      }

      return {
        success: false,
        details: "All RapidAPI endpoints returned invalid data",
      }
    } catch (error) {
      console.error("❌ RapidAPI connection test failed:", error)
      return {
        success: false,
        details: `Connection failed: ${error instanceof Error ? error.message : "Unknown error"}`,
      }
    }
  },

  // Get verse using search endpoint instead of direct lookup
  async getVerse(book: string, chapter: number, verse: number, version = "1"): Promise<BibleVerse | null> {
    try {
      console.log(`📖 Fetching ${book} ${chapter}:${verse} from RapidAPI using search...`)

      // Method 1: Try SearchVerses endpoint
      const searchQuery = `${book} ${chapter}:${verse}`
      console.log(`🔍 Searching for: "${searchQuery}"`)

      const searchUrl = `${BASE_URL}/SearchVerses?query=${encodeURIComponent(searchQuery)}&versionId=${version}`
      console.log(`📡 Search URL: ${searchUrl}`)

      const searchResponse = await fetch(searchUrl, {
        method: "GET",
        headers: {
          "X-RapidAPI-Key": RAPIDAPI_KEY,
          "X-RapidAPI-Host": RAPIDAPI_HOST,
        },
      })

      console.log(`📊 Search Response Status: ${searchResponse.status}`)

      if (searchResponse.ok) {
        const searchData = await searchResponse.json()
        console.log(`📊 Search Response Data:`, searchData)

        if (Array.isArray(searchData) && searchData.length > 0) {
          // Find exact match
          const exactMatch = searchData.find((item) => {
            const ref = item.reference || item.r || `${book} ${chapter}:${verse}`
            return ref.toLowerCase().includes(`${book.toLowerCase()} ${chapter}:${verse}`)
          })

          if (exactMatch && (exactMatch.t || exactMatch.text)) {
            const result = {
              reference: `${book} ${chapter}:${verse}`,
              text: (exactMatch.t || exactMatch.text).trim(),
              id: exactMatch.id || `${book}_${chapter}_${verse}`,
            }
            console.log(`✅ Found verse via search:`, result)
            return result
          }

          // If no exact match, try first result
          const firstResult = searchData[0]
          if (firstResult && (firstResult.t || firstResult.text)) {
            const result = {
              reference: `${book} ${chapter}:${verse}`,
              text: (firstResult.t || firstResult.text).trim(),
              id: firstResult.id || `${book}_${chapter}_${verse}`,
            }
            console.log(`✅ Using first search result:`, result)
            return result
          }
        }
      }

      // Method 2: Try GetChapter and extract specific verse
      console.log(`📖 Trying GetChapter approach for ${book} ${chapter}...`)

      const bookId = this.getBookId(book)
      if (bookId) {
        const chapterUrl = `${BASE_URL}/GetChapter?bookId=${bookId}&chapterId=${chapter}&versionId=${version}`
        console.log(`📡 Chapter URL: ${chapterUrl}`)

        const chapterResponse = await fetch(chapterUrl, {
          method: "GET",
          headers: {
            "X-RapidAPI-Key": RAPIDAPI_KEY,
            "X-RapidAPI-Host": RAPIDAPI_HOST,
          },
        })

        console.log(`📊 Chapter Response Status: ${chapterResponse.status}`)

        if (chapterResponse.ok) {
          const chapterData = await chapterResponse.json()
          console.log(`📊 Chapter Response Data:`, chapterData)

          if (Array.isArray(chapterData)) {
            // Find the specific verse
            const verseData = chapterData.find((v) => {
              const verseNum = v.v || v.verse || v.verseNumber
              return verseNum === verse
            })

            if (verseData && (verseData.t || verseData.text)) {
              const result = {
                reference: `${book} ${chapter}:${verse}`,
                text: (verseData.t || verseData.text).trim(),
                id: verseData.id || `${book}_${chapter}_${verse}`,
              }
              console.log(`✅ Found verse via chapter:`, result)
              return result
            }
          }
        }
      }

      console.log(`❌ All RapidAPI methods failed for ${book} ${chapter}:${verse}`)
      return null
    } catch (error) {
      console.error(`❌ Error fetching verse ${book} ${chapter}:${verse}:`, error)
      return null
    }
  },

  // Get book ID for RapidAPI
  getBookId(book: string): number | null {
    const bookName = book.toLowerCase().trim()
    const bookIds: Record<string, number> = {
      // New Testament
      matthew: 40,
      matt: 40,
      mark: 41,
      mrk: 41,
      luke: 42,
      luk: 42,
      john: 43,
      jhn: 43,
      acts: 44,
      romans: 45,
      rom: 45,
      "1 corinthians": 46,
      "1 cor": 46,
      "2 corinthians": 47,
      "2 cor": 47,
      galatians: 48,
      gal: 48,
      ephesians: 49,
      eph: 49,
      philippians: 50,
      phil: 50,
      colossians: 51,
      col: 51,
      "1 thessalonians": 52,
      "1 thess": 52,
      "2 thessalonians": 53,
      "2 thess": 53,
      "1 timothy": 54,
      "1 tim": 54,
      "2 timothy": 55,
      "2 tim": 55,
      titus: 56,
      tit: 56,
      philemon: 57,
      phlm: 57,
      hebrews: 58,
      heb: 58,
      james: 59,
      jas: 59,
      "1 peter": 60,
      "1 pet": 60,
      "2 peter": 61,
      "2 pet": 61,
      "1 john": 62,
      "1 jhn": 62,
      "2 john": 63,
      "2 jhn": 63,
      "3 john": 64,
      "3 jhn": 64,
      jude: 65,
      revelation: 66,
      rev: 66,
    }

    return bookIds[bookName] || null
  },

  // Parse verse reference
  parseVerseReference(reference: string): { book: string; chapter: number; verse: number } | null {
    console.log(`🔍 Parsing verse reference: "${reference}"`)

    const match = reference.match(/^(\d{0,2}\s*[a-zA-Z]+)\s*(\d+)\s*:\s*(\d+)$/i)

    if (match) {
      const [, book, chapter, verse] = match
      const result = {
        book: book.trim().replace(/(\d)([a-zA-Z])/, "$1 $2"),
        chapter: Number.parseInt(chapter),
        verse: Number.parseInt(verse),
      }
      console.log(`✅ Successfully parsed verse reference:`, result)
      return result
    }

    console.log(`❌ Could not parse as verse reference: "${reference}"`)
    return null
  },

  // Get multiple verses
  async getVerseRange(
    book: string,
    chapter: number,
    startVerse: number,
    endVerse: number,
    version = "1",
  ): Promise<BibleVerse[]> {
    const verses: BibleVerse[] = []

    for (let verseNum = startVerse; verseNum <= endVerse; verseNum++) {
      const verse = await this.getVerse(book, chapter, verseNum, version)
      if (verse) {
        verses.push(verse)
      }
    }

    return verses
  },
}
