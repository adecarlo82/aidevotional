import { supabase } from "./supabase"
import type { User } from "@supabase/supabase-js"

export const auth = {
  // Sign up new user
  async signUp(email: string, password: string, fullName?: string) {
    try {
      console.log("🔐 Attempting to sign up user:", email)

      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: fullName,
          },
        },
      })

      if (error) {
        console.error("❌ Sign up error:", error)
        throw new Error(error.message || "Failed to create account")
      }

      console.log("✅ Sign up successful:", data.user?.email)
      return data
    } catch (error) {
      console.error("❌ Sign up failed:", error)
      throw error
    }
  },

  // Sign in existing user
  async signIn(email: string, password: string) {
    try {
      console.log("🔐 Attempting to sign in user:", email)

      if (!email || !password) {
        throw new Error("Email and password are required")
      }

      const { data, error } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password: password,
      })

      if (error) {
        console.error("❌ Sign in error:", error)

        // Provide user-friendly error messages
        if (error.message.includes("Invalid login credentials")) {
          throw new Error("Invalid email or password. Please check your credentials and try again.")
        } else if (error.message.includes("Email not confirmed")) {
          throw new Error("Please check your email and click the confirmation link before signing in.")
        } else if (error.message.includes("Too many requests")) {
          throw new Error("Too many sign-in attempts. Please wait a moment and try again.")
        } else {
          throw new Error(error.message || "Failed to sign in")
        }
      }

      if (!data.user) {
        throw new Error("Sign in failed - no user data returned")
      }

      console.log("✅ Sign in successful:", data.user.email)
      return data
    } catch (error) {
      console.error("❌ Sign in failed:", error)
      throw error
    }
  },

  // Sign out
  async signOut() {
    try {
      console.log("🔐 Signing out user...")
      const { error } = await supabase.auth.signOut()
      if (error) {
        console.error("❌ Sign out error:", error)
        throw new Error(error.message || "Failed to sign out")
      }
      console.log("✅ Sign out successful")
    } catch (error) {
      console.error("❌ Sign out failed:", error)
      throw error
    }
  },

  // Get current user - handle missing session as normal state
  async getCurrentUser(): Promise<User | null> {
    try {
      const {
        data: { user },
        error,
      } = await supabase.auth.getUser()

      // Handle "Auth session missing!" as a normal state (user not signed in)
      if (error) {
        if (error.message.includes("Auth session missing")) {
          console.log("ℹ️ No user session found (user not signed in)")
          return null
        }
        console.error("❌ Get user error:", error)
        return null
      }

      if (user) {
        console.log("✅ Current user found:", user.email)
      } else {
        console.log("ℹ️ No current user")
      }

      return user
    } catch (error) {
      console.error("❌ Get current user failed:", error)
      return null
    }
  },

  // Check if user has active subscription
  async checkSubscription(userId: string) {
    try {
      const { data, error } = await supabase
        .from("user_subscriptions")
        .select("*")
        .eq("user_id", userId)
        .eq("status", "active")
        .single()

      if (error && error.code !== "PGRST116") {
        console.error("❌ Check subscription error:", error)
        throw error
      }

      return data
    } catch (error) {
      console.error("❌ Check subscription failed:", error)
      return null
    }
  },

  // Listen to auth changes
  onAuthStateChange(callback: (event: string, session: any) => void) {
    return supabase.auth.onAuthStateChange((event, session) => {
      console.log("🔐 Auth state changed:", event, session?.user?.email || "no user")
      callback(event, session)
    })
  },

  // Test Supabase connection - use a method that doesn't require auth
  async testConnection(): Promise<boolean> {
    try {
      console.log("🧪 Testing Supabase connection...")

      // Use getSession instead of getUser to avoid auth session errors
      const { data, error } = await supabase.auth.getSession()

      // Even if there's no session, if we can connect to Supabase, it's working
      if (error && !error.message.includes("Auth session missing")) {
        console.error("❌ Supabase connection test failed:", error)
        return false
      }

      console.log("✅ Supabase connection test successful")
      return true
    } catch (error) {
      console.error("❌ Supabase connection test failed:", error)
      return false
    }
  },
}
