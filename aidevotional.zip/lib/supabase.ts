import { createClient } from "@supabase/supabase-js"

// Use the environment variables you provided earlier with fallbacks
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "https://wvnydnkmzkuviknnsfsq.supabase.co"
const supabaseAnonKey =
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ||
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Ind2bnlkbmttemt1dmlrbm5zZnNxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDgzODUwMTYsImV4cCI6MjA2Mzk2MTAxNn0.f_h8W445VJJNIsz0lFvwZXoqhNd0Bcre2DNc_VSeSh0"

// Log the configuration for debugging
console.log("🔧 Supabase Configuration:")
console.log("URL:", supabaseUrl)
console.log("Anon Key (first 20 chars):", supabaseAnonKey ? supabaseAnonKey.substring(0, 20) + "..." : "NOT SET")

// Validate that we have the required values
if (!supabaseUrl) {
  console.error("❌ Supabase URL is missing")
  throw new Error("Supabase URL is required. Please check your environment variables.")
}

if (!supabaseAnonKey) {
  console.error("❌ Supabase Anon Key is missing")
  throw new Error("Supabase Anon Key is required. Please check your environment variables.")
}

// Validate URL format
try {
  new URL(supabaseUrl)
  console.log("✅ Supabase URL format is valid")
} catch (error) {
  console.error("❌ Invalid Supabase URL format:", supabaseUrl)
  throw new Error(`Invalid Supabase URL format: ${supabaseUrl}`)
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true,
  },
})

console.log("✅ Supabase client created successfully")

// Types for your existing table
export interface UserSubscription {
  id: string
  user_id: string
  stripe_customer_id: string | null
  stripe_subscription_id: string | null
  status: string
  current_period_start: string | null
  current_period_end: string | null
  created_at: string
  updated_at: string
}

// Types for new tables we'll create
export interface UserProfile {
  id: string
  user_id: string
  full_name: string | null
  preferred_bible_version: string
  email_notifications: boolean
  created_at: string
  updated_at: string
}

export interface SavedSearch {
  id: string
  user_id: string
  search_type: "verse" | "concordance" | "devotional"
  query: string
  results: any
  created_at: string
}

export interface SavedDevotional {
  id: string
  user_id: string
  title: string
  content: string
  scripture_references: string[]
  tags: string[]
  created_at: string
  updated_at: string
}
