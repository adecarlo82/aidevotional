// lib/hybrid-bible-api.ts

export async function findVerses(query: string): Promise<any[]> {
  let verses: any[] = []

  try {
    // Basic example - replace with actual API call and data processing
    console.log(`📚 Searching for verses with query: ${query}`)
    verses = [{ text: `Verse for query: ${query}`, reference: "Example 1:1" }]
  } catch (error) {
    console.error(`🔥 Error fetching verses:`, error)
    // Handle the error appropriately, maybe return a default value or re-throw
  }

  // At the end of the findVerses function, before the final return
  console.log(`📚 Final verses result:`, verses)

  // Ensure we always return an array
  if (!Array.isArray(verses)) {
    console.log(`⚠️ Verses is not an array, wrapping:`, verses)
    if (verses && typeof verses === "object") {
      return [verses]
    }
    return []
  }

  return verses
}
