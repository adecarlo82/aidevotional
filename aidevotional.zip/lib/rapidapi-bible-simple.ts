// Simple RapidAPI Bible implementation based on actual working endpoints
const RAPIDAPI_KEY = "4f9153d221msh9e9473de1ec4e29p1732b3jsna37f84ab53e1"
const RAPIDAPI_HOST = "iq-bible.p.rapidapi.com"
const BASE_URL = `https://${RAPIDAPI_HOST}`

interface BibleVerse {
  reference: string
  text: string
  id?: string
}

interface SearchResult {
  verses: BibleVerse[]
  summary?: string
  source: string
  query: string
  timestamp: string
}

export const rapidApiBibleSimple = {
  // Make API request with proper headers
  async makeRequest(endpoint: string): Promise<any> {
    console.log(`📡 RapidAPI request: ${endpoint}`)

    const response = await fetch(endpoint, {
      method: "GET",
      headers: {
        "x-rapidapi-key": RAPIDAPI_KEY,
        "x-rapidapi-host": RAPIDAPI_HOST,
      },
    })

    if (!response.ok) {
      throw new Error(`RapidAPI request failed: ${response.status} ${response.statusText}`)
    }

    const data = await response.json()
    console.log(`✅ RapidAPI response received`)
    return data
  },

  // Search for verses using GetSearch endpoint
  async searchVerses(query: string, versionId = "kjv"): Promise<SearchResult> {
    try {
      console.log(`🔍 RapidAPI searching for: "${query}"`)

      const endpoint = `${BASE_URL}/GetSearch?query=${encodeURIComponent(query)}&versionId=${versionId}`
      const data = await this.makeRequest(endpoint)

      // Convert API response to our format
      const verses: BibleVerse[] = data.map((item: any) => ({
        reference: this.formatReference(item.b, item.c, item.v),
        text: item.t,
        id: `rapidapi_${item.id}`,
      }))

      console.log(`✅ RapidAPI found ${verses.length} verses for: "${query}"`)

      return {
        verses,
        summary: `Found ${verses.length} verses containing "${query}"`,
        source: "RapidAPI Bible Service",
        query,
        timestamp: new Date().toISOString(),
      }
    } catch (error) {
      console.error(`❌ RapidAPI search failed for "${query}":`, error)
      throw error
    }
  },

  // Get specific verse using GetVerse endpoint
  async getVerse(reference: string, versionId = "kjv"): Promise<BibleVerse | null> {
    try {
      console.log(`📖 RapidAPI getting verse: "${reference}"`)

      // Parse reference like "John 3:16"
      const verseId = this.parseReferenceToVerseId(reference)
      if (!verseId) {
        console.log(`❌ Could not parse reference: "${reference}"`)
        return null
      }

      const endpoint = `${BASE_URL}/GetVerse?verseId=${verseId}&versionId=${versionId}`
      const data = await this.makeRequest(endpoint)

      if (data && data.length > 0) {
        const item = data[0]
        return {
          reference: this.formatReference(item.b, item.c, item.v),
          text: item.t,
          id: `rapidapi_${item.id}`,
        }
      }

      return null
    } catch (error) {
      console.error(`❌ RapidAPI getVerse failed for "${reference}":`, error)
      return null
    }
  },

  // Get random verse using GetRandomVerse endpoint
  async getRandomVerse(versionId = "kjv"): Promise<BibleVerse | null> {
    try {
      console.log(`🎲 RapidAPI getting random verse`)

      const endpoint = `${BASE_URL}/GetRandomVerse?versionId=${versionId}`
      const data = await this.makeRequest(endpoint)

      if (data && data.length > 0) {
        const item = data[0]
        return {
          reference: this.formatReference(item.b, item.c, item.v),
          text: item.t,
          id: `rapidapi_${item.id}`,
        }
      }

      return null
    } catch (error) {
      console.error(`❌ RapidAPI getRandomVerse failed:`, error)
      return null
    }
  },

  // Parse citation using GetParseCitation endpoint
  async parseCitation(citation: string): Promise<string[]> {
    try {
      console.log(`📝 RapidAPI parsing citation: "${citation}"`)

      const endpoint = `${BASE_URL}/GetParseCitation?citation=${encodeURIComponent(citation)}`
      const data = await this.makeRequest(endpoint)

      if (data && data.verseIds) {
        return data.verseIds
      }

      return []
    } catch (error) {
      console.error(`❌ RapidAPI parseCitation failed for "${citation}":`, error)
      return []
    }
  },

  // Get multiple verses by verseIds
  async getVersesByIds(verseIds: string[], versionId = "kjv"): Promise<BibleVerse[]> {
    const verses: BibleVerse[] = []

    for (const verseId of verseIds) {
      try {
        const endpoint = `${BASE_URL}/GetVerse?verseId=${verseId}&versionId=${versionId}`
        const data = await this.makeRequest(endpoint)

        if (data && data.length > 0) {
          const item = data[0]
          verses.push({
            reference: this.formatReference(item.b, item.c, item.v),
            text: item.t,
            id: `rapidapi_${item.id}`,
          })
        }
      } catch (error) {
        console.error(`❌ Failed to get verse ${verseId}:`, error)
      }
    }

    return verses
  },

  // Test connection
  async testConnection(): Promise<{ success: boolean; details: string }> {
    try {
      console.log(`🧪 Testing RapidAPI connection`)

      const endpoint = `${BASE_URL}/GetInfo`
      const data = await this.makeRequest(endpoint)

      if (data && data.appName) {
        return {
          success: true,
          details: `Connected to ${data.appName} version ${data.version}`,
        }
      }

      return {
        success: false,
        details: "Unexpected response format",
      }
    } catch (error) {
      return {
        success: false,
        details: error instanceof Error ? error.message : "Connection failed",
      }
    }
  },

  // Helper: Format reference from book, chapter, verse numbers
  formatReference(bookId: string, chapter: string, verse: string): string {
    const bookName = this.getBookName(Number.parseInt(bookId))
    return `${bookName} ${Number.parseInt(chapter)}:${Number.parseInt(verse)}`
  },

  // Helper: Get book name from book ID
  getBookName(bookId: number): string {
    const books: Record<number, string> = {
      1: "Genesis",
      2: "Exodus",
      3: "Leviticus",
      4: "Numbers",
      5: "Deuteronomy",
      6: "Joshua",
      7: "Judges",
      8: "Ruth",
      9: "1 Samuel",
      10: "2 Samuel",
      11: "1 Kings",
      12: "2 Kings",
      13: "1 Chronicles",
      14: "2 Chronicles",
      15: "Ezra",
      16: "Nehemiah",
      17: "Esther",
      18: "Job",
      19: "Psalms",
      20: "Proverbs",
      21: "Ecclesiastes",
      22: "Song of Solomon",
      23: "Isaiah",
      24: "Jeremiah",
      25: "Lamentations",
      26: "Ezekiel",
      27: "Daniel",
      28: "Hosea",
      29: "Joel",
      30: "Amos",
      31: "Obadiah",
      32: "Jonah",
      33: "Micah",
      34: "Nahum",
      35: "Habakkuk",
      36: "Zephaniah",
      37: "Haggai",
      38: "Zechariah",
      39: "Malachi",
      40: "Matthew",
      41: "Mark",
      42: "Luke",
      43: "John",
      44: "Acts",
      45: "Romans",
      46: "1 Corinthians",
      47: "2 Corinthians",
      48: "Galatians",
      49: "Ephesians",
      50: "Philippians",
      51: "Colossians",
      52: "1 Thessalonians",
      53: "2 Thessalonians",
      54: "1 Timothy",
      55: "2 Timothy",
      56: "Titus",
      57: "Philemon",
      58: "Hebrews",
      59: "James",
      60: "1 Peter",
      61: "2 Peter",
      62: "1 John",
      63: "2 John",
      64: "3 John",
      65: "Jude",
      66: "Revelation",
    }
    return books[bookId] || `Book ${bookId}`
  },

  // Helper: Parse reference like "John 3:16" to verseId format
  parseReferenceToVerseId(reference: string): string | null {
    // Try to match patterns like "John 3:16" or "1 John 3:16"
    const match = reference.match(/^(\d?\s*[a-zA-Z]+)\s*(\d+):(\d+)$/i)
    if (!match) return null

    const [, bookName, chapter, verse] = match
    const bookId = this.getBookIdByName(bookName.trim())
    if (!bookId) return null

    // Format as 8-digit verseId: BBCCCVVV
    const formattedBookId = bookId.toString().padStart(2, "0")
    const formattedChapter = chapter.padStart(3, "0")
    const formattedVerse = verse.padStart(3, "0")

    return `${formattedBookId}${formattedChapter}${formattedVerse}`
  },

  // Helper: Get book ID by name
  getBookIdByName(bookName: string): number | null {
    const bookNames: Record<string, number> = {
      genesis: 1,
      exodus: 2,
      leviticus: 3,
      numbers: 4,
      deuteronomy: 5,
      joshua: 6,
      judges: 7,
      ruth: 8,
      "1 samuel": 9,
      "2 samuel": 10,
      "1 kings": 11,
      "2 kings": 12,
      "1 chronicles": 13,
      "2 chronicles": 14,
      ezra: 15,
      nehemiah: 16,
      esther: 17,
      job: 18,
      psalms: 19,
      psalm: 19,
      proverbs: 20,
      ecclesiastes: 21,
      "song of solomon": 22,
      isaiah: 23,
      jeremiah: 24,
      lamentations: 25,
      ezekiel: 26,
      daniel: 27,
      hosea: 28,
      joel: 29,
      amos: 30,
      obadiah: 31,
      jonah: 32,
      micah: 33,
      nahum: 34,
      habakkuk: 35,
      zephaniah: 36,
      haggai: 37,
      zechariah: 38,
      malachi: 39,
      matthew: 40,
      mark: 41,
      luke: 42,
      john: 43,
      acts: 44,
      romans: 45,
      "1 corinthians": 46,
      "2 corinthians": 47,
      galatians: 48,
      ephesians: 49,
      philippians: 50,
      colossians: 51,
      "1 thessalonians": 52,
      "2 thessalonians": 53,
      "1 timothy": 54,
      "2 timothy": 55,
      titus: 56,
      philemon: 57,
      hebrews: 58,
      james: 59,
      "1 peter": 60,
      "2 peter": 61,
      "1 john": 62,
      "2 john": 63,
      "3 john": 64,
      jude: 65,
      revelation: 66,
    }

    return bookNames[bookName.toLowerCase()] || null
  },
}
