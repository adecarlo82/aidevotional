// Working RapidAPI Bible service based on endpoint test results
const RAPIDAPI_KEY = process.env.RAPIDAPI_KEY || "4f9153d221msh9e9473de1ec4e29p1732b3jsna37f84ab53e1"
const RAPIDAPI_HOST = process.env.RAPIDAPI_HOST || "iq-bible.p.rapidapi.com"
const BASE_URL = `https://${RAPIDAPI_HOST}`

interface BibleVerse {
  reference: string
  text: string
  id?: string
}

interface SearchResult {
  verses: BibleVerse[]
  summary?: string
  source: string
  query: string
  timestamp: string
}

export const rapidApiBibleWorking = {
  // Track which endpoints are working
  workingEndpoints: {
    books: false,
    search: false,
    verse: false,
    chapter: false,
  },

  // Test connection and discover working endpoints
  async discoverWorkingEndpoints(): Promise<{ success: boolean; workingEndpoints: string[] }> {
    console.log("🔍 Discovering working RapidAPI endpoints...")
    const workingEndpoints: string[] = []

    // Reset working endpoints
    this.workingEndpoints = {
      books: false,
      search: false,
      verse: false,
      chapter: false,
    }

    try {
      // Test books endpoints
      const booksEndpoints = [`${BASE_URL}/GetBooks?language=english`, `${BASE_URL}/books`]

      for (const endpoint of booksEndpoints) {
        try {
          const response = await this.makeApiRequest(endpoint)
          if (response.ok) {
            this.workingEndpoints.books = true
            workingEndpoints.push(`Books: ${endpoint}`)
            break
          }
        } catch (error) {
          console.log(`Books endpoint failed: ${endpoint}`)
        }
      }

      // Test search endpoints
      const searchEndpoints = [
        `${BASE_URL}/SearchVerses?query=john&versionId=1`,
        `${BASE_URL}/search?query=john`,
        `${BASE_URL}/verses/search?q=john`,
      ]

      for (const endpoint of searchEndpoints) {
        try {
          const response = await this.makeApiRequest(endpoint)
          if (response.ok) {
            this.workingEndpoints.search = true
            workingEndpoints.push(`Search: ${endpoint}`)
            break
          }
        } catch (error) {
          console.log(`Search endpoint failed: ${endpoint}`)
        }
      }

      // Test verse endpoints
      const verseEndpoints = [
        `${BASE_URL}/GetVerse?bookId=43&chapterId=3&verseId=16&versionId=1`,
        `${BASE_URL}/verse?book=43&chapter=3&verse=16&version=1`,
      ]

      for (const endpoint of verseEndpoints) {
        try {
          const response = await this.makeApiRequest(endpoint)
          if (response.ok) {
            this.workingEndpoints.verse = true
            workingEndpoints.push(`Verse: ${endpoint}`)
            break
          }
        } catch (error) {
          console.log(`Verse endpoint failed: ${endpoint}`)
        }
      }

      // Test chapter endpoints
      const chapterEndpoints = [
        `${BASE_URL}/GetChapter?bookId=43&chapterId=3&versionId=1`,
        `${BASE_URL}/chapter?book=43&chapter=3&version=1`,
      ]

      for (const endpoint of chapterEndpoints) {
        try {
          const response = await this.makeApiRequest(endpoint)
          if (response.ok) {
            this.workingEndpoints.chapter = true
            workingEndpoints.push(`Chapter: ${endpoint}`)
            break
          }
        } catch (error) {
          console.log(`Chapter endpoint failed: ${endpoint}`)
        }
      }

      const success = workingEndpoints.length > 0
      console.log(`✅ RapidAPI discovery complete. Working endpoints: ${workingEndpoints.length}`)

      return {
        success,
        workingEndpoints,
      }
    } catch (error) {
      console.error("❌ RapidAPI endpoint discovery failed:", error)
      return {
        success: false,
        workingEndpoints: [],
      }
    }
  },

  // Make API request with proper headers
  async makeApiRequest(url: string): Promise<Response> {
    return fetch(url, {
      method: "GET",
      headers: {
        "X-RapidAPI-Key": RAPIDAPI_KEY,
        "X-RapidAPI-Host": RAPIDAPI_HOST,
      },
    })
  },

  // Search for verses using available endpoints
  async searchVerses(query: string, version = "1"): Promise<SearchResult> {
    console.log(`🔍 RapidAPI searching for: "${query}"`)

    try {
      // Ensure we know which endpoints work
      if (
        !this.workingEndpoints.books &&
        !this.workingEndpoints.search &&
        !this.workingEndpoints.verse &&
        !this.workingEndpoints.chapter
      ) {
        await this.discoverWorkingEndpoints()
      }

      // Strategy 1: Try exact verse reference search if verse endpoint works
      if (this.workingEndpoints.verse) {
        const verseMatch = this.parseVerseReference(query)
        if (verseMatch) {
          console.log(`📖 Detected verse reference:`, verseMatch)
          const verse = await this.getSpecificVerse(verseMatch.book, verseMatch.chapter, verseMatch.verse, version)
          if (verse) {
            return {
              verses: [verse],
              summary: `Found the specific verse: ${verse.reference}`,
              source: "RapidAPI Bible Service (primary)",
              query: query,
              timestamp: new Date().toISOString(),
            }
          }
        }
      }

      // Strategy 2: Try search endpoint if available
      if (this.workingEndpoints.search) {
        console.log(`🔍 Using search endpoint for: "${query}"`)
        const searchResults = await this.searchVersesEndpoint(query, version)
        if (searchResults.length > 0) {
          return {
            verses: searchResults,
            summary: `Found ${searchResults.length} verses related to "${query}"`,
            source: "RapidAPI Bible Service (primary)",
            query: query,
            timestamp: new Date().toISOString(),
          }
        }
      }

      // Strategy 3: Try chapter search if chapter endpoint works
      if (this.workingEndpoints.chapter) {
        const chapterMatch = this.parseChapterReference(query)
        if (chapterMatch) {
          console.log(`📖 Detected chapter reference:`, chapterMatch)
          const chapterVerses = await this.getChapterVerses(chapterMatch.book, chapterMatch.chapter, version)
          if (chapterVerses.length > 0) {
            return {
              verses: chapterVerses.slice(0, 5), // Limit to first 5 verses
              summary: `Found ${chapterVerses.length} verses from ${chapterMatch.book} ${chapterMatch.chapter}`,
              source: "RapidAPI Bible Service (primary)",
              query: query,
              timestamp: new Date().toISOString(),
            }
          }
        }
      }

      // If all strategies fail, return empty result
      console.log(`❌ No results found for: "${query}"`)
      return {
        verses: [],
        summary: `No verses found for "${query}" in RapidAPI`,
        source: "RapidAPI Bible Service (primary)",
        query: query,
        timestamp: new Date().toISOString(),
      }
    } catch (error) {
      console.error(`❌ RapidAPI search error for "${query}":`, error)
      throw error // Let the hybrid system handle the fallback
    }
  },

  // Search using the working search endpoint
  async searchVersesEndpoint(query: string, version = "1"): Promise<BibleVerse[]> {
    try {
      const url = ""

      // Use the appropriate search endpoint format based on discovery
      if (this.workingEndpoints.search) {
        // Try different search endpoint formats
        const searchEndpoints = [
          `${BASE_URL}/SearchVerses?query=${encodeURIComponent(query)}&versionId=${version}`,
          `${BASE_URL}/search?query=${encodeURIComponent(query)}`,
          `${BASE_URL}/verses/search?q=${encodeURIComponent(query)}`,
        ]

        for (const endpoint of searchEndpoints) {
          try {
            console.log(`📡 Trying search endpoint: ${endpoint}`)
            const response = await this.makeApiRequest(endpoint)

            if (response.ok) {
              const data = await response.json()
              const verses = this.parseSearchResponse(data, query)
              if (verses.length > 0) {
                return verses
              }
            }
          } catch (endpointError) {
            console.log(`Search endpoint error: ${endpoint}`, endpointError)
          }
        }
      }

      return []
    } catch (error) {
      console.error("SearchVerses endpoint error:", error)
      return []
    }
  },

  // Get specific verse using working verse endpoint
  async getSpecificVerse(book: string, chapter: number, verse: number, version = "1"): Promise<BibleVerse | null> {
    try {
      console.log(`📖 Getting specific verse: ${book} ${chapter}:${verse}`)
      const bookId = this.getBookId(book)

      if (!bookId) {
        console.log(`❌ Unknown book: ${book}`)
        return null
      }

      if (this.workingEndpoints.verse) {
        // Try different verse endpoint formats
        const verseEndpoints = [
          `${BASE_URL}/GetVerse?bookId=${bookId}&chapterId=${chapter}&verseId=${verse}&versionId=${version}`,
          `${BASE_URL}/verse?book=${bookId}&chapter=${chapter}&verse=${verse}&version=${version}`,
        ]

        for (const endpoint of verseEndpoints) {
          try {
            console.log(`📡 Trying verse endpoint: ${endpoint}`)
            const response = await this.makeApiRequest(endpoint)

            if (response.ok) {
              const data = await response.json()
              console.log(`✅ Verse endpoint worked: ${endpoint}`, data)

              if (data && (data.text || data.t)) {
                return {
                  reference: `${book} ${chapter}:${verse}`,
                  text: (data.text || data.t).trim(),
                  id: `rapidapi_${data.id || `${book}_${chapter}_${verse}`}`,
                }
              }
            }
          } catch (endpointError) {
            console.log(`Verse endpoint error: ${endpoint}`, endpointError)
          }
        }
      }

      // If verse endpoint doesn't work, try search as fallback
      if (this.workingEndpoints.search) {
        const searchQuery = `${book} ${chapter}:${verse}`
        const searchResults = await this.searchVersesEndpoint(searchQuery, version)

        // Find exact match
        const exactMatch = searchResults.find((v) =>
          v.reference.toLowerCase().includes(`${book.toLowerCase()} ${chapter}:${verse}`),
        )

        if (exactMatch) {
          console.log(`✅ Found verse via search fallback: ${exactMatch.reference}`)
          return exactMatch
        }
      }

      console.log(`❌ Could not find verse: ${book} ${chapter}:${verse}`)
      return null
    } catch (error) {
      console.error(`❌ Error getting specific verse ${book} ${chapter}:${verse}:`, error)
      return null
    }
  },

  // Get chapter verses using working chapter endpoint
  async getChapterVerses(book: string, chapter: number, version = "1"): Promise<BibleVerse[]> {
    try {
      console.log(`📖 Getting chapter: ${book} ${chapter}`)
      const bookId = this.getBookId(book)

      if (!bookId) {
        console.log(`❌ Unknown book: ${book}`)
        return []
      }

      if (this.workingEndpoints.chapter) {
        // Try different chapter endpoint formats
        const chapterEndpoints = [
          `${BASE_URL}/GetChapter?bookId=${bookId}&chapterId=${chapter}&versionId=${version}`,
          `${BASE_URL}/chapter?book=${bookId}&chapter=${chapter}&version=${version}`,
        ]

        for (const endpoint of chapterEndpoints) {
          try {
            console.log(`📡 Trying chapter endpoint: ${endpoint}`)
            const response = await this.makeApiRequest(endpoint)

            if (response.ok) {
              const data = await response.json()
              console.log(`✅ Chapter endpoint worked: ${endpoint}`)

              const verses = this.parseSearchResponse(data, `${book} ${chapter}`)
              if (verses.length > 0) {
                return verses
              }
            }
          } catch (endpointError) {
            console.log(`Chapter endpoint error: ${endpoint}`, endpointError)
          }
        }
      }

      // If chapter endpoint doesn't work, try search as fallback
      if (this.workingEndpoints.search) {
        const searchQuery = `${book} ${chapter}`
        return await this.searchVersesEndpoint(searchQuery, version)
      }

      return []
    } catch (error) {
      console.error(`❌ Error getting chapter ${book} ${chapter}:`, error)
      return []
    }
  },

  // Parse different response formats
  parseSearchResponse(data: any, query: string): BibleVerse[] {
    console.log(`📊 Parsing search response type: ${typeof data}`)

    if (!data) return []

    // Handle array response
    if (Array.isArray(data)) {
      return data
        .filter((item) => item && (item.text || item.t || item.verse))
        .map((item) => ({
          reference: this.formatReference(item),
          text: (item.text || item.t || item.verse || "").trim(),
          id: `rapidapi_${item.id || Date.now()}`,
        }))
        .filter((verse) => verse.text.length > 5)
    }

    // Handle object with verses array
    if (data.verses && Array.isArray(data.verses)) {
      return this.parseSearchResponse(data.verses, query)
    }

    // Handle object with results array
    if (data.results && Array.isArray(data.results)) {
      return this.parseSearchResponse(data.results, query)
    }

    // Handle single verse object
    if (data.text || data.t) {
      return [
        {
          reference: this.formatReference(data),
          text: (data.text || data.t || "").trim(),
          id: `rapidapi_${data.id || Date.now()}`,
        },
      ]
    }

    console.log(`⚠️ Unknown response format:`, data)
    return []
  },

  // Parse verse reference (e.g., "John 3:16")
  parseVerseReference(reference: string): { book: string; chapter: number; verse: number } | null {
    const match = reference.match(/^(\d{0,2}\s*[a-zA-Z]+)\s*(\d+)\s*:\s*(\d+)$/i)
    if (match) {
      const [, book, chapter, verse] = match
      return {
        book: book.trim().replace(/(\d)([a-zA-Z])/, "$1 $2"),
        chapter: Number.parseInt(chapter),
        verse: Number.parseInt(verse),
      }
    }
    return null
  },

  // Parse chapter reference (e.g., "John 3")
  parseChapterReference(reference: string): { book: string; chapter: number } | null {
    const match = reference.match(/^(\d{0,2}\s*[a-zA-Z]+)\s*(\d+)$/i)
    if (match) {
      const [, book, chapter] = match
      return {
        book: book.trim().replace(/(\d)([a-zA-Z])/, "$1 $2"),
        chapter: Number.parseInt(chapter),
      }
    }
    return null
  },

  // Format reference from API response
  formatReference(item: any): string {
    if (item.reference) return item.reference
    if (item.r) return item.r

    // Try to construct from parts
    const book = item.book || item.b || item.bookName || "Unknown"
    const chapter = item.chapter || item.c || item.chapterNumber || "?"
    const verse = item.verse || item.v || item.verseNumber || "?"

    return `${book} ${chapter}:${verse}`
  },

  // Get book ID for RapidAPI
  getBookId(book: string): number | null {
    const bookName = book.toLowerCase().trim()
    const bookIds: Record<string, number> = {
      // New Testament
      matthew: 40,
      matt: 40,
      mark: 41,
      mrk: 41,
      luke: 42,
      luk: 42,
      john: 43,
      jhn: 43,
      acts: 44,
      romans: 45,
      rom: 45,
      "1 corinthians": 46,
      "1 cor": 46,
      "2 corinthians": 47,
      "2 cor": 47,
      galatians: 48,
      gal: 48,
      ephesians: 49,
      eph: 49,
      philippians: 50,
      phil: 50,
      colossians: 51,
      col: 51,
      "1 thessalonians": 52,
      "1 thess": 52,
      "2 thessalonians": 53,
      "2 thess": 53,
      "1 timothy": 54,
      "1 tim": 54,
      "2 timothy": 55,
      "2 tim": 55,
      titus: 56,
      tit: 56,
      philemon: 57,
      phlm: 57,
      hebrews: 58,
      heb: 58,
      james: 59,
      jas: 59,
      "1 peter": 60,
      "1 pet": 60,
      "2 peter": 61,
      "2 pet": 61,
      "1 john": 62,
      "1 jhn": 62,
      "2 john": 63,
      "2 jhn": 63,
      "3 john": 64,
      "3 jhn": 64,
      jude: 65,
      revelation: 66,
      rev: 66,
      // Old Testament
      genesis: 1,
      gen: 1,
      exodus: 2,
      exod: 2,
      leviticus: 3,
      lev: 3,
      numbers: 4,
      num: 4,
      deuteronomy: 5,
      deut: 5,
      joshua: 6,
      josh: 6,
      judges: 7,
      judg: 7,
      ruth: 8,
      "1 samuel": 9,
      "1 sam": 9,
      "2 samuel": 10,
      "2 sam": 10,
      "1 kings": 11,
      "1 kgs": 11,
      "2 kings": 12,
      "2 kgs": 12,
      "1 chronicles": 13,
      "1 chr": 13,
      "2 chronicles": 14,
      "2 chr": 14,
      ezra: 15,
      nehemiah: 16,
      neh: 16,
      esther: 17,
      esth: 17,
      job: 18,
      psalms: 19,
      psalm: 19,
      ps: 19,
      proverbs: 20,
      prov: 20,
      ecclesiastes: 21,
      eccl: 21,
      "song of solomon": 22,
      song: 22,
      isaiah: 23,
      isa: 23,
      jeremiah: 24,
      jer: 24,
      lamentations: 25,
      lam: 25,
      ezekiel: 26,
      ezek: 26,
      daniel: 27,
      dan: 27,
      hosea: 28,
      hos: 28,
      joel: 29,
      amos: 30,
      obadiah: 31,
      obad: 31,
      jonah: 32,
      micah: 33,
      mic: 33,
      nahum: 34,
      nah: 34,
      habakkuk: 35,
      hab: 35,
      zephaniah: 36,
      zeph: 36,
      haggai: 37,
      hag: 37,
      zechariah: 38,
      zech: 38,
      malachi: 39,
      mal: 39,
    }

    return bookIds[bookName] || null
  },
}
