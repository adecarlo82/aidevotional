import { rapidApiBibleWorking } from "./rapidapi-bible-working"
import { bibleAPI } from "./bible-api"

interface BibleVerse {
  reference: string
  text: string
  id?: string
}

interface SearchResult {
  verses: BibleVerse[]
  summary?: string
  source: string
  query: string
  timestamp: string
}

// Hybrid Bible API that tries RapidAPI first, then falls back to local database
export const hybridBibleApiFixed = {
  // Track system status
  status: {
    rapidApiWorking: false,
    localDbWorking: true,
    lastChecked: "",
  },

  // Initialize and check API status
  async init(): Promise<void> {
    try {
      console.log("🔄 Initializing Hybrid Bible API...")

      // Check RapidAPI status
      const rapidApiStatus = await rapidApiBibleWorking.discoverWorkingEndpoints()
      this.status.rapidApiWorking = rapidApiStatus.success

      // Check local database status (assume it's working)
      this.status.localDbWorking = true

      this.status.lastChecked = new Date().toISOString()

      console.log(
        `✅ Hybrid Bible API initialized. RapidAPI: ${this.status.rapidApiWorking ? "Working" : "Not Working"}, Local DB: ${this.status.localDbWorking ? "Working" : "Not Working"}`,
      )
    } catch (error) {
      console.error("❌ Error initializing Hybrid Bible API:", error)
      this.status.rapidApiWorking = false
    }
  },

  // Search verses with fallback
  async searchVerses(query: string): Promise<SearchResult> {
    console.log(`🔍 HYBRID SEARCH for: "${query}"`)

    // Initialize if needed
    if (!this.status.lastChecked) {
      await this.init()
    }

    // Try RapidAPI first if it's working
    if (this.status.rapidApiWorking) {
      try {
        console.log("🌐 Attempting RapidAPI search for:", query)
        const rapidApiResult = await rapidApiBibleWorking.searchVerses(query)

        // If RapidAPI returned verses, use them
        if (rapidApiResult.verses && rapidApiResult.verses.length > 0) {
          console.log(`✅ RapidAPI found ${rapidApiResult.verses.length} verses`)
          return {
            ...rapidApiResult,
            source: "RapidAPI Bible Service (primary)",
          }
        }

        console.log("⚠️ RapidAPI returned no verses, falling back to local database")
      } catch (error) {
        console.error("❌ RapidAPI search failed:", error)
        console.log("⚠️ Using local database fallback")
      }
    } else {
      console.log("ℹ️ RapidAPI not available, using local database")
    }

    // Fall back to local database
    try {
      console.log("📚 LOCAL BIBLE SEARCH for:", query)
      const localVerses = await bibleAPI.findVerses(query)

      return {
        verses: localVerses,
        summary: `Found ${localVerses.length} verses for "${query}" from local database`,
        source: "Local Bible Database (fallback)",
        query: query,
        timestamp: new Date().toISOString(),
      }
    } catch (error) {
      console.error("❌ Local database search failed:", error)

      // Return empty result if both methods fail
      return {
        verses: [],
        summary: `No results found for "${query}" after trying all sources`,
        source: "No working source",
        query: query,
        timestamp: new Date().toISOString(),
      }
    }
  },

  // Get system status
  getStatus(): { rapidApiWorking: boolean; localDbWorking: boolean; lastChecked: string } {
    return this.status
  },
}
