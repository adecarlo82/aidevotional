import { supabase } from "./supabase"
import { stripe, type SubscriptionPlan } from "./stripe"
import type { UserSubscription } from "./supabase"

export const SUBSCRIPTION_PLANS = {
  free: {
    name: "Free",
    price: 0,
    features: [
      "Unlimited Bible verse search",
      "Unlimited AI concordance",
      "Unlimited devotional generation",
      "All core features included",
    ],
    limits: {
      devotionals: -1, // unlimited
      searches: -1, // unlimited
    },
  },
  premium: {
    name: "Premium",
    price: 4.99,
    priceId: process.env.STRIPE_PREMIUM_PRICE_ID,
    features: [
      "Everything in Free",
      "Save devotionals and searches",
      "Search history and bookmarks",
      "Export features (PDF, Word)",
      "Priority support",
      "Custom Bible versions",
      "Advanced study tools",
      "Offline access",
    ],
    limits: {
      devotionals: -1, // unlimited
      searches: -1, // unlimited
    },
  },
}

export const subscription = {
  // Get user's current subscription
  async getUserSubscription(userId: string): Promise<UserSubscription | null> {
    const { data, error } = await supabase.from("user_subscriptions").select("*").eq("user_id", userId).single()

    if (error && error.code !== "PGRST116") throw error
    return data
  },

  // Check if user has active subscription
  async hasActiveSubscription(userId: string): Promise<boolean> {
    const subscription = await this.getUserSubscription(userId)
    return subscription?.status === "active"
  },

  // Get user's subscription plan
  async getUserPlan(userId: string): Promise<SubscriptionPlan> {
    const subscription = await this.getUserSubscription(userId)

    if (!subscription || subscription.status !== "active") {
      return "free"
    }

    // If they have an active subscription, they're on premium
    return "premium"
  },

  // Check if user can perform action based on their plan
  async canPerformAction(userId: string, action: "devotional" | "search", currentUsage?: number): Promise<boolean> {
    const plan = await this.getUserPlan(userId)
    const planLimits = SUBSCRIPTION_PLANS[plan].limits

    if (action === "devotional") {
      return planLimits.devotionals === -1 || (currentUsage || 0) < planLimits.devotionals
    }

    if (action === "search") {
      return planLimits.searches === -1 || (currentUsage || 0) < planLimits.searches
    }

    return false
  },

  // Create Stripe checkout session
  async createCheckoutSession(userId: string, successUrl: string, cancelUrl: string) {
    const planConfig = SUBSCRIPTION_PLANS.premium

    if (!planConfig.priceId) {
      throw new Error(`Price ID not configured for premium plan`)
    }

    // Get or create Stripe customer
    let customerId: string | undefined

    const existingSubscription = await this.getUserSubscription(userId)
    if (existingSubscription?.stripe_customer_id) {
      customerId = existingSubscription.stripe_customer_id
    } else {
      // Get user email from Supabase Auth
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user?.email) throw new Error("User email not found")

      const customer = await stripe.customers.create({
        email: user.email,
        metadata: {
          supabase_user_id: userId,
        },
      })
      customerId = customer.id
    }

    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      payment_method_types: ["card"],
      line_items: [
        {
          price: planConfig.priceId,
          quantity: 1,
        },
      ],
      mode: "subscription",
      success_url: successUrl,
      cancel_url: cancelUrl,
      metadata: {
        user_id: userId,
        plan: "premium",
      },
    })

    return session
  },

  // Get or create Stripe customer (without subscription record)
  async getOrCreateStripeCustomer(userId: string): Promise<string> {
    // First check if user has existing subscription with customer ID
    const existingSubscription = await this.getUserSubscription(userId)
    if (existingSubscription?.stripe_customer_id) {
      return existingSubscription.stripe_customer_id
    }

    // Get user email from Supabase Auth
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user?.email) throw new Error("User email not found")

    // Create new Stripe customer
    const customer = await stripe.customers.create({
      email: user.email,
      metadata: {
        supabase_user_id: userId,
      },
    })

    // Don't create subscription record yet - that happens when they actually subscribe
    console.log(`Created Stripe customer ${customer.id} for user ${userId}`)

    return customer.id
  },

  // Create or get portal configuration
  async getOrCreatePortalConfiguration(): Promise<string> {
    try {
      // Try to list existing configurations
      const configurations = await stripe.billingPortal.configurations.list({ limit: 1 })

      if (configurations.data.length > 0) {
        return configurations.data[0].id
      }

      // Create a new configuration if none exists
      const configuration = await stripe.billingPortal.configurations.create({
        business_profile: {
          headline: "AI Devotional - Manage your subscription",
        },
        features: {
          payment_method_update: {
            enabled: true,
          },
          subscription_cancel: {
            enabled: true,
            mode: "at_period_end",
          },
          subscription_update: {
            enabled: false,
          },
          invoice_history: {
            enabled: true,
          },
        },
      })

      return configuration.id
    } catch (error) {
      console.error("Error managing portal configuration:", error)
      throw error
    }
  },

  // Create customer portal session
  async createPortalSession(userId: string, returnUrl: string) {
    try {
      // Get or create Stripe customer
      const customerId = await this.getOrCreateStripeCustomer(userId)

      // Try to create portal session without configuration first (uses default)
      try {
        const session = await stripe.billingPortal.sessions.create({
          customer: customerId,
          return_url: returnUrl,
        })
        return session
      } catch (configError) {
        // If no default configuration exists, create one and try again
        if (configError instanceof Error && configError.message.includes("configuration")) {
          console.log("No default portal configuration found, creating one...")
          const configurationId = await this.getOrCreatePortalConfiguration()

          const session = await stripe.billingPortal.sessions.create({
            customer: customerId,
            return_url: returnUrl,
            configuration: configurationId,
          })
          return session
        }
        throw configError
      }
    } catch (error) {
      console.error("Error creating portal session:", error)
      throw error
    }
  },
}
