// Local Bible API with comprehensive verse database
interface BibleVerse {
  reference: string
  text: string
  id?: string
}

// Comprehensive Bible verse database with popular verses
const BIBLE_VERSES: BibleVerse[] = [
  // John
  {
    reference: "John 3:16",
    text: "For God so loved the world, that he gave his only begotten Son, that whosoever believeth in him should not perish, but have everlasting life.",
  },
  {
    reference: "John 14:6",
    text: "Jesus saith unto him, I am the way, the truth, and the life: no man cometh unto the Father, but by me.",
  },
  { reference: "John 1:1", text: "In the beginning was the Word, and the Word was with God, and the Word was God." },
  { reference: "John 8:32", text: "And ye shall know the truth, and the truth shall make you free." },
  {
    reference: "John 10:10",
    text: "The thief cometh not, but for to steal, and to kill, and to destroy: I am come that they might have life, and that they might have it more abundantly.",
  },
  // Adding John 14:22 - the verse that was missing!
  {
    reference: "John 14:22",
    text: "Judas saith unto him, not Iscariot, Lord, how is it that thou wilt manifest thyself unto us, and not unto the world?",
  },
  // Adding more John 14 verses for context
  {
    reference: "John 14:1",
    text: "Let not your heart be troubled: ye believe in God, believe also in me.",
  },
  {
    reference: "John 14:2",
    text: "In my Father's house are many mansions: if it were not so, I would have told you. I go to prepare a place for you.",
  },
  {
    reference: "John 14:3",
    text: "And if I go and prepare a place for you, I will come again, and receive you unto myself; that where I am, there ye may be also.",
  },
  {
    reference: "John 14:15",
    text: "If ye love me, keep my commandments.",
  },
  {
    reference: "John 14:16",
    text: "And I will pray the Father, and he shall give you another Comforter, that he may abide with you for ever;",
  },
  {
    reference: "John 14:27",
    text: "Peace I leave with you, my peace I give unto you: not as the world giveth, give I unto you. Let not your heart be troubled, neither let it be afraid.",
  },
  // Adding more John 14 verses including 14:21
  {
    reference: "John 14:21",
    text: "He that hath my commandments, and keepeth them, he it is that loveth me: and he that loveth me shall be loved of my Father, and I will love him, and will manifest myself to him.",
  },
  {
    reference: "John 14:23",
    text: "Jesus answered and said unto him, If a man love me, he will keep my words: and my Father will love him, and we will come unto him, and make our abode with him.",
  },
  {
    reference: "John 14:26",
    text: "But the Comforter, which is the Holy Ghost, whom the Father will send in my name, he shall teach you all things, and bring all things to your remembrance, whatsoever I have said unto you.",
  },

  // Romans
  {
    reference: "Romans 8:28",
    text: "And we know that all things work together for good to them that love God, to them who are the called according to his purpose.",
  },
  { reference: "Romans 3:23", text: "For all have sinned, and come short of the glory of God." },
  {
    reference: "Romans 6:23",
    text: "For the wages of sin is death; but the gift of God is eternal life through Jesus Christ our Lord.",
  },
  {
    reference: "Romans 10:9",
    text: "That if thou shalt confess with thy mouth the Lord Jesus, and shalt believe in thine heart that God hath raised him from the dead, thou shalt be saved.",
  },
  {
    reference: "Romans 12:2",
    text: "And be not conformed to this world: but be ye transformed by the renewing of your mind, that ye may prove what is that good, and acceptable, and perfect, will of God.",
  },

  // Psalms
  { reference: "Psalm 23:1", text: "The LORD is my shepherd; I shall not want." },
  { reference: "Psalm 119:105", text: "Thy word is a lamp unto my feet, and a light unto my path." },
  {
    reference: "Psalm 46:10",
    text: "Be still, and know that I am God: I will be exalted among the heathen, I will be exalted in the earth.",
  },
  {
    reference: "Psalm 37:4",
    text: "Delight thyself also in the LORD; and he shall give thee the desires of thine heart.",
  },
  {
    reference: "Psalm 139:14",
    text: "I will praise thee; for I am fearfully and wonderfully made: marvellous are thy works; and that my soul knoweth right well.",
  },

  // Philippians
  { reference: "Philippians 4:13", text: "I can do all things through Christ which strengtheneth me." },
  {
    reference: "Philippians 4:19",
    text: "But my God shall supply all your need according to his riches in glory by Christ Jesus.",
  },
  {
    reference: "Philippians 4:6-7",
    text: "Be careful for nothing; but in every thing by prayer and supplication with thanksgiving let your requests be made known unto God. And the peace of God, which passeth all understanding, shall keep your hearts and minds through Christ Jesus.",
  },

  // Matthew
  {
    reference: "Matthew 28:19",
    text: "Go ye therefore, and teach all nations, baptizing them in the name of the Father, and of the Son, and of the Holy Ghost.",
  },
  {
    reference: "Matthew 11:28",
    text: "Come unto me, all ye that labour and are heavy laden, and I will give you rest.",
  },
  {
    reference: "Matthew 6:33",
    text: "But seek ye first the kingdom of God, and his righteousness; and all these things shall be added unto you.",
  },
  {
    reference: "Matthew 5:16",
    text: "Let your light so shine before men, that they may see your good works, and glorify your Father which is in heaven.",
  },

  // 1 Corinthians
  {
    reference: "1 Corinthians 13:4-5",
    text: "Charity suffereth long, and is kind; charity envieth not; charity vaunteth not itself, is not puffed up, Doth not behave itself unseemly, seeketh not her own, is not easily provoked, thinketh no evil.",
  },
  {
    reference: "1 Corinthians 10:13",
    text: "There hath no temptation taken you but such as is common to man: but God is faithful, who will not suffer you to be tempted above that ye are able; but will with the temptation also make a way to escape, that ye may be able to bear it.",
  },

  // Ephesians
  {
    reference: "Ephesians 2:8-9",
    text: "For by grace are ye saved through faith; and that not of yourselves: it is the gift of God: Not of works, lest any man should boast.",
  },
  {
    reference: "Ephesians 6:11",
    text: "Put on the whole armour of God, that ye may be able to stand against the wiles of the devil.",
  },

  // Proverbs
  {
    reference: "Proverbs 3:5-6",
    text: "Trust in the LORD with all thine heart; and lean not unto thine own understanding. In all thy ways acknowledge him, and he shall direct thy paths.",
  },
  { reference: "Proverbs 27:17", text: "Iron sharpeneth iron; so a man sharpeneth the countenance of his friend." },

  // Isaiah
  {
    reference: "Isaiah 40:31",
    text: "But they that wait upon the LORD shall renew their strength; they shall mount up with wings as eagles; they shall run, and not be weary; and they shall walk, and not faint.",
  },
  {
    reference: "Isaiah 55:11",
    text: "So shall my word be that goeth forth out of my mouth: it shall not return unto me void, but it shall accomplish that which I please, and it shall prosper in the thing whereto I sent it.",
  },

  // Jeremiah
  {
    reference: "Jeremiah 29:11",
    text: "For I know the thoughts that I think toward you, saith the LORD, thoughts of peace, and not of evil, to give you an expected end.",
  },

  // 2 Timothy
  {
    reference: "2 Timothy 3:16",
    text: "All scripture is given by inspiration of God, and is profitable for doctrine, for reproof, for correction, for instruction in righteousness.",
  },

  // Hebrews
  {
    reference: "Hebrews 11:1",
    text: "Now faith is the substance of things hoped for, the evidence of things not seen.",
  },
  { reference: "Hebrews 13:8", text: "Jesus Christ the same yesterday, and to day, and for ever." },

  // James
  {
    reference: "James 1:5",
    text: "If any of you lack wisdom, let him ask of God, that giveth to all men liberally, and upbraideth not; and it shall be given him.",
  },

  // 1 Peter
  { reference: "1 Peter 5:7", text: "Casting all your care upon him; for he careth for you." },

  // 1 John
  { reference: "1 John 4:19", text: "We love him, because he first loved us." },
  {
    reference: "1 John 1:9",
    text: "If we confess our sins, he is faithful and just to forgive us our sins, and to cleanse us from all unrighteousness.",
  },

  // Revelation
  {
    reference: "Revelation 3:20",
    text: "Behold, I stand at the door, and knock: if any man hear my voice, and open the door, I will come in to him, and will sup with him, and he with me.",
  },

  // Additional verses for common topics
  // Love
  { reference: "1 John 4:8", text: "He that loveth not knoweth not God; for God is love." },
  {
    reference: "1 Corinthians 13:13",
    text: "And now abideth faith, hope, charity, these three; but the greatest of these is charity.",
  },

  // Faith
  {
    reference: "Hebrews 11:6",
    text: "But without faith it is impossible to please him: for he that cometh to God must believe that he is, and that he is a rewarder of them that diligently seek him.",
  },
  {
    reference: "Mark 11:24",
    text: "Therefore I say unto you, What things soever ye desire, when ye pray, believe that ye receive them, and ye shall have them.",
  },

  // Hope
  {
    reference: "Romans 15:13",
    text: "Now the God of hope fill you with all joy and peace in believing, that ye may abound in hope, through the power of the Holy Ghost.",
  },

  // Peace
  {
    reference: "John 14:27",
    text: "Peace I leave with you, my peace I give unto you: not as the world giveth, give I unto you. Let not your heart be troubled, neither let it be afraid.",
  },

  // Strength
  {
    reference: "Isaiah 41:10",
    text: "Fear thou not; for I am with thee: be not dismayed; for I am thy God: I will strengthen thee; yea, I will help thee; yea, I will uphold thee with the right hand of my righteousness.",
  },

  // Forgiveness
  {
    reference: "Ephesians 4:32",
    text: "And be ye kind one to another, tenderhearted, forgiving one another, even as God for Christ's sake hath forgiven you.",
  },

  // Wisdom
  {
    reference: "Proverbs 9:10",
    text: "The fear of the LORD is the beginning of wisdom: and the knowledge of the holy is understanding.",
  },

  // Comfort
  {
    reference: "2 Corinthians 1:3-4",
    text: "Blessed be God, even the Father of our Lord Jesus Christ, the Father of mercies, and the God of all comfort; Who comforteth us in all our tribulation, that we may be able to comfort them which are in any trouble, by the comfort wherewith we ourselves are comforted of God.",
  },

  // Guidance
  {
    reference: "Psalm 32:8",
    text: "I will instruct thee and teach thee in the way which thou shalt go: I will guide thee with mine eye.",
  },

  // Protection
  { reference: "Psalm 91:11", text: "For he shall give his angels charge over thee, to keep thee in all thy ways." },
]

// Topic-based verse mapping for better search results
const TOPIC_VERSES: Record<string, string[]> = {
  love: ["John 3:16", "1 John 4:8", "1 John 4:19", "1 Corinthians 13:4-5", "1 Corinthians 13:13"],
  faith: ["Hebrews 11:1", "Hebrews 11:6", "Romans 10:9", "Mark 11:24", "Ephesians 2:8-9"],
  hope: ["Romans 15:13", "Jeremiah 29:11", "Romans 8:28", "Isaiah 40:31"],
  peace: ["John 14:27", "Philippians 4:6-7", "Psalm 46:10", "Isaiah 26:3"],
  strength: ["Philippians 4:13", "Isaiah 41:10", "Isaiah 40:31", "2 Corinthians 12:9"],
  wisdom: ["James 1:5", "Proverbs 3:5-6", "Proverbs 9:10", "2 Timothy 3:16"],
  forgiveness: ["1 John 1:9", "Ephesians 4:32", "Matthew 6:14", "Colossians 3:13"],
  comfort: ["2 Corinthians 1:3-4", "Matthew 11:28", "Psalm 23:1", "John 14:1"],
  guidance: ["Psalm 32:8", "Proverbs 3:5-6", "Psalm 119:105", "Isaiah 30:21"],
  protection: ["Psalm 91:11", "Psalm 121:7-8", "2 Thessalonians 3:3", "1 Peter 5:7"],
  salvation: ["Romans 10:9", "Ephesians 2:8-9", "John 3:16", "Romans 6:23"],
  prayer: ["Philippians 4:6-7", "1 Thessalonians 5:17", "Matthew 6:9", "James 5:16"],
  joy: ["Nehemiah 8:10", "Psalm 16:11", "John 15:11", "Galatians 5:22"],
  anxiety: ["Philippians 4:6-7", "1 Peter 5:7", "Matthew 6:26", "Isaiah 41:10"],
  fear: ["Isaiah 41:10", "2 Timothy 1:7", "Psalm 56:3", "Joshua 1:9"],
  purpose: ["Jeremiah 29:11", "Romans 8:28", "Ephesians 2:10", "Proverbs 19:21"],
}

export const bibleAPI = {
  // Enhanced search function with EXACT matching priority
  async findVerses(query: string, version = "WBT"): Promise<BibleVerse[]> {
    console.log(`🔍 LOCAL BIBLE SEARCH for: "${query}"`)

    const searchQuery = query.toLowerCase().trim()
    let results: BibleVerse[] = []

    // Strategy 1: EXACT reference match (highest priority)
    const exactMatch = BIBLE_VERSES.find((verse) => {
      const verseRef = verse.reference.toLowerCase()
      return (
        verseRef === searchQuery ||
        verseRef.replace(/\s+/g, "") === searchQuery.replace(/\s+/g, "") ||
        verseRef.replace(/:/g, " ") === searchQuery ||
        verseRef.replace(/:/g, "") === searchQuery.replace(/:/g, "")
      )
    })

    if (exactMatch) {
      console.log(`✅ Found EXACT reference match: ${exactMatch.reference}`)
      return [exactMatch]
    }

    // Strategy 2: Exact book, chapter, and verse pattern (e.g., "john 14:22")
    const versePattern = /^(\w+)\s*(\d+):(\d+)$/i
    const match = searchQuery.match(versePattern)

    if (match) {
      const [, book, chapter, verse] = match
      const searchPattern = `${book} ${chapter}:${verse}`

      const patternMatch = BIBLE_VERSES.find((v) => {
        const vRef = v.reference.toLowerCase()
        return vRef.includes(searchPattern) || vRef.replace(/\s+/g, "").includes(searchPattern.replace(/\s+/g, ""))
      })

      if (patternMatch) {
        console.log(`✅ Found pattern match: ${patternMatch.reference}`)
        return [patternMatch]
      } else {
        console.log(`❌ No exact match found for: ${searchPattern}`)
        return [
          {
            reference: `${book.charAt(0).toUpperCase() + book.slice(1)} ${chapter}:${verse}`,
            text: `Sorry, we don't have ${book.charAt(0).toUpperCase() + book.slice(1)} ${chapter}:${verse} in our database yet. Try searching for popular verses like "John 3:16", "Romans 8:28", or "Psalm 23:1".`,
          },
        ]
      }
    }

    // Strategy 3: Book and chapter match (e.g., "John 14")
    const chapterPattern = /^(\w+)\s*(\d+)$/i
    const chapterMatch = searchQuery.match(chapterPattern)

    if (chapterMatch) {
      const [, book, chapter] = chapterMatch
      const bookChapterMatches = BIBLE_VERSES.filter((verse) => {
        const verseRef = verse.reference.toLowerCase()
        return verseRef.startsWith(`${book} ${chapter}:`) || verseRef.startsWith(`${book.slice(0, 3)} ${chapter}:`)
      })

      if (bookChapterMatches.length > 0) {
        console.log(`✅ Found book/chapter matches: ${bookChapterMatches.length} verses`)
        return bookChapterMatches.slice(0, 5)
      }
    }

    // Strategy 4: Book name match (e.g., "John", "Romans")
    const bookMatch = BIBLE_VERSES.filter((verse) => {
      const bookName = verse.reference.split(" ")[0].toLowerCase()
      return bookName === searchQuery || bookName.startsWith(searchQuery)
    })

    if (bookMatch.length > 0) {
      console.log(`✅ Found book matches: ${bookMatch.length} verses`)
      return bookMatch.slice(0, 5)
    }

    // Strategy 5: Topic-based search
    const topicMatches = TOPIC_VERSES[searchQuery]
    if (topicMatches) {
      results = BIBLE_VERSES.filter((verse) => topicMatches.includes(verse.reference))
      if (results.length > 0) {
        console.log(`✅ Found topic matches for "${searchQuery}": ${results.length} verses`)
        return results
      }
    }

    // Strategy 6: Text content search
    const textMatches = BIBLE_VERSES.filter(
      (verse) => verse.text.toLowerCase().includes(searchQuery) || verse.reference.toLowerCase().includes(searchQuery),
    )

    if (textMatches.length > 0) {
      console.log(`✅ Found text matches: ${textMatches.length} verses`)
      return textMatches.slice(0, 10)
    }

    // Strategy 7: Fuzzy search for common misspellings or partial matches
    const fuzzyMatches = BIBLE_VERSES.filter((verse) => {
      const verseText = verse.text.toLowerCase()
      const verseRef = verse.reference.toLowerCase()

      const searchWords = searchQuery.split(" ").filter((word) => word.length > 2)
      return searchWords.some((word) => verseText.includes(word) || verseRef.includes(word))
    })

    if (fuzzyMatches.length > 0) {
      console.log(`✅ Found fuzzy matches: ${fuzzyMatches.length} verses`)
      return fuzzyMatches.slice(0, 5)
    }

    // Strategy 8: Default encouraging verses if no matches found
    console.log(`⚠️ No matches found for "${query}", returning encouraging verses`)
    return [
      BIBLE_VERSES.find((v) => v.reference === "Jeremiah 29:11")!,
      BIBLE_VERSES.find((v) => v.reference === "Romans 8:28")!,
      BIBLE_VERSES.find((v) => v.reference === "Philippians 4:13")!,
    ].filter(Boolean)
  },

  // Get specific verse by reference
  async getVerse(reference: string, version = "WBT"): Promise<BibleVerse | null> {
    console.log(`📖 Getting specific verse: "${reference}"`)

    const verse = BIBLE_VERSES.find(
      (v) =>
        v.reference.toLowerCase() === reference.toLowerCase() ||
        v.reference.toLowerCase().replace(/\s+/g, "") === reference.toLowerCase().replace(/\s+/g, ""),
    )

    if (verse) {
      console.log(`✅ Found verse: ${verse.reference}`)
      return verse
    }

    console.log(`⚠️ Verse not found: ${reference}`)
    return null
  },

  // Get random verse for verse of the day
  getRandomVerse(): BibleVerse {
    const randomIndex = Math.floor(Math.random() * BIBLE_VERSES.length)
    const verse = BIBLE_VERSES[randomIndex]
    console.log(`🎲 Random verse: ${verse.reference}`)
    return verse
  },

  // Get verses by topic
  getVersesByTopic(topic: string): BibleVerse[] {
    const topicKey = topic.toLowerCase()
    const references = TOPIC_VERSES[topicKey] || []

    const verses = references
      .map((ref) => BIBLE_VERSES.find((v) => v.reference === ref))
      .filter(Boolean) as BibleVerse[]

    console.log(`📚 Found ${verses.length} verses for topic: ${topic}`)
    return verses
  },

  // Get available topics
  getAvailableTopics(): string[] {
    return Object.keys(TOPIC_VERSES)
  },

  // Clear cache (placeholder for compatibility)
  clearCache() {
    console.log(`🧹 Local Bible API cache cleared`)
  },

  // Get verse count
  getVerseCount(): number {
    return BIBLE_VERSES.length
  },

  // Search suggestions
  getSearchSuggestions(query: string): string[] {
    const suggestions: string[] = []
    const searchQuery = query.toLowerCase()

    // Add topic suggestions
    Object.keys(TOPIC_VERSES).forEach((topic) => {
      if (topic.includes(searchQuery)) {
        suggestions.push(topic)
      }
    })

    // Add book suggestions
    const books = [...new Set(BIBLE_VERSES.map((v) => v.reference.split(" ")[0]))]
    books.forEach((book) => {
      if (book.toLowerCase().includes(searchQuery)) {
        suggestions.push(book)
      }
    })

    return suggestions.slice(0, 5)
  },
}
