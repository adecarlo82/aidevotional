"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function TestRapidAPISimplePage() {
  const [results, setResults] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const testRapidAPI = async () => {
    setLoading(true)
    setError(null)

    try {
      // Test the GetBooks endpoint which is simple and should work if API is accessible
      const response = await fetch("https://iq-bible.p.rapidapi.com/GetBooks?language=english", {
        method: "GET",
        headers: {
          "X-RapidAPI-Key": "4f9153d221msh9e9473de1ec4e29p1732b3jsna37f84ab53e1",
          "X-RapidAPI-Host": "iq-bible.p.rapidapi.com",
        },
      })

      if (!response.ok) {
        throw new Error(`API returned status ${response.status}: ${response.statusText}`)
      }

      const data = await response.json()
      setResults({
        success: true,
        message: "RapidAPI connection successful!",
        data: Array.isArray(data) ? data.slice(0, 5) : data, // Show first 5 books if it's an array
      })
    } catch (err) {
      console.error("RapidAPI test failed:", err)
      setError(err instanceof Error ? err.message : "Unknown error occurred")
      setResults({
        success: false,
        message: "RapidAPI connection failed",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-4xl mx-auto">
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>RapidAPI Bible Connection Test</CardTitle>
            <p className="text-slate-600">Tests if the RapidAPI Bible service is accessible</p>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4 mb-6">
              <Button onClick={testRapidAPI} disabled={loading}>
                {loading ? "Testing..." : "Test RapidAPI Connection"}
              </Button>
              <Button variant="outline" onClick={() => (window.location.href = "/")}>
                Back to Home
              </Button>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-md mb-4">
                <h3 className="font-semibold">Error:</h3>
                <p>{error}</p>
              </div>
            )}

            {results && (
              <div
                className={`p-4 rounded-md ${results.success ? "bg-green-50 border border-green-200" : "bg-red-50 border border-red-200"}`}
              >
                <h3 className={`font-semibold ${results.success ? "text-green-700" : "text-red-700"}`}>
                  {results.success ? "✅ Success" : "❌ Failed"}
                </h3>
                <p className={results.success ? "text-green-700" : "text-red-700"}>{results.message}</p>

                {results.data && (
                  <div className="mt-4">
                    <h4 className="font-medium mb-2">Sample Data:</h4>
                    <pre className="bg-slate-100 p-3 rounded text-xs overflow-auto max-h-60">
                      {JSON.stringify(results.data, null, 2)}
                    </pre>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
