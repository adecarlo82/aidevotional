"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function TestSimple() {
  const [query, setQuery] = useState("Jesus")
  const [results, setResults] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const [connectionTest, setConnectionTest] = useState<any>(null)

  const testSearch = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/ai/search-verses", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query }),
      })
      const data = await response.json()
      setResults(data)
    } catch (error) {
      console.error("Search test failed:", error)
      setResults({ error: "Search failed" })
    } finally {
      setLoading(false)
    }
  }

  const testConnection = async () => {
    try {
      const { hybridBibleSimple } = await import("@/lib/hybrid-bible-simple")
      const testResult = await hybridBibleSimple.testConnection()
      setConnectionTest(testResult)
    } catch (error) {
      console.error("Connection test failed:", error)
      setConnectionTest({ error: "Connection test failed" })
    }
  }

  const testSearchWithQuery = async (searchQuery: string) => {
    setQuery(searchQuery)
    setLoading(true)
    try {
      const response = await fetch("/api/ai/search-verses", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: searchQuery }),
      })
      const data = await response.json()
      setResults(data)
    } catch (error) {
      console.error("Search test failed:", error)
      setResults({ error: "Search failed" })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto p-6 max-w-4xl">
      <h1 className="text-3xl font-bold mb-6">Simple Bible API Test</h1>

      <div className="space-y-6">
        {/* Connection Test */}
        <Card>
          <CardHeader>
            <CardTitle>Connection Test</CardTitle>
          </CardHeader>
          <CardContent>
            <Button onClick={testConnection} className="mb-4">
              Test API Connection
            </Button>
            {connectionTest && (
              <div className="space-y-2">
                <div>
                  <strong>RapidAPI:</strong>{" "}
                  <span className={connectionTest.rapidApi?.success ? "text-green-600" : "text-red-600"}>
                    {connectionTest.rapidApi?.success ? "✅ Working" : "❌ Failed"}
                  </span>
                  <div className="text-sm text-gray-600">{connectionTest.rapidApi?.details}</div>
                </div>
                <div>
                  <strong>Local Database:</strong>{" "}
                  <span className={connectionTest.local?.success ? "text-green-600" : "text-red-600"}>
                    {connectionTest.local?.success ? "✅ Working" : "❌ Failed"}
                  </span>
                  <div className="text-sm text-gray-600">{connectionTest.local?.details}</div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Search Test */}
        <Card>
          <CardHeader>
            <CardTitle>Search Test</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-2 mb-4">
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Enter search query..."
                onKeyPress={(e) => e.key === "Enter" && testSearch()}
              />
              <Button onClick={testSearch} disabled={loading}>
                {loading ? "Searching..." : "Search"}
              </Button>
            </div>

            <div className="flex flex-wrap gap-2 mb-4">
              <Button
                variant="outline"
                onClick={() => {
                  setQuery("Jesus")
                  testSearchWithQuery("Jesus")
                }}
              >
                Test "Jesus"
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setQuery("love")
                  testSearchWithQuery("love")
                }}
              >
                Test "love"
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setQuery("faith")
                  testSearchWithQuery("faith")
                }}
              >
                Test "faith"
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setQuery("John 3:16")
                  testSearchWithQuery("John 3:16")
                }}
              >
                Test "John 3:16"
              </Button>
            </div>

            {results && (
              <div className="space-y-4">
                <div className="p-3 bg-blue-50 rounded">
                  <strong>Source:</strong> {results.source}
                  <br />
                  <strong>Found:</strong> {results.totalFound} verses
                  <br />
                  <strong>Query:</strong> {results.query}
                </div>

                {results.summary && (
                  <div className="p-3 bg-green-50 rounded">
                    <strong>Summary:</strong> {results.summary}
                  </div>
                )}

                <div className="space-y-2">
                  <strong>Verses:</strong>
                  {results.verses?.map((verse: any, index: number) => (
                    <div key={index} className="p-3 border rounded">
                      <div className="font-semibold text-blue-600">{verse.reference}</div>
                      <div className="mt-1">{verse.text}</div>
                    </div>
                  ))}
                </div>

                {results.error && (
                  <div className="p-3 bg-red-50 text-red-700 rounded">
                    <strong>Error:</strong> {results.error}
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
