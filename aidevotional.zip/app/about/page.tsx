"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Heart, Users, Globe, Target, Lightbulb, Shield } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

const values = [
  {
    icon: Heart,
    title: "Faith-Centered",
    description:
      "Everything we build is rooted in reverence for Scripture and respect for diverse Christian traditions.",
  },
  {
    icon: Users,
    title: "Community-Driven",
    description: "We listen to our users and build features that serve the global Christian community's needs.",
  },
  {
    icon: Shield,
    title: "Trustworthy",
    description: "We maintain the highest standards of biblical accuracy and data security for our users.",
  },
  {
    icon: Globe,
    title: "Accessible",
    description:
      "Making powerful Bible study tools available to everyone, regardless of technical expertise or budget.",
  },
]

const milestones = [
  {
    year: "2023",
    title: "The Vision",
    description: "Founded with the mission to democratize biblical study through AI technology.",
  },
  {
    year: "2024",
    title: "Platform Launch",
    description: "Launched our AI-powered Bible search and devotional generation features.",
  },
  {
    year: "2024",
    title: "Growing Community",
    description: "Reached 10,000+ users across 50+ countries, generating 100,000+ devotionals.",
  },
  {
    year: "2025",
    title: "Future Vision",
    description: "Expanding to support multiple languages and additional Bible translations.",
  },
]

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-amber-200 sticky top-0 z-50">
        <div className="container mx-auto px-2 py-2 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-3">
            <Image src="/logo.png" alt="AI Devotional Logo" width={80} height={80} className="object-contain" />
          </Link>
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/" className="text-slate-700 hover:text-amber-700 transition-colors">
              Home
            </Link>
            <Link href="/features" className="text-slate-700 hover:text-amber-700 transition-colors">
              Features
            </Link>
            <Link href="/about" className="text-amber-700 font-medium">
              About
            </Link>
            <Link href="/get-started" className="text-slate-700 hover:text-amber-700 transition-colors">
              Get Started
            </Link>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-8 bg-gradient-to-br from-blue-50 to-amber-50">
        <div className="container mx-auto px-2">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-5xl font-bold text-slate-800 mb-4">
              Empowering Faith Through
              <span className="text-amber-600"> Technology</span>
            </h1>
            <p className="text-xl text-slate-600 mb-4 leading-relaxed">
              We believe that everyone deserves access to powerful Bible study tools. Our mission is to combine
              cutting-edge AI technology with deep biblical scholarship to create an accessible, meaningful, and
              transformative spiritual experience.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" asChild className="bg-amber-600 hover:bg-amber-700">
                <Link href="/#features">Try Our Platform</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-8">
        <div className="container mx-auto px-2">
          <div className="grid lg:grid-cols-2 gap-6 max-w-6xl mx-auto">
            <Card className="border-amber-200">
              <CardHeader>
                <Target className="w-12 h-12 text-amber-600 mb-2" />
                <CardTitle className="text-2xl">Our Mission</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-700 text-lg leading-relaxed">
                  To democratize biblical study by making advanced AI-powered tools accessible to believers worldwide,
                  regardless of their theological background, technical expertise, or financial resources. We strive to
                  deepen faith and understanding through intelligent, scripture-centered technology.
                </p>
              </CardContent>
            </Card>

            <Card className="border-blue-200">
              <CardHeader>
                <Lightbulb className="w-12 h-12 text-blue-600 mb-2" />
                <CardTitle className="text-2xl">Our Vision</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-700 text-lg leading-relaxed">
                  A world where every believer has access to personalized, intelligent Bible study tools that adapt to
                  their spiritual journey. We envision a global community of faith-seekers connected through technology
                  that enhances rather than replaces the timeless wisdom of Scripture.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-8 bg-slate-50">
        <div className="container mx-auto px-2">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-6">
              <h2 className="text-3xl font-bold text-slate-800 mb-2">Our Story</h2>
              <p className="text-slate-600 text-lg">How AI Devotional came to be</p>
            </div>

            <div className="prose prose-lg max-w-none">
              <div className="bg-white rounded-lg p-4 shadow-sm">
                <p className="text-slate-700 mb-3">
                  AI Devotional was born from a simple observation: while technology has transformed nearly every aspect
                  of our lives, Bible study tools remained largely unchanged for decades. Traditional concordances and
                  study guides, while valuable, often required extensive theological training to use effectively.
                </p>

                <p className="text-slate-700 mb-3">
                  Our founder, Sarah Chen, experienced this firsthand during her seminary studies. Despite having access
                  to extensive libraries and resources, she found that many fellow believers struggled to engage deeply
                  with Scripture due to the complexity of traditional study tools.
                </p>

                <p className="text-slate-700 mb-3">
                  The breakthrough came when artificial intelligence reached a point where it could understand natural
                  language queries and provide contextually relevant biblical insights. We realized we could bridge the
                  gap between advanced biblical scholarship and everyday faith practice.
                </p>

                <p className="text-slate-700">
                  Today, AI Devotional serves thousands of believers worldwide, from new Christians taking their first
                  steps in faith to seasoned theologians seeking fresh perspectives on familiar passages. Our platform
                  continues to evolve, always guided by our commitment to biblical accuracy, accessibility, and the
                  transformative power of God's Word.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-8">
        <div className="container mx-auto px-2">
          <div className="text-center mb-6">
            <h2 className="text-3xl font-bold text-slate-800 mb-2">Our Values</h2>
            <p className="text-slate-600 max-w-2xl mx-auto">
              These core principles guide every decision we make and every feature we build
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 max-w-6xl mx-auto">
            {values.map((value, index) => {
              const IconComponent = value.icon
              return (
                <Card key={index} className="text-center">
                  <CardHeader>
                    <IconComponent className="w-12 h-12 text-amber-600 mx-auto mb-2" />
                    <CardTitle className="text-xl">{value.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-slate-600">{value.description}</p>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-8 bg-slate-800">
        <div className="container mx-auto px-2 text-center">
          <h2 className="text-4xl font-bold text-white mb-4">Join Our Mission</h2>
          <p className="text-xl text-slate-300 mb-4 max-w-2xl mx-auto">
            Be part of a community that's transforming how people engage with Scripture through technology.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" asChild className="bg-amber-600 hover:bg-amber-700">
              <Link href="/#features">Start Your Journey</Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              asChild
              className="border-white text-white hover:bg-white hover:text-slate-800"
            >
              <Link href="/get-started">Learn How to Get Started</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
