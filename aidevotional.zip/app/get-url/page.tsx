"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Copy } from "lucide-react"

export default function GetURL() {
  const [currentURL, setCurrentURL] = useState("")
  const [baseURL, setBaseURL] = useState("")
  const [webhookURL, setWebhookURL] = useState("")

  useEffect(() => {
    if (typeof window !== "undefined") {
      const fullURL = window.location.href
      const base = window.location.origin
      const webhook = `${base}/api/stripe/webhook`

      setCurrentURL(fullURL)
      setBaseURL(base)
      setWebhookURL(webhook)
    }
  }, [])

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    alert("Copied to clipboard!")
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-2xl mx-auto">
        <Card>
          <CardHeader>
            <CardTitle>Your v0 URLs</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Current Full URL:</label>
              <div className="flex items-center gap-2">
                <code className="flex-1 p-2 bg-gray-100 rounded text-sm break-all">{currentURL || "Loading..."}</code>
                <Button size="sm" variant="outline" onClick={() => copyToClipboard(currentURL)} disabled={!currentURL}>
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Base URL (for Stripe CLI):</label>
              <div className="flex items-center gap-2">
                <code className="flex-1 p-2 bg-gray-100 rounded text-sm break-all">{baseURL || "Loading..."}</code>
                <Button size="sm" variant="outline" onClick={() => copyToClipboard(baseURL)} disabled={!baseURL}>
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Webhook URL (for Stripe CLI):</label>
              <div className="flex items-center gap-2">
                <code className="flex-1 p-2 bg-blue-50 rounded text-sm break-all border-2 border-blue-200">
                  {webhookURL || "Loading..."}
                </code>
                <Button size="sm" onClick={() => copyToClipboard(webhookURL)} disabled={!webhookURL}>
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
              <h3 className="font-semibold text-yellow-800 mb-2">How to Use:</h3>
              <ol className="text-sm text-yellow-700 space-y-1">
                <li>1. Copy the "Webhook URL" above</li>
                <li>2. In your terminal, run:</li>
                <li className="font-mono bg-yellow-100 p-2 rounded ml-4">stripe listen --forward-to [WEBHOOK_URL]</li>
                <li>3. Copy the webhook secret and add it to your environment variables</li>
              </ol>
            </div>

            <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
              <h3 className="font-semibold text-blue-800 mb-2">Alternative: Manual Testing</h3>
              <p className="text-sm text-blue-700 mb-2">
                If Stripe CLI doesn't work, you can test the webhook flow manually:
              </p>
              <Button
                onClick={() => (window.location.href = "/test-webhook-manual")}
                variant="outline"
                className="w-full"
              >
                Go to Manual Webhook Test
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
