"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function TestRapidAPIEndpoints() {
  const [results, setResults] = useState<any[]>([])
  const [testing, setTesting] = useState(false)

  const testEndpoints = async () => {
    setTesting(true)
    setResults([])

    const RAPIDAPI_KEY = "4f9153d221msh9e9473de1ec4e29p1732b3jsna37f84ab53e1"
    const RAPIDAPI_HOST = "iq-bible.p.rapidapi.com"
    const BASE_URL = "https://iq-bible.p.rapidapi.com"

    // Test different endpoint patterns
    const endpoints = [
      { name: "GetBooks", url: `${BASE_URL}/GetBooks?language=english` },
      { name: "Books Alt", url: `${BASE_URL}/books` },
      { name: "Search John", url: `${BASE_URL}/search?query=john` },
      { name: "SearchVerses", url: `${BASE_URL}/SearchVerses?query=john&versionId=1` },
      { name: "Verses Search", url: `${BASE_URL}/verses/search?q=john` },
      { name: "GetVerse John 3:16", url: `${BASE_URL}/GetVerse?bookId=43&chapterId=3&verseId=16&versionId=1` },
      { name: "Verse Alt", url: `${BASE_URL}/verse?book=43&chapter=3&verse=16&version=1` },
      { name: "GetChapter John 3", url: `${BASE_URL}/GetChapter?bookId=43&chapterId=3&versionId=1` },
      { name: "Chapter Alt", url: `${BASE_URL}/chapter?book=43&chapter=3&version=1` },
      { name: "Versions", url: `${BASE_URL}/versions` },
      { name: "GetVersions", url: `${BASE_URL}/GetVersions` },
    ]

    for (const endpoint of endpoints) {
      try {
        console.log(`Testing: ${endpoint.name}`)

        const response = await fetch(endpoint.url, {
          method: "GET",
          headers: {
            "X-RapidAPI-Key": RAPIDAPI_KEY,
            "X-RapidAPI-Host": RAPIDAPI_HOST,
          },
        })

        const result = {
          name: endpoint.name,
          url: endpoint.url,
          status: response.status,
          success: response.ok,
          data: null as any,
          error: null as string | null,
        }

        if (response.ok) {
          try {
            const data = await response.json()
            result.data = Array.isArray(data) ? data.slice(0, 3) : data
          } catch (parseError) {
            result.error = "Failed to parse JSON"
          }
        } else {
          result.error = `HTTP ${response.status}: ${response.statusText}`
        }

        setResults((prev) => [...prev, result])

        // Small delay to avoid rate limiting
        await new Promise((resolve) => setTimeout(resolve, 500))
      } catch (error) {
        setResults((prev) => [
          ...prev,
          {
            name: endpoint.name,
            url: endpoint.url,
            status: 0,
            success: false,
            data: null,
            error: error instanceof Error ? error.message : "Network error",
          },
        ])
      }
    }

    setTesting(false)
  }

  return (
    <div className="container mx-auto p-6">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">RapidAPI Endpoint Testing</h1>

        <div className="mb-6">
          <Button onClick={testEndpoints} disabled={testing} className="w-full">
            {testing ? "Testing Endpoints..." : "Test All RapidAPI Endpoints"}
          </Button>
        </div>

        <div className="space-y-4">
          {results.map((result, index) => (
            <Card key={index} className={result.success ? "border-green-500" : "border-red-500"}>
              <CardHeader>
                <CardTitle className="flex justify-between items-center">
                  <span>{result.name}</span>
                  <span
                    className={`px-2 py-1 rounded text-sm ${
                      result.success ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                    }`}
                  >
                    {result.success ? `✅ ${result.status}` : `❌ ${result.status || "Error"}`}
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div>
                    <strong>URL:</strong>
                    <code className="block bg-gray-100 p-2 rounded text-sm mt-1 break-all">{result.url}</code>
                  </div>

                  {result.error && (
                    <div>
                      <strong>Error:</strong>
                      <div className="text-red-600 mt-1">{result.error}</div>
                    </div>
                  )}

                  {result.data && (
                    <div>
                      <strong>Response Data:</strong>
                      <pre className="bg-gray-100 p-2 rounded text-sm mt-1 overflow-auto max-h-40">
                        {JSON.stringify(result.data, null, 2)}
                      </pre>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {results.length > 0 && (
          <div className="mt-6 p-4 bg-blue-50 rounded">
            <h3 className="font-bold mb-2">Summary:</h3>
            <div>✅ Working endpoints: {results.filter((r) => r.success).length}</div>
            <div>❌ Failed endpoints: {results.filter((r) => !r.success).length}</div>
          </div>
        )}
      </div>
    </div>
  )
}
