"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { BookOpen, Heart, Users, GraduationCap, Sparkles, ArrowRight } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import FeatureTabs from "@/components/feature-tabs"
import { AuthButton } from "@/components/auth/auth-button"
import { AuthModal } from "@/components/auth/auth-modal"
import { useAuth } from "@/components/auth/auth-provider"
import { PremiumSignup } from "@/components/premium-signup"

export default function HomePage() {
  const [showAuthModal, setShowAuthModal] = useState(false)
  const { user } = useAuth()

  const handleGetStarted = () => {
    // Always scroll to features since they're now free
    document.getElementById("features")?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-amber-50">
      {/* Header */}
      <header className="bg-white/90 backdrop-blur-md border-b border-amber-200/50 sticky top-0 z-50 shadow-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <Image src="/logo.png" alt="AI Devotional Logo" width={100} height={100} className="object-contain" />
            </div>
          </div>
          <nav className="hidden md:flex items-center space-x-6">
            <Link
              href="/features"
              className="text-slate-700 hover:text-amber-700 transition-colors font-medium hover:scale-105 transform duration-200"
            >
              Features
            </Link>
            <Link
              href="/about"
              className="text-slate-700 hover:text-amber-700 transition-colors font-medium hover:scale-105 transform duration-200"
            >
              About
            </Link>
            <Link
              href="/complete-devotional"
              className="text-slate-700 hover:text-amber-700 transition-colors font-medium hover:scale-105 transform duration-200"
            >
              Complete Devotional
            </Link>
            <Link
              href="/prayer-list"
              className="text-slate-700 hover:text-amber-700 transition-colors font-medium hover:scale-105 transform duration-200"
            >
              Prayer List
            </Link>
            <Link
              href="/reading-plan"
              className="text-slate-700 hover:text-amber-700 transition-colors font-medium hover:scale-105 transform duration-200"
            >
              Reading Plan
            </Link>
            <AuthButton />
            <Button
              asChild
              className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
            >
              <Link href="/get-started">{user ? "Explore Features" : "Get Started"}</Link>
            </Button>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-6 container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center mb-12">
          <h1 className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-slate-800 via-slate-700 to-amber-700 bg-clip-text text-transparent mb-8 leading-tight">
            Deepen Your Faith Journey
          </h1>
        </div>

        <div className="relative overflow-hidden rounded-2xl shadow-2xl mb-12 group">
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent z-10"></div>
          <Image
            src="/hero-crosses.png"
            alt="Three crosses at sunset"
            width={1200}
            height={600}
            className="w-full h-auto object-cover group-hover:scale-105 transition-transform duration-700"
            priority
          />
          <div className="absolute bottom-6 left-6 z-20 text-white">
            <div className="bg-white/20 backdrop-blur-sm rounded-lg p-4 border border-white/30">
              <p className="font-medium">Experience scripture like never before</p>
            </div>
          </div>
        </div>

        <div className="max-w-4xl mx-auto text-center">
          <p className="text-xl md:text-2xl text-slate-700 mb-10 leading-relaxed">
            Experience scripture like never before with intelligent verse search, comprehensive concordance, and
            personalized devotional outlines—all completely <span className="font-bold text-amber-600">free</span>. No
            sign-up required!
          </p>

          {/* Main CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
            <Button
              size="lg"
              onClick={handleGetStarted}
              className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white px-10 py-4 text-lg shadow-xl hover:shadow-2xl transform hover:scale-105 transition-all duration-300 group"
            >
              Start Exploring Free
              <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => setShowAuthModal(true)}
              className="border-2 border-amber-600 text-amber-600 hover:bg-gradient-to-r hover:from-amber-600 hover:to-orange-600 hover:text-white px-10 py-4 text-lg shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
            >
              Sign In for Premium
            </Button>
          </div>

          <div className="inline-flex items-center gap-2 bg-white/80 backdrop-blur-sm text-slate-600 px-4 py-2 rounded-full text-sm border border-slate-200 shadow-sm">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            All core features are free forever • Premium features available with sign-in
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-16 bg-gradient-to-br from-white to-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-100 to-indigo-100 text-blue-800 px-4 py-2 rounded-full text-sm font-medium mb-6 border border-blue-200">
              <BookOpen className="w-4 h-4" />
              Free Bible Study Tools
            </div>
            <h2 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-slate-800 to-blue-700 bg-clip-text text-transparent mb-6">
              Free Bible Study Tools
            </h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              Powerful AI-powered tools available to everyone, no sign-up required
            </p>
          </div>

          {/* Feature Cards */}
          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto mb-20">
            <div className="group text-center bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100">
              <div className="w-20 h-20 bg-gradient-to-r from-amber-400 to-orange-500 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                <BookOpen className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-xl font-bold text-amber-700 mb-4">AI Bible Search</h3>
              <p className="text-slate-600 leading-relaxed">
                Ask questions in natural language and find relevant verses instantly with AI-powered understanding.
              </p>
            </div>

            <div className="group text-center bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100">
              <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                <BookOpen className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-xl font-bold text-blue-600 mb-4">Smart Concordance</h3>
              <p className="text-slate-600 leading-relaxed">
                Discover all verses related to any word or concept with contextual explanations and thematic
                connections.
              </p>
            </div>

            <div className="group text-center bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100">
              <div className="w-20 h-20 bg-gradient-to-r from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                <Heart className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-xl font-bold text-green-600 mb-4">Devotional Outlines</h3>
              <p className="text-slate-600 leading-relaxed">
                Generate structured devotional studies on any topic with reflective questions and practical
                applications.
              </p>
            </div>
          </div>

          {/* Interactive Feature Tabs */}
          <div className="max-w-7xl mx-auto">
            <FeatureTabs />
          </div>
        </div>
      </section>

      {/* Target Audience Section */}
      <section className="py-16 bg-gradient-to-br from-amber-50 to-orange-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 bg-gradient-to-r from-amber-100 to-orange-100 text-amber-800 px-4 py-2 rounded-full text-sm font-medium mb-6 border border-amber-200">
              <Users className="w-4 h-4" />
              For Every Believer
            </div>
            <h2 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-slate-800 to-amber-700 bg-clip-text text-transparent mb-6">
              Designed for Every Believer
            </h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              Whether you're just beginning your faith journey or deepening your study, AI Devotional meets you where
              you are
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <div className="group text-center bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100">
              <div className="w-20 h-20 bg-gradient-to-r from-pink-400 to-red-500 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                <Heart className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-slate-800 mb-4">General Public</h3>
              <p className="text-slate-600 text-lg leading-relaxed">
                Accessible tools for anyone seeking to grow in their faith and understanding of scripture
              </p>
            </div>

            <div className="group text-center bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100">
              <div className="w-20 h-20 bg-gradient-to-r from-purple-500 to-indigo-600 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                <GraduationCap className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-slate-800 mb-4">Students</h3>
              <p className="text-slate-600 text-lg leading-relaxed">
                Perfect for seminary students, Bible college attendees, and academic researchers
              </p>
            </div>

            <div className="group text-center bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100">
              <div className="w-20 h-20 bg-gradient-to-r from-teal-500 to-cyan-600 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                <Users className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-slate-800 mb-4">Hobbyists</h3>
              <p className="text-slate-600 text-lg leading-relaxed">
                Ideal for those who love diving deep into biblical study as a personal passion
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Premium Signup Section */}
      <section id="premium-signup" className="py-16 bg-gradient-to-br from-amber-50 to-orange-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-slate-800 to-amber-700 bg-clip-text text-transparent mb-6">
              Ready for Premium?
            </h2>
            <p className="text-xl text-slate-600 max-w-2xl mx-auto">
              Unlock complete devotionals, prayer lists, reading plans, and more with one simple step.
            </p>
          </div>
          <PremiumSignup />
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-slate-800 via-slate-700 to-slate-800 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-slate-800/50 to-slate-900/50 opacity-20"></div>
        <div className="container mx-auto px-4 text-center relative z-10">
          <div className="max-w-4xl mx-auto">
            <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm text-white px-4 py-2 rounded-full text-sm font-medium mb-6 border border-white/20">
              <Sparkles className="w-4 h-4" />
              Start Your Journey Today
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">Ready to Explore Scripture?</h2>
            <p className="text-xl text-slate-300 mb-10 max-w-2xl mx-auto leading-relaxed">
              Start using our free Bible study tools right now, or sign in to unlock premium features and save your
              progress.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button
                size="lg"
                onClick={handleGetStarted}
                className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white px-10 py-4 text-lg shadow-2xl hover:shadow-amber-500/25 transform hover:scale-105 transition-all duration-300 group"
              >
                Use Free Tools Now
                <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() => setShowAuthModal(true)}
                className="border-2 border-white text-white hover:bg-white hover:text-slate-800 px-10 py-4 text-lg shadow-xl hover:shadow-2xl transform hover:scale-105 transition-all duration-300"
              >
                Sign In for Premium
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-br from-slate-900 to-slate-800 text-slate-300 py-12 border-t border-slate-700">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-6">
                <div className="relative">
                  <Image src="/logo.png" alt="AI Devotional Logo" width={80} height={80} className="object-contain" />
                </div>
                <span className="text-xl font-bold text-white">AI Devotional</span>
              </div>
              <p className="text-slate-400 leading-relaxed">
                Empowering your spiritual journey with AI-powered Bible study tools.
              </p>
            </div>

            <div>
              <h4 className="text-white font-bold mb-6 text-lg">Features</h4>
              <ul className="space-y-3">
                <li>
                  <Link
                    href="/features"
                    className="hover:text-amber-400 transition-colors duration-200 flex items-center gap-2 group"
                  >
                    <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                    Verse Search
                  </Link>
                </li>
                <li>
                  <Link
                    href="/features"
                    className="hover:text-amber-400 transition-colors duration-200 flex items-center gap-2 group"
                  >
                    <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                    Concordance
                  </Link>
                </li>
                <li>
                  <Link
                    href="/features"
                    className="hover:text-amber-400 transition-colors duration-200 flex items-center gap-2 group"
                  >
                    <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                    AI Devotionals
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-bold mb-6 text-lg">Support</h4>
              <ul className="space-y-3">
                <li>
                  <Link
                    href="/get-started"
                    className="hover:text-amber-400 transition-colors duration-200 flex items-center gap-2 group"
                  >
                    <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                    Help Center
                  </Link>
                </li>
                <li>
                  <Link
                    href="/about"
                    className="hover:text-amber-400 transition-colors duration-200 flex items-center gap-2 group"
                  >
                    <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                    Contact Us
                  </Link>
                </li>
                <li>
                  <Link
                    href="#"
                    className="hover:text-amber-400 transition-colors duration-200 flex items-center gap-2 group"
                  >
                    <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                    Privacy Policy
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-bold mb-6 text-lg">Connect</h4>
              <ul className="space-y-3">
                <li>
                  <Link
                    href="#"
                    className="hover:text-amber-400 transition-colors duration-200 flex items-center gap-2 group"
                  >
                    <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                    Newsletter
                  </Link>
                </li>
                <li>
                  <Link
                    href="#"
                    className="hover:text-amber-400 transition-colors duration-200 flex items-center gap-2 group"
                  >
                    <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                    Community
                  </Link>
                </li>
                <li>
                  <Link
                    href="#"
                    className="hover:text-amber-400 transition-colors duration-200 flex items-center gap-2 group"
                  >
                    <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                    Blog
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-slate-700 mt-12 pt-8 text-center">
            <div className="flex items-center justify-center gap-2 mb-4">
              <div className="w-2 h-2 bg-amber-500 rounded-full animate-pulse"></div>
              <p className="text-slate-400">
                © 2024 AI Devotional. All rights reserved. Built with faith and technology.
              </p>
            </div>
          </div>
        </div>
      </footer>

      {/* Auth Modal */}
      <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />
    </div>
  )
}
