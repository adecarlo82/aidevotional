"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function TestTextSearchPage() {
  const [query, setQuery] = useState("love")
  const [results, setResults] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const testRapidAPISearch = async () => {
    setLoading(true)
    setError(null)
    setResults(null)

    try {
      console.log(`🧪 Testing RapidAPI GetSearch for: "${query}"`)

      const response = await fetch("/api/test/rapidapi-text-search", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ query }),
      })

      const data = await response.json()
      console.log(`📊 RapidAPI test results:`, data)

      if (!response.ok) {
        throw new Error(data.error || "RapidAPI test failed")
      }

      setResults(data)
    } catch (err) {
      console.error("❌ RapidAPI test error:", err)
      setError(err instanceof Error ? err.message : "Unknown error")
    } finally {
      setLoading(false)
    }
  }

  const testLocalSearch = async () => {
    setLoading(true)
    setError(null)
    setResults(null)

    try {
      console.log(`🧪 Testing Local Database search for: "${query}"`)

      const response = await fetch("/api/test/local-text-search", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ query }),
      })

      const data = await response.json()
      console.log(`📊 Local search results:`, data)

      if (!response.ok) {
        throw new Error(data.error || "Local search test failed")
      }

      setResults(data)
    } catch (err) {
      console.error("❌ Local search test error:", err)
      setError(err instanceof Error ? err.message : "Unknown error")
    } finally {
      setLoading(false)
    }
  }

  const testCurrentSystem = async () => {
    setLoading(true)
    setError(null)
    setResults(null)

    try {
      console.log(`🧪 Testing Current Verse Search for: "${query}"`)

      const response = await fetch("/api/ai/search-verses", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ query }),
      })

      const data = await response.json()
      console.log(`📊 Current system results:`, data)

      if (!response.ok) {
        throw new Error(data.error || "Current system test failed")
      }

      setResults(data)
    } catch (err) {
      console.error("❌ Current system test error:", err)
      setError(err instanceof Error ? err.message : "Unknown error")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto p-6 max-w-6xl">
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Text Search Diagnosis</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-3">
            <Input
              type="text"
              placeholder="Enter search term (e.g., love, faith, hope)"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="flex-1"
            />
          </div>

          <div className="flex gap-3 flex-wrap">
            <Button onClick={testRapidAPISearch} disabled={loading} variant="outline">
              {loading ? "Testing..." : "Test RapidAPI GetSearch"}
            </Button>
            <Button onClick={testLocalSearch} disabled={loading} variant="outline">
              {loading ? "Testing..." : "Test Local Database"}
            </Button>
            <Button onClick={testCurrentSystem} disabled={loading}>
              {loading ? "Testing..." : "Test Current System"}
            </Button>
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <h3 className="font-semibold text-red-800">Error:</h3>
              <p className="text-red-700 font-mono text-sm">{error}</p>
            </div>
          )}

          {results && (
            <div className="space-y-4">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h3 className="font-semibold text-blue-800">Test Results:</h3>
                <pre className="text-sm text-blue-700 mt-2 overflow-auto max-h-96">
                  {JSON.stringify(results, null, 2)}
                </pre>
              </div>

              {results.verses && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <h3 className="font-semibold text-green-800">Found Verses ({results.verses.length}):</h3>
                  <div className="space-y-2 mt-2">
                    {results.verses.slice(0, 5).map((verse: any, index: number) => (
                      <div key={index} className="border-l-4 border-green-500 pl-3">
                        <p className="font-medium text-green-700">{verse.reference}</p>
                        <p className="text-green-600 text-sm italic">"{verse.text}"</p>
                      </div>
                    ))}
                    {results.verses.length > 5 && (
                      <p className="text-green-600 text-sm">... and {results.verses.length - 5} more verses</p>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
            <h3 className="font-semibold text-gray-800">Diagnosis Instructions:</h3>
            <ol className="text-sm text-gray-700 mt-2 space-y-1">
              <li>1. Test "RapidAPI GetSearch" to verify the API works for text searches</li>
              <li>2. Test "Local Database" to check fallback search capabilities</li>
              <li>3. Test "Current System" to see the full verse search flow</li>
              <li>4. Check browser console for detailed logs and error messages</li>
              <li>5. Try different search terms: "love", "faith", "hope", "peace"</li>
            </ol>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
