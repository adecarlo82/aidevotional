"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { CheckCircle, Mail, Sparkles } from "lucide-react"
import Link from "next/link"
import { useSearchParams } from "next/navigation"

export default function WelcomePage() {
  const [email, setEmail] = useState("")
  const [magicLinkSent, setMagicLinkSent] = useState(false)
  const [loading, setLoading] = useState(false)
  const searchParams = useSearchParams()
  const sessionId = searchParams.get("session_id")

  const sendMagicLink = async () => {
    if (!email) return

    try {
      setLoading(true)
      const { supabase } = await import("@/lib/supabase")

      const { error } = await supabase.auth.signInWithOtp({
        email: email,
        options: {
          emailRedirectTo: `${window.location.origin}/dashboard?welcome=true`,
        },
      })

      if (error) throw error

      setMagicLinkSent(true)
    } catch (error) {
      console.error("Error sending magic link:", error)
      alert("Failed to send magic link. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-amber-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-lg border-green-200 shadow-xl">
        <CardHeader className="text-center">
          <div className="w-20 h-20 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-10 h-10 text-white" />
          </div>
          <CardTitle className="text-3xl text-slate-800 mb-2">Welcome to Premium!</CardTitle>
          <p className="text-slate-600">
            Your payment was successful. Let's get you signed in to access your premium features.
          </p>
        </CardHeader>

        <CardContent className="space-y-6">
          {!magicLinkSent ? (
            <>
              <div className="space-y-4">
                <div className="flex items-center gap-3 p-3 bg-amber-50 rounded-lg border border-amber-200">
                  <Sparkles className="w-5 h-5 text-amber-600" />
                  <span className="text-amber-800 font-medium">Premium features are now active!</span>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Enter your email to receive a sign-in link:
                  </label>
                  <Input
                    type="email"
                    placeholder="your@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full"
                  />
                </div>

                <Button
                  onClick={sendMagicLink}
                  disabled={!email || loading}
                  className="w-full bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700"
                >
                  {loading ? "Sending..." : "Send Sign-In Link"}
                </Button>
              </div>
            </>
          ) : (
            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full flex items-center justify-center mx-auto">
                <Mail className="w-8 h-8 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-slate-800 mb-2">Check Your Email!</h3>
                <p className="text-slate-600">
                  We've sent a magic sign-in link to <strong>{email}</strong>
                </p>
                <p className="text-sm text-slate-500 mt-2">
                  Click the link in your email to access your premium account.
                </p>
              </div>
            </div>
          )}

          <div className="border-t pt-4">
            <p className="text-center text-sm text-slate-500">
              Need help?{" "}
              <Link href="/about" className="text-amber-600 hover:underline">
                Contact support
              </Link>
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
