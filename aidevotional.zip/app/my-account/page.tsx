"use client"

import { useAuth } from "@/components/auth/auth-provider"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { User, CreditCard, Settings, LogOut } from "lucide-react"
import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"

interface SubscriptionInfo {
  hasActiveSubscription: boolean
  plan?: string
  status?: string
  currentPeriodEnd?: string
}

export default function MyAccountPage() {
  const { user, signOut, loading } = useAuth()
  const router = useRouter()
  const [subscriptionInfo, setSubscriptionInfo] = useState<SubscriptionInfo | null>(null)
  const [loadingSubscription, setLoadingSubscription] = useState(true)

  useEffect(() => {
    if (!loading && !user) {
      router.push("/")
      return
    }

    if (user) {
      fetchSubscriptionInfo()
    }
  }, [user, loading, router])

  const fetchSubscriptionInfo = async () => {
    try {
      const response = await fetch("/api/user/subscription")
      const data = await response.json()
      setSubscriptionInfo(data)
    } catch (error) {
      console.error("Error fetching subscription info:", error)
    } finally {
      setLoadingSubscription(false)
    }
  }

  const handleManageSubscription = async () => {
    try {
      const response = await fetch("/api/stripe/portal", {
        method: "POST",
      })
      const { url } = await response.json()
      window.location.href = url
    } catch (error) {
      console.error("Error accessing customer portal:", error)
    }
  }

  const handleUpgrade = async () => {
    try {
      const response = await fetch("/api/stripe/checkout", {
        method: "POST",
      })
      const { url } = await response.json()
      window.location.href = url
    } catch (error) {
      console.error("Error starting checkout:", error)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-amber-600 mx-auto"></div>
          <p className="mt-2 text-slate-600">Loading...</p>
        </div>
      </div>
    )
  }

  if (!user) {
    return null
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-slate-800">My Account</h1>
            <Button variant="outline" onClick={() => router.push("/")}>
              Back to Home
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="grid gap-6">
          {/* Profile Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="w-5 h-5" />
                Profile Information
              </CardTitle>
              <CardDescription>Your account details and preferences</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-slate-700">Email Address</label>
                  <p className="text-slate-900">{user.email}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-slate-700">Account Created</label>
                  <p className="text-slate-600">{new Date(user.created_at).toLocaleDateString()}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Subscription Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="w-5 h-5" />
                Subscription
              </CardTitle>
              <CardDescription>Manage your subscription and billing</CardDescription>
            </CardHeader>
            <CardContent>
              {loadingSubscription ? (
                <div className="flex items-center gap-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-amber-600"></div>
                  <span className="text-slate-600">Loading subscription info...</span>
                </div>
              ) : subscriptionInfo?.hasActiveSubscription ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-green-600">Premium Subscription Active</p>
                      <p className="text-sm text-slate-600">$4.99/month</p>
                      {subscriptionInfo.currentPeriodEnd && (
                        <p className="text-sm text-slate-500">
                          Next billing: {new Date(subscriptionInfo.currentPeriodEnd).toLocaleDateString()}
                        </p>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <Button onClick={handleManageSubscription} variant="outline">
                        Manage Subscription
                      </Button>
                    </div>
                  </div>
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <h4 className="font-medium text-green-800 mb-2">Premium Features Unlocked:</h4>
                    <ul className="text-sm text-green-700 space-y-1">
                      <li>• Complete AI-generated devotionals</li>
                      <li>• Personal prayer list management</li>
                      <li>• Structured Bible reading plans</li>
                      <li>• Save and export your content</li>
                    </ul>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div>
                    <p className="font-medium text-slate-700">Free Account</p>
                    <p className="text-sm text-slate-600">You have access to our free Bible study tools</p>
                  </div>
                  <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                    <h4 className="font-medium text-amber-800 mb-2">Upgrade to Premium for:</h4>
                    <ul className="text-sm text-amber-700 space-y-1 mb-4">
                      <li>• Complete AI-generated devotionals</li>
                      <li>• Personal prayer list management</li>
                      <li>• Structured Bible reading plans</li>
                      <li>• Save and export your content</li>
                    </ul>
                    <Button onClick={handleUpgrade} className="bg-amber-600 hover:bg-amber-700">
                      Upgrade to Premium - $4.99/month
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="w-5 h-5" />
                Quick Actions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-3">
                <Button variant="outline" onClick={() => router.push("/features")} className="justify-start">
                  Explore Free Features
                </Button>
                {subscriptionInfo?.hasActiveSubscription && (
                  <>
                    <Button
                      variant="outline"
                      onClick={() => router.push("/complete-devotional")}
                      className="justify-start"
                    >
                      Generate Complete Devotional
                    </Button>
                    <Button variant="outline" onClick={() => router.push("/prayer-list")} className="justify-start">
                      Manage Prayer List
                    </Button>
                    <Button variant="outline" onClick={() => router.push("/reading-plan")} className="justify-start">
                      Bible Reading Plan
                    </Button>
                  </>
                )}
                <Button
                  variant="outline"
                  onClick={signOut}
                  className="justify-start text-red-600 hover:text-red-700 hover:bg-red-50"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Sign Out
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
