"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle, XCircle, Clock, AlertTriangle } from "lucide-react"

interface TestResult {
  name: string
  status: "pending" | "success" | "error" | "warning"
  message: string
  data?: any
  timing?: number
}

export default function TestRapidAPIStatusPage() {
  const [tests, setTests] = useState<TestResult[]>([])
  const [isRunning, setIsRunning] = useState(false)

  const updateTest = (name: string, status: TestResult["status"], message: string, data?: any, timing?: number) => {
    setTests((prev) => {
      const existing = prev.find((t) => t.name === name)
      if (existing) {
        existing.status = status
        existing.message = message
        existing.data = data
        existing.timing = timing
        return [...prev]
      }
      return [...prev, { name, status, message, data, timing }]
    })
  }

  const runRapidAPITests = async () => {
    setIsRunning(true)
    setTests([])

    const testEndpoints = [
      {
        name: "GetBooks Endpoint",
        url: "https://iq-bible.p.rapidapi.com/GetBooks?language=english",
        description: "Test basic API connectivity",
      },
      {
        name: "SearchVerses - John 3:16",
        url: "https://iq-bible.p.rapidapi.com/SearchVerses?query=John 3:16&versionId=1",
        description: "Test verse search functionality",
      },
      {
        name: "SearchVerses - Love",
        url: "https://iq-bible.p.rapidapi.com/SearchVerses?query=love&versionId=1",
        description: "Test keyword search",
      },
      {
        name: "GetChapter - John 3",
        url: "https://iq-bible.p.rapidapi.com/GetChapter?bookId=43&chapterId=3&versionId=1",
        description: "Test chapter retrieval",
      },
      {
        name: "GetVerse - John 3:16",
        url: "https://iq-bible.p.rapidapi.com/GetVerse?bookId=43&chapterId=3&verseId=16&versionId=1",
        description: "Test specific verse retrieval",
      },
    ]

    for (const test of testEndpoints) {
      updateTest(test.name, "pending", `Testing ${test.description}...`)

      const startTime = Date.now()

      try {
        console.log(`🧪 Testing ${test.name}: ${test.url}`)

        const response = await fetch(test.url, {
          method: "GET",
          headers: {
            "X-RapidAPI-Key": "4f9153d221msh9e9473de1ec4e29p1732b3jsna37f84ab53e1",
            "X-RapidAPI-Host": "iq-bible.p.rapidapi.com",
          },
        })

        const timing = Date.now() - startTime

        console.log(`📊 ${test.name} Response Status: ${response.status}`)

        if (!response.ok) {
          updateTest(test.name, "error", `HTTP ${response.status}: ${response.statusText}`, null, timing)
          continue
        }

        const data = await response.json()
        console.log(`📊 ${test.name} Response Data:`, data)

        // Validate response based on endpoint
        if (test.name.includes("GetBooks")) {
          if (Array.isArray(data) && data.length > 0) {
            updateTest(test.name, "success", `Found ${data.length} books`, data.slice(0, 3), timing)
          } else {
            updateTest(test.name, "warning", "No books returned", data, timing)
          }
        } else if (test.name.includes("SearchVerses")) {
          if (Array.isArray(data) && data.length > 0) {
            const hasText = data.some((item) => item.t || item.text)
            if (hasText) {
              updateTest(test.name, "success", `Found ${data.length} verses with text`, data.slice(0, 2), timing)
            } else {
              updateTest(
                test.name,
                "warning",
                `Found ${data.length} verses but no text content`,
                data.slice(0, 2),
                timing,
              )
            }
          } else {
            updateTest(test.name, "error", "No verses returned", data, timing)
          }
        } else if (test.name.includes("GetChapter")) {
          if (Array.isArray(data) && data.length > 0) {
            const hasVerses = data.some((item) => item.t || item.text)
            if (hasVerses) {
              updateTest(test.name, "success", `Found ${data.length} verses in chapter`, data.slice(0, 3), timing)
            } else {
              updateTest(test.name, "warning", `Found ${data.length} items but no verse text`, data.slice(0, 3), timing)
            }
          } else {
            updateTest(test.name, "error", "No chapter data returned", data, timing)
          }
        } else if (test.name.includes("GetVerse")) {
          if (data && (data.t || data.text)) {
            updateTest(test.name, "success", "Verse retrieved successfully", data, timing)
          } else {
            updateTest(test.name, "error", "No verse text returned", data, timing)
          }
        }
      } catch (error) {
        const timing = Date.now() - startTime
        console.error(`❌ ${test.name} Error:`, error)
        updateTest(
          test.name,
          "error",
          `Network error: ${error instanceof Error ? error.message : "Unknown error"}`,
          null,
          timing,
        )
      }

      // Small delay between requests
      await new Promise((resolve) => setTimeout(resolve, 500))
    }

    setIsRunning(false)
  }

  const getStatusIcon = (status: TestResult["status"]) => {
    switch (status) {
      case "success":
        return <CheckCircle className="w-5 h-5 text-green-500" />
      case "error":
        return <XCircle className="w-5 h-5 text-red-500" />
      case "warning":
        return <AlertTriangle className="w-5 h-5 text-yellow-500" />
      case "pending":
        return <Clock className="w-5 h-5 text-blue-500 animate-pulse" />
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-6xl mx-auto">
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>RapidAPI Bible Service Status Test</CardTitle>
            <p className="text-slate-600">Testing all RapidAPI endpoints to verify functionality and identify issues</p>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4 mb-6">
              <Button onClick={runRapidAPITests} disabled={isRunning}>
                {isRunning ? "Running Tests..." : "Test All RapidAPI Endpoints"}
              </Button>
              <Button variant="outline" onClick={() => (window.location.href = "/")}>
                Back to Home
              </Button>
            </div>

            {tests.length > 0 && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Test Results</h3>
                {tests.map((test, index) => (
                  <Card key={index}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-3">
                          {getStatusIcon(test.status)}
                          <span className="font-medium">{test.name}</span>
                        </div>
                        {test.timing && <span className="text-xs text-slate-500">{test.timing}ms</span>}
                      </div>
                      <p className="text-sm text-slate-600 mb-2">{test.message}</p>
                      {test.data && (
                        <details className="mt-2">
                          <summary className="text-xs text-slate-400 cursor-pointer">View Response Data</summary>
                          <pre className="text-xs bg-slate-100 p-2 rounded mt-1 overflow-auto max-h-40">
                            {JSON.stringify(test.data, null, 2)}
                          </pre>
                        </details>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}

            <div className="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h4 className="font-semibold text-blue-800 mb-2">What This Test Checks:</h4>
              <ul className="text-sm text-blue-700 space-y-1">
                <li>
                  • <strong>GetBooks:</strong> Basic API connectivity and authentication
                </li>
                <li>
                  • <strong>SearchVerses:</strong> Verse search functionality with specific references and keywords
                </li>
                <li>
                  • <strong>GetChapter:</strong> Chapter-level data retrieval
                </li>
                <li>
                  • <strong>GetVerse:</strong> Individual verse retrieval
                </li>
                <li>
                  • <strong>Response Format:</strong> Validates that responses contain expected text content
                </li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
