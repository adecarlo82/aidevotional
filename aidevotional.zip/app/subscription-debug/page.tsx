"use client"

import { useAuth } from "@/components/auth/auth-provider"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useEffect, useState } from "react"
import { supabase } from "@/lib/supabase"

export default function SubscriptionDebugPage() {
  const { user, loading } = useAuth()
  const [debugData, setDebugData] = useState<any>(null)
  const [loadingDebug, setLoadingDebug] = useState(false)

  const runDebug = async () => {
    if (!user) return

    setLoadingDebug(true)
    try {
      // Get session for auth token
      const {
        data: { session },
      } = await supabase.auth.getSession()

      console.log("🔍 Running subscription debug for:", user.email)

      // Test the subscription API
      const response = await fetch("/api/user/subscription", {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${session?.access_token}`,
        },
      })

      const subscriptionData = await response.json()

      // Also test the debug endpoint
      const debugResponse = await fetch("/api/debug/subscription")
      const debugEndpointData = await debugResponse.json()

      setDebugData({
        user: {
          id: user.id,
          email: user.email,
          created_at: user.created_at,
        },
        session: {
          hasAccessToken: !!session?.access_token,
          tokenLength: session?.access_token?.length || 0,
        },
        subscriptionAPI: {
          status: response.status,
          data: subscriptionData,
        },
        debugAPI: {
          status: debugResponse.status,
          data: debugEndpointData,
        },
        timestamp: new Date().toISOString(),
      })
    } catch (error) {
      console.error("Debug error:", error)
      setDebugData({
        error: error instanceof Error ? error.message : "Unknown error",
        timestamp: new Date().toISOString(),
      })
    } finally {
      setLoadingDebug(false)
    }
  }

  useEffect(() => {
    if (user && !loading) {
      runDebug()
    }
  }, [user, loading])

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-amber-600 mx-auto"></div>
          <p className="mt-2 text-slate-600">Loading...</p>
        </div>
      </div>
    )
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="text-center py-8">
            <p className="text-slate-600 mb-4">Please sign in to debug your subscription</p>
            <Button onClick={() => (window.location.href = "/")}>Go to Home</Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-4xl mx-auto">
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Subscription Debug Tool</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4 mb-4">
              <Button onClick={runDebug} disabled={loadingDebug}>
                {loadingDebug ? "Running Debug..." : "Refresh Debug Info"}
              </Button>
              <Button variant="outline" onClick={() => (window.location.href = "/")}>
                Back to Home
              </Button>
            </div>

            {debugData && (
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold mb-2">User Information</h3>
                  <pre className="bg-slate-100 p-3 rounded text-sm overflow-auto">
                    {JSON.stringify(debugData.user, null, 2)}
                  </pre>
                </div>

                <div>
                  <h3 className="font-semibold mb-2">Session Information</h3>
                  <pre className="bg-slate-100 p-3 rounded text-sm overflow-auto">
                    {JSON.stringify(debugData.session, null, 2)}
                  </pre>
                </div>

                <div>
                  <h3 className="font-semibold mb-2">Subscription API Response</h3>
                  <pre className="bg-slate-100 p-3 rounded text-sm overflow-auto max-h-96">
                    {JSON.stringify(debugData.subscriptionAPI, null, 2)}
                  </pre>
                </div>

                <div>
                  <h3 className="font-semibold mb-2">Debug API Response</h3>
                  <pre className="bg-slate-100 p-3 rounded text-sm overflow-auto max-h-96">
                    {JSON.stringify(debugData.debugAPI, null, 2)}
                  </pre>
                </div>

                {debugData.error && (
                  <div>
                    <h3 className="font-semibold mb-2 text-red-600">Error</h3>
                    <pre className="bg-red-50 p-3 rounded text-sm text-red-700">{debugData.error}</pre>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
