"use client"

import { TestWorkflow } from "@/components/test-workflow"

export default function TestPage() {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container mx-auto px-4">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">AI Devotional Test Suite</h1>
          <p className="text-gray-600">Comprehensive testing of all app features and integrations</p>
        </div>

        <TestWorkflow />

        <div className="mt-12 max-w-4xl mx-auto">
          <h2 className="text-2xl font-bold mb-6">Manual Testing Checklist</h2>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="font-semibold text-green-600 mb-4">✅ Free Features</h3>
              <ul className="space-y-2 text-sm">
                <li>• Bible verse search works without login</li>
                <li>• Concordance search returns results</li>
                <li>• Devotional generation works</li>
                <li>• All features accessible to anonymous users</li>
              </ul>
            </div>

            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="font-semibold text-blue-600 mb-4">🔐 Premium Features</h3>
              <ul className="space-y-2 text-sm">
                <li>• User registration and login</li>
                <li>• Stripe checkout integration</li>
                <li>• Subscription management portal</li>
                <li>• Webhook processing</li>
              </ul>
            </div>
          </div>

          <div className="mt-8 bg-white p-6 rounded-lg shadow">
            <h3 className="font-semibold text-purple-600 mb-4">🧪 Stripe Test Cards</h3>
            <div className="grid md:grid-cols-3 gap-4 text-sm">
              <div>
                <strong>Success:</strong>
                <br />
                4242 4242 4242 4242
              </div>
              <div>
                <strong>Declined:</strong>
                <br />
                4000 0000 0000 0002
              </div>
              <div>
                <strong>3D Secure:</strong>
                <br />
                4000 0025 0000 3155
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
