"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function TestExactVerse() {
  const [reference, setReference] = useState("John 3:16")
  const [result, setResult] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const getExactVerse = async () => {
    setLoading(true)
    setError(null)

    try {
      const { rapidApiVerse } = await import("@/lib/rapidapi-verse")
      const verse = await rapidApiVerse.getExactVerse(reference)

      setResult(verse)
      if (!verse) {
        setError(`No verse found for "${reference}"`)
      }
    } catch (err) {
      console.error("Error getting verse:", err)
      setError(err instanceof Error ? err.message : "Unknown error")
      setResult(null)
    } finally {
      setLoading(false)
    }
  }

  const testCommonVerses = async (testReference: string) => {
    setReference(testReference)
    setLoading(true)
    setError(null)

    try {
      const { rapidApiVerse } = await import("@/lib/rapidapi-verse")
      const verse = await rapidApiVerse.getExactVerse(testReference)

      setResult(verse)
      if (!verse) {
        setError(`No verse found for "${testReference}"`)
      }
    } catch (err) {
      console.error("Error getting verse:", err)
      setError(err instanceof Error ? err.message : "Unknown error")
      setResult(null)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto p-6 max-w-2xl">
      <h1 className="text-3xl font-bold mb-6">RapidAPI Exact Verse Test</h1>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Get Exact Verse</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2 mb-4">
            <Input
              value={reference}
              onChange={(e) => setReference(e.target.value)}
              placeholder="Enter verse reference (e.g., John 3:16)"
              onKeyPress={(e) => e.key === "Enter" && getExactVerse()}
            />
            <Button onClick={getExactVerse} disabled={loading}>
              {loading ? "Loading..." : "Get Verse"}
            </Button>
          </div>

          <div className="flex flex-wrap gap-2 mb-4">
            <Button variant="outline" onClick={() => testCommonVerses("John 3:16")}>
              John 3:16
            </Button>
            <Button variant="outline" onClick={() => testCommonVerses("Genesis 1:1")}>
              Genesis 1:1
            </Button>
            <Button variant="outline" onClick={() => testCommonVerses("Psalm 23:1")}>
              Psalm 23:1
            </Button>
            <Button variant="outline" onClick={() => testCommonVerses("John 4:7")}>
              John 4:7
            </Button>
          </div>

          {error && (
            <div className="p-3 bg-red-50 text-red-700 rounded mb-4">
              <strong>Error:</strong> {error}
            </div>
          )}

          {result && (
            <div className="p-4 border rounded">
              <div className="font-semibold text-blue-600 mb-2">{result.reference}</div>
              <div>{result.text}</div>
              <div className="mt-2 text-sm text-gray-500">ID: {result.id}</div>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="text-sm text-gray-500">
        <p>
          This page tests <strong>only</strong> the GetVerse endpoint from RapidAPI.
        </p>
        <p>It converts references like "John 3:16" to the 8-digit verseId format (43003016) required by RapidAPI.</p>
        <p>Check the browser console for detailed logs of the API request and response.</p>
      </div>
    </div>
  )
}
