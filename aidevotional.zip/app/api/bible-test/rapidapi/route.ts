export async function GET() {
  try {
    // Test RapidAPI connection
    const response = await fetch("https://iq-bible.p.rapidapi.com/GetBooks?language=english", {
      headers: {
        "X-RapidAPI-Key": "4f9153d221msh9e9473de1ec4e29p1732b3jsna37f84ab53e1",
        "X-RapidAPI-Host": "iq-bible.p.rapidapi.com",
      },
    })

    if (response.ok) {
      const data = await response.json()
      return new Response(
        JSON.stringify({
          success: true,
          message: "RapidAPI is working",
          data: data,
        }),
        {
          headers: { "Content-Type": "application/json" },
        },
      )
    } else {
      return new Response(
        JSON.stringify({
          success: false,
          message: "RapidAPI failed",
          status: response.status,
          statusText: response.statusText,
        }),
        {
          headers: { "Content-Type": "application/json" },
        },
      )
    }
  } catch (error) {
    return new Response(
      JSON.stringify({
        success: false,
        message: "RapidAPI error",
        error: error instanceof Error ? error.message : "Unknown error",
      }),
      {
        headers: { "Content-Type": "application/json" },
      },
    )
  }
}
