export async function GET() {
  return new Response(
    JSON.stringify({
      status: "working",
      message: "Bible test API is functional",
      timestamp: new Date().toISOString(),
    }),
    {
      headers: { "Content-Type": "application/json" },
    },
  )
}
