import { NextResponse } from "next/server"
import { supabase } from "@/lib/supabase"

export async function GET() {
  try {
    // Check if we can connect to Supabase
    const { data: subscriptions, error } = await supabase
      .from("user_subscriptions")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(5)

    if (error) {
      return NextResponse.json({
        success: false,
        error: "Supabase connection failed",
        details: error.message,
      })
    }

    return NextResponse.json({
      success: true,
      message: "Webhook debug info",
      recent_subscriptions: subscriptions,
      webhook_endpoint: "/api/stripe/webhook",
      environment: process.env.NODE_ENV,
    })
  } catch (error: any) {
    return NextResponse.json({
      success: false,
      error: "Debug failed",
      details: error.message,
    })
  }
}
