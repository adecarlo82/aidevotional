import { NextResponse } from "next/server"
import Stripe from "stripe"

export async function GET() {
  try {
    // First, check if we have the environment variables
    const envCheck = {
      hasSecretKey: !!process.env.STRIPE_SECRET_KEY,
      secretKeyPrefix: process.env.STRIPE_SECRET_KEY
        ? `${process.env.STRIPE_SECRET_KEY.substring(0, 7)}...`
        : "Not set",
      hasPriceId: !!process.env.STRIPE_PREMIUM_PRICE_ID,
      priceId: process.env.STRIPE_PREMIUM_PRICE_ID || "Not set",
    }

    // If no secret key, return early
    if (!process.env.STRIPE_SECRET_KEY) {
      return NextResponse.json({
        error: "STRIPE_SECRET_KEY is not set",
        envCheck,
      })
    }

    // Initialize Stripe with the key
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
      apiVersion: "2023-10-16",
    })

    // Make a simple API call
    const balance = await stripe.balance.retrieve()

    // Try to get the price if it exists
    let priceInfo = { exists: false, data: null, error: null }
    if (process.env.STRIPE_PREMIUM_PRICE_ID) {
      try {
        const price = await stripe.prices.retrieve(process.env.STRIPE_PREMIUM_PRICE_ID)
        priceInfo = { exists: true, data: price, error: null }
      } catch (priceError: any) {
        priceInfo = {
          exists: false,
          data: null,
          error: priceError.message || "Error retrieving price",
        }
      }
    }

    return NextResponse.json({
      status: "success",
      isTestMode: process.env.STRIPE_SECRET_KEY.startsWith("sk_test_"),
      envCheck,
      balance: {
        available: balance.available,
        pending: balance.pending,
      },
      priceInfo,
    })
  } catch (error: any) {
    console.error("Stripe debug error:", error)

    return NextResponse.json(
      {
        status: "error",
        message: error.message || "Unknown Stripe error",
        type: error.type || "unknown_type",
        envCheck: {
          hasSecretKey: !!process.env.STRIPE_SECRET_KEY,
          secretKeyPrefix: process.env.STRIPE_SECRET_KEY
            ? `${process.env.STRIPE_SECRET_KEY.substring(0, 7)}...`
            : "Not set",
          hasPriceId: !!process.env.STRIPE_PREMIUM_PRICE_ID,
          priceId: process.env.STRIPE_PREMIUM_PRICE_ID || "Not set",
        },
      },
      { status: 500 },
    )
  }
}
