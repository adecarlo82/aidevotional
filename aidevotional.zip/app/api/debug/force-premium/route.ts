import { type NextRequest, NextResponse } from "next/server"
import { supabase } from "@/lib/supabase"

export async function GET(request: NextRequest) {
  try {
    // Get the session directly from the cookie
    const { data: sessionData, error: sessionError } = await supabase.auth.getSession()

    if (sessionError) {
      return NextResponse.json({ error: "Session error", details: sessionError }, { status: 401 })
    }

    const user = sessionData?.session?.user

    if (!user) {
      return NextResponse.json({ error: "No authenticated user found" }, { status: 401 })
    }

    // For debugging purposes, always return premium access
    return NextResponse.json({
      hasActiveSubscription: true,
      plan: "premium",
      userId: user.id,
      userEmail: user.email,
      message: "Premium access granted by debug endpoint",
    })
  } catch (error) {
    return NextResponse.json(
      {
        error: "Failed to check subscription",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
