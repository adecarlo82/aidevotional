import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

// Create a server-side Supabase client with service role key for admin access
const supabaseAdmin = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

export async function GET(request: NextRequest) {
  try {
    // Get the authorization header
    const authHeader = request.headers.get("authorization")

    let user = null
    if (authHeader) {
      const token = authHeader.replace("Bearer ", "")
      const {
        data: { user: authUser },
        error: authError,
      } = await supabaseAdmin.auth.getUser(token)
      user = authUser
    }

    if (!user) {
      // Try to get user from session if no auth header
      const {
        data: { session },
      } = await supabaseAdmin.auth.getSession()
      user = session?.user || null
    }

    if (!user) {
      return NextResponse.json({
        error: "No user found",
        user: null,
        message: "Please ensure you're signed in and try again",
      })
    }

    console.log(`🔍 Debug: Checking subscription for user: ${user.email} (${user.id})`)

    // Get all subscriptions for this user (not just active ones)
    const { data: allSubscriptions, error: allError } = await supabaseAdmin
      .from("user_subscriptions")
      .select("*")
      .eq("user_id", user.id)

    // Get active subscriptions specifically
    const { data: activeSubscriptions, error: activeError } = await supabaseAdmin
      .from("user_subscriptions")
      .select("*")
      .eq("user_id", user.id)
      .eq("status", "active")

    // Get table schema info
    const { data: tableInfo, error: tableError } = await supabaseAdmin.from("user_subscriptions").select("*").limit(1)

    return NextResponse.json({
      user: {
        id: user.id,
        email: user.email,
        created_at: user.created_at,
      },
      database: {
        allSubscriptions: allSubscriptions || [],
        activeSubscriptions: activeSubscriptions || [],
        subscriptionCount: allSubscriptions?.length || 0,
        activeCount: activeSubscriptions?.length || 0,
        hasActiveSubscription: (activeSubscriptions?.length || 0) > 0,
      },
      errors: {
        allError,
        activeError,
        tableError,
      },
      environment: {
        hasSupabaseUrl: !!process.env.NEXT_PUBLIC_SUPABASE_URL,
        hasServiceRoleKey: !!process.env.SUPABASE_SERVICE_ROLE_KEY,
      },
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("❌ Debug subscription error:", error)
    return NextResponse.json(
      {
        error: "Failed to debug subscription",
        details: error instanceof Error ? error.message : "Unknown error",
        timestamp: new Date().toISOString(),
      },
      { status: 500 },
    )
  }
}
