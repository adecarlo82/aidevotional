import { type NextRequest, NextResponse } from "next/server"
import { auth } from "@/lib/auth"
import { subscription } from "@/lib/subscription"
import { database } from "@/lib/database"

export async function POST(request: NextRequest) {
  try {
    // Check authentication
    const user = await auth.getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 })
    }

    // Check subscription
    const hasActiveSubscription = await subscription.hasActiveSubscription(user.id)
    if (!hasActiveSubscription) {
      return NextResponse.json({ error: "Premium subscription required" }, { status: 403 })
    }

    const devotionalData = await request.json()

    // Save devotional to database
    const savedDevotional = await database.saveDevotional(user.id, {
      title: devotionalData.title,
      content: JSON.stringify(devotionalData),
      scripture_references: [devotionalData.mainScripture?.reference].filter(Boolean),
      tags: devotionalData.tags || [],
    })

    return NextResponse.json(savedDevotional)
  } catch (error) {
    console.error("Save devotional error:", error)
    return NextResponse.json({ error: "Failed to save devotional" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    // Check authentication
    const user = await auth.getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 })
    }

    // Check subscription
    const hasActiveSubscription = await subscription.hasActiveSubscription(user.id)
    if (!hasActiveSubscription) {
      return NextResponse.json({ error: "Premium subscription required" }, { status: 403 })
    }

    // Get user's saved devotionals
    const devotionals = await database.getUserDevotionals(user.id)

    return NextResponse.json(devotionals)
  } catch (error) {
    console.error("Get devotionals error:", error)
    return NextResponse.json({ error: "Failed to get devotionals" }, { status: 500 })
  }
}
