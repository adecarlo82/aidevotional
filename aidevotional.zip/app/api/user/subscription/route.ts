import { type NextRequest, NextResponse } from "next/server"
import { supabase } from "@/lib/supabase"

export async function GET(request: NextRequest) {
  try {
    // Get the session directly from the cookie
    const { data: sessionData, error: sessionError } = await supabase.auth.getSession()

    if (sessionError) {
      console.error("❌ Session error:", sessionError)
      return NextResponse.json({ error: "Session error", details: sessionError }, { status: 401 })
    }

    const user = sessionData?.session?.user

    if (!user) {
      console.log("❌ No authenticated user found")
      return NextResponse.json({ error: "No authenticated user found" }, { status: 401 })
    }

    console.log(`🔍 Checking subscription for user: ${user.email} (${user.id})`)

    // Query the user_subscriptions table
    const { data: subscriptions, error: dbError } = await supabase
      .from("user_subscriptions")
      .select("*")
      .eq("user_id", user.id)

    if (dbError) {
      console.error("❌ Database error:", dbError)
      return NextResponse.json({ error: "Database error", details: dbError }, { status: 500 })
    }

    console.log(`📊 Found ${subscriptions?.length || 0} subscription records for user ${user.email}`)

    // Check for active subscription
    const activeSubscription = subscriptions?.find((sub) => sub.status === "active")
    const hasActiveSubscription = !!activeSubscription

    console.log(`✅ Active subscription status for ${user.email}: ${hasActiveSubscription ? "ACTIVE" : "INACTIVE"}`)

    // For debugging, let's always return premium access for this specific email
    if (user.email === "alex.decarlo82@yahoo.com") {
      console.log("🔑 Special case: Granting premium access to alex.decarlo82@yahoo.com")
      return NextResponse.json({
        hasActiveSubscription: true,
        plan: "premium",
        userId: user.id,
        userEmail: user.email,
        overridden: true,
        message: "Premium access granted by special case",
      })
    }

    return NextResponse.json({
      hasActiveSubscription,
      plan: hasActiveSubscription ? "premium" : "free",
      userId: user.id,
      userEmail: user.email,
      subscription: activeSubscription || null,
    })
  } catch (error) {
    console.error("❌ Subscription check error:", error)
    return NextResponse.json(
      {
        error: "Failed to check subscription",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
