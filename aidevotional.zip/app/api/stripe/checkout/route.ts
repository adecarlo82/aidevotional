import { NextResponse } from "next/server"
import { stripe } from "@/lib/stripe"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { email, priceId = process.env.STRIPE_PREMIUM_PRICE_ID, metadata = {} } = body

    if (!email) {
      return NextResponse.json({ error: "Email is required" }, { status: 400 })
    }

    // Check if this is a direct premium signup (no auth)
    const isPremiumDirect = !metadata.user_id

    // If direct signup, use the email from the request
    const userEmail = email

    // Get user session if available (for existing users)
    let userId = metadata.user_id
    if (!userId) {
      // For direct premium signup, we'll create the user in the webhook
      // Just use the email as identifier for now
      userId = `pending_${userEmail}`
    }

    // Create checkout session
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      billing_address_collection: "auto",
      customer_email: userEmail,
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      mode: "subscription",
      allow_promotion_codes: true,
      subscription_data: {
        metadata: {
          user_id: userId,
          user_email: userEmail,
          signup_type: isPremiumDirect ? "premium_direct" : "existing_user",
          ...metadata,
        },
      },
      // Fix the redirect URLs to use existing pages
      success_url: `${process.env.NEXT_PUBLIC_SITE_URL}/test-premium-flow?success=true&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.NEXT_PUBLIC_SITE_URL}/test-premium-flow?canceled=true`,
    })

    return NextResponse.json({ url: session.url })
  } catch (error: any) {
    console.error("Stripe checkout error:", error)
    return NextResponse.json({ error: error.message || "Something went wrong" }, { status: 500 })
  }
}
