import { type NextRequest, NextResponse } from "next/server"
import { subscription } from "@/lib/subscription"
import { auth } from "@/lib/auth"

export async function POST(request: NextRequest) {
  try {
    // Get current user
    const user = await auth.getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    console.log(`Creating portal session for user: ${user.id}`)

    // Create portal session
    const session = await subscription.createPortalSession(user.id, `${request.nextUrl.origin}/my-account`)

    console.log(`Portal session created successfully: ${session.url}`)
    return NextResponse.json({ url: session.url })
  } catch (error) {
    console.error("Portal error:", error)

    // Provide more specific error messages
    if (error instanceof Error) {
      if (error.message.includes("email not found")) {
        return NextResponse.json({ error: "User email not found" }, { status: 400 })
      }
      if (error.message.includes("customer")) {
        return NextResponse.json({ error: "Failed to create or find Stripe customer" }, { status: 500 })
      }
    }

    return NextResponse.json({ error: "Failed to create portal session" }, { status: 500 })
  }
}
