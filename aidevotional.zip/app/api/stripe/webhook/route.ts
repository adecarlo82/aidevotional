import { type NextRequest, NextResponse } from "next/server"
import { stripe } from "@/lib/stripe"
import { supabase } from "@/lib/supabase"
import type Stripe from "stripe"

const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET!

export async function POST(request: NextRequest) {
  console.log("🔔 Webhook received at:", new Date().toISOString())

  try {
    const body = await request.text()
    const signature = request.headers.get("stripe-signature")!

    console.log("📦 Body length:", body.length)
    console.log("🔐 Signature present:", !!signature)
    console.log("🔑 Webhook secret configured:", !!webhookSecret)

    if (!webhookSecret) {
      console.error("❌ STRIPE_WEBHOOK_SECRET not configured!")
      return NextResponse.json({ error: "Webhook secret not configured" }, { status: 500 })
    }

    let event: Stripe.Event

    try {
      event = stripe.webhooks.constructEvent(body, signature, webhookSecret)
      console.log("✅ Webhook signature verified")
      console.log("📋 Event type:", event.type)
      console.log("🆔 Event ID:", event.id)
    } catch (err) {
      console.error("❌ Webhook signature verification failed:", err)
      return NextResponse.json({ error: "Invalid signature" }, { status: 400 })
    }

    // Handle the event
    switch (event.type) {
      case "customer.subscription.created":
      case "customer.subscription.updated":
        console.log("🎯 Processing subscription event:", event.type)
        await handleSubscriptionChange(event.data.object as Stripe.Subscription)
        break

      case "customer.subscription.deleted":
        console.log("🎯 Processing subscription deletion")
        await handleSubscriptionDeleted(event.data.object as Stripe.Subscription)
        break

      case "invoice.payment_succeeded":
        console.log("🎯 Processing payment success")
        await handlePaymentSucceeded(event.data.object as Stripe.Invoice)
        break

      case "invoice.payment_failed":
        console.log("🎯 Processing payment failure")
        await handlePaymentFailed(event.data.object as Stripe.Invoice)
        break

      default:
        console.log(`ℹ️ Unhandled event type: ${event.type}`)
    }

    console.log("✅ Webhook processed successfully")
    return NextResponse.json({ received: true })
  } catch (error) {
    console.error("💥 Webhook error:", error)
    return NextResponse.json({ error: "Webhook handler failed" }, { status: 500 })
  }
}

async function handleSubscriptionChange(subscription: Stripe.Subscription) {
  console.log("🔄 handleSubscriptionChange called")
  console.log("📧 Customer email from metadata:", subscription.metadata.user_email)
  console.log("🏷️ Signup type:", subscription.metadata.signup_type)

  const customerId = subscription.customer as string
  const userEmail = subscription.metadata.user_email
  const signupType = subscription.metadata.signup_type

  // If this is a premium direct signup, create the user account
  if (signupType === "premium_direct" && userEmail) {
    console.log("🆕 Creating new premium user for:", userEmail)

    try {
      // Check if user already exists
      const { data: existingUser } = await supabase.auth.admin.getUserByEmail(userEmail)

      if (existingUser.user) {
        console.log("👤 User already exists:", existingUser.user.id)
        await createSubscriptionRecord(existingUser.user.id, customerId, subscription)
        return
      }

      // Create user in Supabase Auth
      console.log("🔨 Creating new Supabase user...")
      const { data: authData, error: authError } = await supabase.auth.admin.createUser({
        email: userEmail,
        email_confirm: true,
        user_metadata: {
          signup_type: "premium_direct",
          stripe_customer_id: customerId,
        },
      })

      if (authError) {
        console.error("❌ Error creating user:", authError)
        throw authError
      }

      if (authData.user) {
        console.log("✅ Created new user:", authData.user.id)
        await createSubscriptionRecord(authData.user.id, customerId, subscription)
        await sendWelcomeEmail(userEmail)
      }
    } catch (error) {
      console.error("💥 Error in premium direct signup:", error)
      throw error
    }
  } else {
    console.log("ℹ️ Not a premium direct signup, skipping user creation")
    const userId = subscription.metadata.user_id
    if (userId) {
      await createSubscriptionRecord(userId, customerId, subscription)
    }
  }
}

async function createSubscriptionRecord(userId: string, customerId: string, subscription: Stripe.Subscription) {
  console.log("💾 Creating subscription record for user:", userId)

  const subscriptionData = {
    user_id: userId,
    stripe_customer_id: customerId,
    stripe_subscription_id: subscription.id,
    status: subscription.status,
    current_period_start: new Date(subscription.current_period_start * 1000).toISOString(),
    current_period_end: new Date(subscription.current_period_end * 1000).toISOString(),
    updated_at: new Date().toISOString(),
  }

  console.log("📝 Subscription data:", subscriptionData)

  const { data, error } = await supabase.from("user_subscriptions").upsert(subscriptionData).select()

  if (error) {
    console.error("❌ Error creating subscription record:", error)
    throw error
  }

  console.log("✅ Subscription record created:", data)
}

async function sendWelcomeEmail(email: string) {
  console.log("📧 Generating welcome email for:", email)

  try {
    const { data, error } = await supabase.auth.admin.generateLink({
      type: "magiclink",
      email: email,
      options: {
        redirectTo: `${process.env.NEXT_PUBLIC_SITE_URL}/welcome?new=true`,
      },
    })

    if (error) {
      console.error("❌ Error generating magic link:", error)
      return
    }

    console.log("✅ Magic link generated:", data.properties?.action_link)
    // TODO: Send actual email
  } catch (error) {
    console.error("💥 Error sending welcome email:", error)
  }
}

async function handleSubscriptionDeleted(subscription: Stripe.Subscription) {
  console.log("🗑️ Handling subscription deletion:", subscription.id)

  const { error } = await supabase
    .from("user_subscriptions")
    .update({
      status: "canceled",
      updated_at: new Date().toISOString(),
    })
    .eq("stripe_subscription_id", subscription.id)

  if (error) {
    console.error("❌ Error canceling subscription:", error)
  } else {
    console.log("✅ Subscription marked as canceled")
  }
}

async function handlePaymentSucceeded(invoice: Stripe.Invoice) {
  console.log("💳 Handling payment success for invoice:", invoice.id)

  if (invoice.subscription) {
    const { error } = await supabase
      .from("user_subscriptions")
      .update({
        status: "active",
        updated_at: new Date().toISOString(),
      })
      .eq("stripe_subscription_id", invoice.subscription)

    if (error) {
      console.error("❌ Error updating payment status:", error)
    } else {
      console.log("✅ Subscription marked as active")
    }
  }
}

async function handlePaymentFailed(invoice: Stripe.Invoice) {
  console.log("💸 Handling payment failure for invoice:", invoice.id)

  if (invoice.subscription) {
    const { error } = await supabase
      .from("user_subscriptions")
      .update({
        status: "past_due",
        updated_at: new Date().toISOString(),
      })
      .eq("stripe_subscription_id", invoice.subscription)

    if (error) {
      console.error("❌ Error updating payment failure:", error)
    } else {
      console.log("✅ Subscription marked as past_due")
    }
  }
}
