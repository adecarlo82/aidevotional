import { type NextRequest, NextResponse } from "next/server"
import { gemini } from "@/lib/gemini"

export async function POST(request: NextRequest) {
  try {
    const { topic, preferences } = await request.json()

    if (!topic) {
      return NextResponse.json({ error: "Topic is required" }, { status: 400 })
    }

    // Generate AI devotional using Webster Bible
    const devotional = await gemini.generateDevotional(topic, preferences)

    return NextResponse.json({
      ...devotional,
      accessLevel: "free",
      bibleVersion: "Webster Bible (WBT)",
    })
  } catch (error) {
    console.error("Devotional generation error:", error)
    return NextResponse.json({ error: "Failed to generate devotional" }, { status: 500 })
  }
}
