import { type NextRequest, NextResponse } from "next/server"
import { auth } from "@/lib/auth"
import { subscription } from "@/lib/subscription"
import { hybridBibleAPI } from "@/lib/hybrid-bible-api"

export async function POST(request: NextRequest) {
  try {
    // Check authentication
    const user = await auth.getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 })
    }

    // Check subscription
    const hasActiveSubscription = await subscription.hasActiveSubscription(user.id)
    if (!hasActiveSubscription) {
      return NextResponse.json({ error: "Premium subscription required" }, { status: 403 })
    }

    const { topic } = await request.json()

    if (!topic) {
      return NextResponse.json({ error: "Topic is required" }, { status: 400 })
    }

    // Find relevant scripture for the prayer topic
    const verses = await hybridBibleAPI.findVerses(topic)

    if (verses.length > 0 && !verses[0].reference.startsWith("Search:")) {
      return NextResponse.json({
        scripture: {
          reference: verses[0].reference,
          text: verses[0].text,
        },
      })
    }

    // Fallback to encouraging verses
    const encouragingVerses = [
      {
        reference: "Philippians 4:6-7",
        text: "Do not be anxious about anything, but in every situation, by prayer and petition, with thanksgiving, present your requests to God. And the peace of God, which transcends all understanding, will guard your hearts and your minds in Christ Jesus.",
      },
      {
        reference: "1 John 5:14",
        text: "This is the confidence we have in approaching God: that if we ask anything according to his will, he hears us.",
      },
      {
        reference: "Matthew 7:7",
        text: "Ask and it will be given to you; seek and you will find; knock and the door will be opened to you.",
      },
    ]

    const randomVerse = encouragingVerses[Math.floor(Math.random() * encouragingVerses.length)]

    return NextResponse.json({
      scripture: randomVerse,
    })
  } catch (error) {
    console.error("Prayer scripture error:", error)
    return NextResponse.json({ error: "Failed to find scripture" }, { status: 500 })
  }
}
