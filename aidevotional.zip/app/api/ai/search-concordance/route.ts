import { type NextRequest, NextResponse } from "next/server"
import { gemini } from "@/lib/gemini"

export async function POST(request: NextRequest) {
  try {
    const { word, searchId } = await request.json()

    if (!word) {
      return NextResponse.json({ error: "Word is required" }, { status: 400 })
    }

    console.log(`📚 CONCORDANCE search for: "${word}" with ID: ${searchId || "none"}`)

    // Use Gemini AI for concordance study - NO verse detection, NO RapidAPI
    let concordanceResult
    try {
      console.log(`🤖 Generating concordance study for: "${word}"`)
      concordanceResult = await gemini.generateConcordance(word)
      console.log(`✅ Concordance study generated for: "${word}"`)
    } catch (concordanceError) {
      console.error(`❌ Concordance generation failed for: "${word}"`, concordanceError)

      // Fallback concordance response
      concordanceResult = {
        word: word,
        definition: `A biblical study of the word "${word}" would explore its usage throughout Scripture, examining its original Hebrew and Greek meanings, and its theological significance in the context of God's Word.`,
        keyVerses: [
          {
            reference: "Study Note",
            text: `For a comprehensive study of "${word}", please try searching for specific verses or topics related to this concept.`,
            explanation: "Concordance study assistance",
          },
        ],
        themes: [`Biblical meaning of ${word}`, "Scriptural usage", "Theological significance"],
        crossReferences: ["Related biblical concepts"],
        originalLanguage: `Study the Hebrew and Greek words translated as "${word}"`,
        practicalApplication: `Understanding "${word}" in biblical context helps deepen our faith and spiritual growth.`,
        fullStudy: `The word "${word}" appears throughout Scripture with rich theological meaning. A thorough concordance study would examine each occurrence, considering the original languages and cultural context to understand God's intended message.`,
      }
    }

    // Format the response for the frontend
    const formattedResults = {
      word: concordanceResult.word || word,
      definition: concordanceResult.definition || `Biblical study of "${word}"`,
      keyVerses: concordanceResult.keyVerses || [],
      themes: concordanceResult.themes || [],
      crossReferences: concordanceResult.crossReferences || [],
      originalLanguage: concordanceResult.originalLanguage || "",
      practicalApplication: concordanceResult.practicalApplication || "",
      fullStudy: concordanceResult.fullStudy || "",
      searchTerms: [word],
      totalFound: concordanceResult.keyVerses?.length || 0,
      source: "Google Gemini AI Concordance",
      query: word,
      originalQuery: word,
      searchId: searchId || `concordance_${Date.now()}`,
      accessLevel: "free",
      timestamp: new Date().toISOString(),
    }

    console.log(`📤 Returning concordance results for "${word}":`, {
      verseCount: formattedResults.keyVerses.length,
      source: formattedResults.source,
    })

    return new NextResponse(JSON.stringify(formattedResults), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        "Cache-Control": "no-store, no-cache, must-revalidate, proxy-revalidate",
        Pragma: "no-cache",
        Expires: "0",
      },
    })
  } catch (error) {
    console.error("Concordance API error:", error)

    return NextResponse.json(
      {
        error: "Concordance service temporarily unavailable",
        errorDetails: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
