import { type NextRequest, NextResponse } from "next/server"
import { auth } from "@/lib/auth"
import { subscription } from "@/lib/subscription"
import { gemini } from "@/lib/gemini"

export async function POST(request: NextRequest) {
  try {
    // Check authentication
    const user = await auth.getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 })
    }

    // Check subscription
    const hasActiveSubscription = await subscription.hasActiveSubscription(user.id)
    if (!hasActiveSubscription) {
      return NextResponse.json({ error: "Premium subscription required" }, { status: 403 })
    }

    const { topic, preferences } = await request.json()

    if (!topic) {
      return NextResponse.json({ error: "Topic is required" }, { status: 400 })
    }

    // Generate enhanced devotional with more detailed content
    const devotional = await gemini.generateDevotional(topic, {
      enhanced: true,
      preferences,
      includeCommentary: true,
      includeApplications: true,
    })

    // Add premium-specific enhancements
    const enhancedDevotional = {
      ...devotional,
      id: `devotional_${Date.now()}`,
      createdAt: new Date().toISOString(),
      content: {
        introduction: devotional.outline?.introduction || `Begin your study of ${topic} with prayer and an open heart.`,
        scriptureStudy: {
          keyPoints: devotional.outline?.scriptureStudy?.keyPoints || [
            {
              point: "Biblical Foundation",
              explanation: `Explore what Scripture teaches about ${topic}.`,
              supportingVerses: [],
            },
          ],
        },
        reflection: {
          questions: devotional.outline?.reflection?.questions || [
            "What is God teaching me through this passage?",
            "How does this apply to my current situation?",
            "What steps can I take to live this out?",
          ],
        },
        application: {
          practicalSteps: devotional.outline?.application?.practicalSteps || [
            "Reflect on the main message",
            "Identify one specific application",
            "Pray for wisdom to implement this truth",
          ],
          prayer:
            devotional.outline?.application?.prayer ||
            `Lord, help me understand and apply Your truth about ${topic}. Amen.`,
        },
      },
      tags: ["devotional", "premium", topic.toLowerCase().replace(/\s+/g, "-")],
    }

    return NextResponse.json(enhancedDevotional)
  } catch (error) {
    console.error("Complete devotional generation error:", error)
    return NextResponse.json({ error: "Failed to generate devotional" }, { status: 500 })
  }
}
