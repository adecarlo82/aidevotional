import { type NextRequest, NextResponse } from "next/server"
import { hybridBibleSimple } from "@/lib/hybrid-bible-simple"

// Helper function for related topics
function getRelatedTopics(query: string): string[] {
  const topicMap: Record<string, string[]> = {
    love: ["faith", "hope", "forgiveness", "peace"],
    faith: ["hope", "trust", "salvation", "prayer"],
    hope: ["faith", "peace", "comfort", "strength"],
    peace: ["comfort", "anxiety", "fear", "rest"],
    strength: ["courage", "faith", "perseverance", "hope"],
    wisdom: ["guidance", "understanding", "knowledge", "discernment"],
    forgiveness: ["mercy", "grace", "love", "redemption"],
    prayer: ["faith", "worship", "communion", "petition"],
    salvation: ["grace", "redemption", "eternal life", "faith"],
    comfort: ["peace", "hope", "healing", "rest"],
  }

  const queryLower = query.toLowerCase()
  return topicMap[queryLower] || ["faith", "hope", "love"]
}

export async function POST(request: NextRequest) {
  try {
    const { query, bibleVersion = "kjv", searchId } = await request.json()

    if (!query) {
      return NextResponse.json({ error: "Query is required" }, { status: 400 })
    }

    console.log(`📝 API received search request for: "${query}" with ID: ${searchId || "none"}`)

    // Use improved hybrid search
    const searchResult = await hybridBibleSimple.searchVerses(query)

    // Generate AI summary if we have real verses
    let aiSummary = searchResult.summary
    if (
      searchResult.verses.length > 0 &&
      !searchResult.verses[0].reference.includes("Search Help") &&
      !searchResult.verses[0].reference.includes("Verse Not Found")
    ) {
      try {
        console.log(`🤖 Generating AI summary for ${searchResult.verses.length} verses...`)

        // Simple AI summary generation
        const { GoogleGenerativeAI } = await import("@google/generative-ai")

        if (process.env.GOOGLE_AI_STUDIO_KEY) {
          const genAI = new GoogleGenerativeAI(process.env.GOOGLE_AI_STUDIO_KEY)
          const model = genAI.getGenerativeModel({
            model: "gemini-1.5-flash",
            systemInstruction: `You are a biblical scholar providing brief, meaningful summaries of Bible verses. 
            Focus on the spiritual message and practical application. Keep responses to 2-3 sentences maximum.
            Be encouraging and faithful to the biblical text.`,
          })

          const versesText = searchResult.verses.map((v) => `${v.reference}: "${v.text}"`).join("\n")
          const prompt = `Please provide a brief, meaningful summary of these Bible verses related to "${query}":

${versesText}

Focus on:
1. The main spiritual message
2. How this applies to someone searching for "${query}"
3. Keep it encouraging and practical (2-3 sentences maximum)`

          const result = await model.generateContent(prompt)
          const generatedSummary = result.response.text().trim()

          if (generatedSummary && generatedSummary.length > 10) {
            aiSummary = generatedSummary
            console.log(`✅ AI summary generated successfully`)
          }
        }
      } catch (error) {
        console.error("AI summary generation failed:", error)
        // Use a simple fallback summary
        if (searchResult.verses.length === 1) {
          aiSummary = `This verse provides biblical wisdom about "${query}". God's word offers comfort and direction for those seeking guidance.`
        } else {
          aiSummary = `These ${searchResult.verses.length} verses offer biblical perspective on "${query}". Scripture provides timeless wisdom and encouragement for believers seeking God's guidance.`
        }
      }
    }

    // Format response
    const formattedResults = {
      verses: searchResult.verses.map((verse) => ({
        reference: verse.reference,
        text: verse.text,
        relevance:
          verse.reference.includes("Search Help") || verse.reference.includes("Verse Not Found")
            ? "Help message"
            : "Biblical verse",
      })),
      summary: aiSummary,
      explanation: aiSummary,
      searchTerms: [query],
      totalFound: searchResult.verses.length,
      relatedTopics: getRelatedTopics(query),
      source: searchResult.source,
      query: query,
      originalQuery: query,
      searchId: searchId || `auto_${Date.now()}`,
      accessLevel: "free",
      bibleVersion: "RapidAPI + Local Database",
      timestamp: searchResult.timestamp,
    }

    console.log(`📤 Returning results for "${query}":`, {
      verseCount: formattedResults.verses.length,
      source: formattedResults.source,
    })

    return new NextResponse(JSON.stringify(formattedResults), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        "Cache-Control": "no-store, no-cache, must-revalidate, proxy-revalidate",
        Pragma: "no-cache",
        Expires: "0",
      },
    })
  } catch (error) {
    console.error("Search API error:", error)

    return NextResponse.json(
      {
        error: "Bible search service temporarily unavailable",
        errorDetails: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
