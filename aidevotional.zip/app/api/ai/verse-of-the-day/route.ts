import { type NextRequest, NextResponse } from "next/server"
import { gemini } from "@/lib/gemini"

export async function GET(request: NextRequest) {
  try {
    // Generate verse of the day (no auth required - public feature)
    const verseOfTheDay = await gemini.getVerseOfTheDay()

    return NextResponse.json(verseOfTheDay)
  } catch (error) {
    console.error("Verse of the day error:", error)
    return NextResponse.json({ error: "Failed to get verse of the day" }, { status: 500 })
  }
}
