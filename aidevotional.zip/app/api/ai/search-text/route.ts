import { type NextRequest, NextResponse } from "next/server"
import { bibleAPI } from "@/lib/bible-api"

const RAPIDAPI_KEY = "4f9153d221msh9e9473de1ec4e29p1732b3jsna37f84ab53e1"
const RAPIDAPI_HOST = "iq-bible.p.rapidapi.com"
const BASE_URL = `https://${RAPIDAPI_HOST}`

interface BibleVerse {
  reference: string
  text: string
  id?: string
}

interface TextSearchResult {
  literalMatches: BibleVerse[]
  thematicMatches: BibleVerse[]
  summary: string
  source: string
  query: string
  timestamp: string
}

export async function POST(request: NextRequest) {
  try {
    const { query } = await request.json()

    if (!query) {
      return NextResponse.json({ error: "Query is required" }, { status: 400 })
    }

    console.log(`🔍 Text search for: "${query}"`)

    let literalMatches: BibleVerse[] = []
    let thematicMatches: BibleVerse[] = []
    let primarySource = ""

    // Phase 1: Try RapidAPI for literal word matches
    try {
      console.log(`🌐 Trying RapidAPI GetSearch for literal matches...`)
      const rapidApiResults = await searchRapidAPI(query)

      if (rapidApiResults.length > 0) {
        literalMatches = rapidApiResults
        primarySource = "RapidAPI (primary)"
        console.log(`✅ RapidAPI found ${literalMatches.length} literal matches`)
      }
    } catch (error) {
      console.error(`❌ RapidAPI search failed:`, error)
    }

    // Phase 2: If RapidAPI failed, try local database for literal matches
    if (literalMatches.length === 0) {
      try {
        console.log(`💾 Trying local database for literal matches...`)
        const localResults = await bibleAPI.findVerses(query)

        if (localResults.length > 0) {
          literalMatches = localResults
          primarySource = "Local Database (fallback)"
          console.log(`✅ Local database found ${literalMatches.length} literal matches`)
        }
      } catch (error) {
        console.error(`❌ Local database search failed:`, error)
      }
    }

    // Phase 3: Generate thematic matches using AI (if we have literal matches)
    if (literalMatches.length > 0) {
      try {
        console.log(`🤖 Generating thematic matches with AI...`)
        thematicMatches = await generateThematicMatches(query, literalMatches)
        console.log(`✅ Generated ${thematicMatches.length} thematic matches`)
      } catch (error) {
        console.error(`❌ AI thematic generation failed:`, error)
      }
    }

    // Generate summary
    const summary = generateSummary(query, literalMatches.length, thematicMatches.length, primarySource)

    const result: TextSearchResult = {
      literalMatches: literalMatches.slice(0, 10), // Limit to 10 results
      thematicMatches: thematicMatches.slice(0, 5), // Limit to 5 thematic results
      summary,
      source: primarySource,
      query,
      timestamp: new Date().toISOString(),
    }

    console.log(`📤 Returning text search results for "${query}":`, {
      literalCount: result.literalMatches.length,
      thematicCount: result.thematicMatches.length,
      source: result.source,
    })

    return NextResponse.json(result)
  } catch (error) {
    console.error("Text search API error:", error)

    return NextResponse.json(
      {
        error: "Text search service temporarily unavailable",
        errorDetails: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

// Search RapidAPI GetSearch endpoint
async function searchRapidAPI(query: string): Promise<BibleVerse[]> {
  const url = `${BASE_URL}/GetSearch?query=${encodeURIComponent(query)}&versionId=kjv`
  console.log(`📡 RapidAPI request: ${url}`)

  const response = await fetch(url, {
    method: "GET",
    headers: {
      "x-rapidapi-key": RAPIDAPI_KEY,
      "x-rapidapi-host": RAPIDAPI_HOST,
    },
  })

  if (!response.ok) {
    throw new Error(`RapidAPI search failed: ${response.status} ${response.statusText}`)
  }

  const data = await response.json()
  console.log(`📊 RapidAPI response:`, data)

  // Handle different response formats
  let searchResults = []
  if (Array.isArray(data)) {
    searchResults = data
  } else if (data && typeof data === "object" && data.results && Array.isArray(data.results)) {
    searchResults = data.results
  } else if (data && typeof data === "object" && data.verses && Array.isArray(data.verses)) {
    searchResults = data.verses
  }

  if (searchResults.length === 0) {
    throw new Error("No results from RapidAPI")
  }

  // Format the verses
  return searchResults.slice(0, 15).map((item: any, index: number) => ({
    reference: `${getBookName(item.b || item.book)} ${Number.parseInt(item.c || item.chapter || "1")}:${Number.parseInt(item.v || item.verse || "1")}`,
    text: item.t || item.text || "Text not available",
    id: item.id || `rapidapi_${index}`,
  }))
}

// Generate thematic matches using AI
async function generateThematicMatches(query: string, literalMatches: BibleVerse[]): Promise<BibleVerse[]> {
  // For now, return a subset of literal matches as thematic
  // In the future, this could use AI to find conceptually related verses
  return literalMatches.slice(0, 5).map((verse, index) => ({
    ...verse,
    id: `thematic_${index}`,
  }))
}

// Generate summary text
function generateSummary(query: string, literalCount: number, thematicCount: number, source: string): string {
  if (literalCount === 0) {
    return `No verses found containing "${query}". Try searching for related terms or check spelling.`
  }

  let summary = `Found ${literalCount} verses containing "${query}"`

  if (thematicCount > 0) {
    summary += ` and ${thematicCount} thematically related verses`
  }

  summary += ` from ${source}.`

  return summary
}

// Helper function to get book name from book ID
function getBookName(bookId: string | number): string {
  const bookIdStr = String(bookId)
  const books: Record<string, string> = {
    "1": "Genesis",
    "2": "Exodus",
    "3": "Leviticus",
    "4": "Numbers",
    "5": "Deuteronomy",
    "6": "Joshua",
    "7": "Judges",
    "8": "Ruth",
    "9": "1 Samuel",
    "10": "2 Samuel",
    "11": "1 Kings",
    "12": "2 Kings",
    "13": "1 Chronicles",
    "14": "2 Chronicles",
    "15": "Ezra",
    "16": "Nehemiah",
    "17": "Esther",
    "18": "Job",
    "19": "Psalms",
    "20": "Proverbs",
    "21": "Ecclesiastes",
    "22": "Song of Solomon",
    "23": "Isaiah",
    "24": "Jeremiah",
    "25": "Lamentations",
    "26": "Ezekiel",
    "27": "Daniel",
    "28": "Hosea",
    "29": "Joel",
    "30": "Amos",
    "31": "Obadiah",
    "32": "Jonah",
    "33": "Micah",
    "34": "Nahum",
    "35": "Habakkuk",
    "36": "Zephaniah",
    "37": "Haggai",
    "38": "Zechariah",
    "39": "Malachi",
    "40": "Matthew",
    "41": "Mark",
    "42": "Luke",
    "43": "John",
    "44": "Acts",
    "45": "Romans",
    "46": "1 Corinthians",
    "47": "2 Corinthians",
    "48": "Galatians",
    "49": "Ephesians",
    "50": "Philippians",
    "51": "Colossians",
    "52": "1 Thessalonians",
    "53": "2 Thessalonians",
    "54": "1 Timothy",
    "55": "2 Timothy",
    "56": "Titus",
    "57": "Philemon",
    "58": "Hebrews",
    "59": "James",
    "60": "1 Peter",
    "61": "2 Peter",
    "62": "1 John",
    "63": "2 John",
    "64": "3 John",
    "65": "Jude",
    "66": "Revelation",
  }
  return books[bookIdStr] || `Book ${bookIdStr}`
}
