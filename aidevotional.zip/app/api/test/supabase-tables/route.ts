import { NextResponse } from "next/server"
import { supabase } from "@/lib/supabase"

export async function GET() {
  try {
    // Check user_subscriptions table
    const { data: subscriptions, error: subError } = await supabase
      .from("user_subscriptions")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(5)

    // Check auth users (limited info)
    const { data: users, error: userError } = await supabase.auth.admin.listUsers()

    return NextResponse.json({
      success: true,
      subscriptions: {
        count: subscriptions?.length || 0,
        data: subscriptions || [],
        error: subError?.message,
      },
      users: {
        count: users.users?.length || 0,
        recent_users:
          users.users?.slice(0, 5).map((u) => ({
            id: u.id,
            email: u.email,
            created_at: u.created_at,
            user_metadata: u.user_metadata,
          })) || [],
        error: userError?.message,
      },
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: error.toString() }, { status: 500 })
  }
}
