import { type NextRequest, NextResponse } from "next/server"
import { supabase } from "@/lib/supabase"

export async function POST(request: NextRequest) {
  try {
    const { subscriptionId } = await request.json()

    const { data: subscription, error } = await supabase
      .from("user_subscriptions")
      .select("*")
      .eq("stripe_subscription_id", subscriptionId)
      .single()

    if (error && error.code !== "PGRST116") {
      return NextResponse.json({ success: false, error: error.message }, { status: 400 })
    }

    return NextResponse.json({
      success: true,
      subscription_exists: !!subscription,
      subscription_data: subscription,
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: error.toString() }, { status: 500 })
  }
}
