import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    console.log("🔍 User check endpoint called")

    // Check if we can parse the request body
    let email: string
    try {
      const body = await request.json()
      email = body.email
      console.log("📧 Email from request:", email)
    } catch (parseError) {
      console.error("❌ Failed to parse request body:", parseError)
      return NextResponse.json(
        {
          success: false,
          error: "Invalid request body",
          details: parseError instanceof Error ? parseError.message : String(parseError),
        },
        { status: 400 },
      )
    }

    if (!email) {
      return NextResponse.json(
        {
          success: false,
          error: "Email is required",
        },
        { status: 400 },
      )
    }

    // Check environment variables - try different possible names
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || process.env.SUPABASE_URL
    const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY
    const anonKey = process.env.SUPABASE_ANON_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

    console.log("🔧 Environment check:", {
      hasUrl: !!supabaseUrl,
      hasServiceKey: !!serviceRoleKey,
      hasAnonKey: !!anonKey,
    })

    if (!supabaseUrl) {
      return NextResponse.json(
        {
          success: false,
          error: "Missing Supabase URL",
          available_env_keys: Object.keys(process.env).filter((key) => key.includes("SUPABASE")),
        },
        { status: 500 },
      )
    }

    // If no service role key, try with anon key (limited functionality)
    const keyToUse = serviceRoleKey || anonKey
    if (!keyToUse) {
      return NextResponse.json(
        {
          success: false,
          error: "No Supabase key available",
          available_env_keys: Object.keys(process.env).filter((key) => key.includes("SUPABASE")),
        },
        { status: 500 },
      )
    }

    // Try to create Supabase client
    let supabaseClient
    try {
      const { createClient } = await import("@supabase/supabase-js")
      supabaseClient = createClient(supabaseUrl, keyToUse, {
        auth: {
          autoRefreshToken: false,
          persistSession: false,
        },
      })
      console.log("✅ Supabase client created")
    } catch (clientError) {
      console.error("❌ Failed to create Supabase client:", clientError)
      return NextResponse.json(
        {
          success: false,
          error: "Failed to create Supabase client",
          details: clientError instanceof Error ? clientError.message : String(clientError),
        },
        { status: 500 },
      )
    }

    // Try to check users - different approaches based on available key
    try {
      if (serviceRoleKey) {
        // Use admin API if service role key is available
        console.log("🔍 Using admin API to list users...")
        const { data: users, error } = await supabaseClient.auth.admin.listUsers()

        if (error) {
          console.error("❌ Error listing users:", error)
          return NextResponse.json(
            {
              success: false,
              error: "Failed to list users",
              details: error.message,
            },
            { status: 400 },
          )
        }

        console.log(`📊 Found ${users.users.length} total users`)
        const user = users.users.find((u) => u.email === email)

        if (user) {
          console.log("✅ User found:", user.id)
          return NextResponse.json({
            success: true,
            user_exists: true,
            user: {
              id: user.id,
              email: user.email,
              created_at: user.created_at,
              user_metadata: user.user_metadata,
            },
          })
        } else {
          console.log("❌ User not found")
          return NextResponse.json({
            success: true,
            user_exists: false,
            message: "User not found",
          })
        }
      } else {
        // Limited functionality with anon key
        console.log("⚠️ Using anon key - limited functionality")
        return NextResponse.json({
          success: true,
          user_exists: false,
          message: "Cannot check users with anon key - would need service role key",
          key_type: "anon",
        })
      }
    } catch (listError) {
      console.error("❌ Error in user checking operation:", listError)
      return NextResponse.json(
        {
          success: false,
          error: "Error checking users",
          details: listError instanceof Error ? listError.message : String(listError),
        },
        { status: 500 },
      )
    }
  } catch (error) {
    console.error("💥 Unexpected error in check-user endpoint:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Internal server error",
        details: error instanceof Error ? error.message : String(error),
      },
      { status: 500 },
    )
  }
}
