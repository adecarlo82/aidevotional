import { NextResponse } from "next/server"

export async function GET() {
  try {
    // Check all possible environment variable names and variations
    const envCheck = {
      // Direct process.env access
      direct_access: {
        NEXT_PUBLIC_SUPABASE_URL: process.env.NEXT_PUBLIC_SUPABASE_URL,
        SUPABASE_SERVICE_ROLE_KEY: process.env.SUPABASE_SERVICE_ROLE_KEY,
        SUPABASE_ANON_KEY: process.env.SUPABASE_ANON_KEY,
        NEXT_PUBLIC_SUPABASE_ANON_KEY: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
        SUPABASE_URL: process.env.SUPABASE_URL,
        SUPABASE_JWT_SECRET: process.env.SUPABASE_JWT_SECRET,
      },

      // Check if values exist (without showing actual values for security)
      exists_check: {
        NEXT_PUBLIC_SUPABASE_URL: !!process.env.NEXT_PUBLIC_SUPABASE_URL,
        SUPABASE_SERVICE_ROLE_KEY: !!process.env.SUPABASE_SERVICE_ROLE_KEY,
        SUPABASE_ANON_KEY: !!process.env.SUPABASE_ANON_KEY,
        NEXT_PUBLIC_SUPABASE_ANON_KEY: !!process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
        SUPABASE_URL: !!process.env.SUPABASE_URL,
        SUPABASE_JWT_SECRET: !!process.env.SUPABASE_JWT_SECRET,
      },

      // Show first few characters of each (for debugging)
      partial_values: {
        NEXT_PUBLIC_SUPABASE_URL: process.env.NEXT_PUBLIC_SUPABASE_URL?.substring(0, 20) + "...",
        SUPABASE_SERVICE_ROLE_KEY: process.env.SUPABASE_SERVICE_ROLE_KEY?.substring(0, 20) + "...",
        SUPABASE_ANON_KEY: process.env.SUPABASE_ANON_KEY?.substring(0, 20) + "...",
        NEXT_PUBLIC_SUPABASE_ANON_KEY: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY?.substring(0, 20) + "...",
        SUPABASE_URL: process.env.SUPABASE_URL?.substring(0, 20) + "...",
      },

      // All environment variables that contain "SUPABASE"
      all_supabase_keys: Object.keys(process.env).filter((key) => key.toUpperCase().includes("SUPABASE")),

      // Total number of environment variables
      total_env_vars: Object.keys(process.env).length,

      // Some other common env vars to check if env loading works at all
      other_vars: {
        NODE_ENV: process.env.NODE_ENV,
        VERCEL: process.env.VERCEL,
        NEXT_RUNTIME: process.env.NEXT_RUNTIME,
      },
    }

    return NextResponse.json({
      success: true,
      debug_info: envCheck,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : String(error),
      },
      { status: 500 },
    )
  }
}
