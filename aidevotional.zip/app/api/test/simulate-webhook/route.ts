import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    console.log("🧪 Webhook simulation started")

    const body = await request.json()
    console.log("📦 Received body:", body)

    // Just return success for now to test the flow
    return NextResponse.json({
      success: true,
      message: "Webhook simulation completed (basic test)",
      timestamp: new Date().toISOString(),
      received_data: body,
    })
  } catch (error) {
    console.error("💥 Webhook simulation error:", error)

    return new Response(
      JSON.stringify({
        success: false,
        error: "Webhook simulation error",
        details: error instanceof Error ? error.message : String(error),
      }),
      {
        status: 500,
        headers: {
          "Content-Type": "application/json",
        },
      },
    )
  }
}

export async function GET() {
  return NextResponse.json({
    success: true,
    message: "Webhook simulation endpoint is working",
    methods: ["POST"],
  })
}
