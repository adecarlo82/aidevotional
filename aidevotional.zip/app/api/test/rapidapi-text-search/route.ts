import { type NextRequest, NextResponse } from "next/server"

const RAPIDAPI_KEY = "4f9153d221msh9e9473de1ec4e29p1732b3jsna37f84ab53e1"
const RAPIDAPI_HOST = "iq-bible.p.rapidapi.com"
const BASE_URL = `https://${RAPIDAPI_HOST}`

export async function POST(request: NextRequest) {
  try {
    const { query } = await request.json()

    if (!query) {
      return NextResponse.json({ error: "Query is required" }, { status: 400 })
    }

    console.log(`🧪 Testing RapidAPI GetSearch for: "${query}"`)

    // Test RapidAPI GetSearch endpoint
    const url = `${BASE_URL}/GetSearch?query=${encodeURIComponent(query)}&versionId=kjv`
    console.log(`📡 RapidAPI URL: ${url}`)

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "x-rapidapi-key": RAPIDAPI_KEY,
        "x-rapidapi-host": RAPIDAPI_HOST,
      },
    })

    console.log(`📊 RapidAPI response status: ${response.status}`)

    if (!response.ok) {
      const errorText = await response.text()
      console.error(`❌ RapidAPI error: ${response.status} - ${errorText}`)
      throw new Error(`RapidAPI failed: ${response.status} ${response.statusText}`)
    }

    const data = await response.json()
    console.log(`📊 RapidAPI raw response:`, data)
    console.log(`📊 Response type:`, typeof data, `Array:`, Array.isArray(data), `Length:`, data?.length)

    // Process the response
    let searchResults = []
    if (Array.isArray(data)) {
      searchResults = data
    } else if (data && typeof data === "object" && data.results && Array.isArray(data.results)) {
      searchResults = data.results
    } else if (data && typeof data === "object" && data.verses && Array.isArray(data.verses)) {
      searchResults = data.verses
    }

    console.log(`📊 Processed search results: ${searchResults.length} items`)

    if (searchResults.length > 0) {
      // Format the verses
      const verses = searchResults.slice(0, 10).map((item: any, index: number) => {
        console.log(`📝 Processing item ${index}:`, item)

        return {
          reference: `${getBookName(item.b || item.book)} ${Number.parseInt(item.c || item.chapter || "1")}:${Number.parseInt(item.v || item.verse || "1")}`,
          text: item.t || item.text || "Text not available",
          id: item.id || `search_${index}`,
        }
      })

      return NextResponse.json({
        success: true,
        query,
        verses,
        totalFound: searchResults.length,
        source: "RapidAPI GetSearch",
        rawResponse: data,
        timestamp: new Date().toISOString(),
      })
    }

    return NextResponse.json({
      success: false,
      query,
      verses: [],
      message: "No results found",
      rawResponse: data,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("❌ RapidAPI text search test error:", error)

    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
        details: "RapidAPI text search test failed",
      },
      { status: 500 },
    )
  }
}

// Helper function to get book name from book ID
function getBookName(bookId: string | number): string {
  const bookIdStr = String(bookId)
  const books: Record<string, string> = {
    "1": "Genesis",
    "2": "Exodus",
    "3": "Leviticus",
    "4": "Numbers",
    "5": "Deuteronomy",
    "6": "Joshua",
    "7": "Judges",
    "8": "Ruth",
    "9": "1 Samuel",
    "10": "2 Samuel",
    "11": "1 Kings",
    "12": "2 Kings",
    "13": "1 Chronicles",
    "14": "2 Chronicles",
    "15": "Ezra",
    "16": "Nehemiah",
    "17": "Esther",
    "18": "Job",
    "19": "Psalms",
    "20": "Proverbs",
    "21": "Ecclesiastes",
    "22": "Song of Solomon",
    "23": "Isaiah",
    "24": "Jeremiah",
    "25": "Lamentations",
    "26": "Ezekiel",
    "27": "Daniel",
    "28": "Hosea",
    "29": "Joel",
    "30": "Amos",
    "31": "Obadiah",
    "32": "Jonah",
    "33": "Micah",
    "34": "Nahum",
    "35": "Habakkuk",
    "36": "Zephaniah",
    "37": "Haggai",
    "38": "Zechariah",
    "39": "Malachi",
    "40": "Matthew",
    "41": "Mark",
    "42": "Luke",
    "43": "John",
    "44": "Acts",
    "45": "Romans",
    "46": "1 Corinthians",
    "47": "2 Corinthians",
    "48": "Galatians",
    "49": "Ephesians",
    "50": "Philippians",
    "51": "Colossians",
    "52": "1 Thessalonians",
    "53": "2 Thessalonians",
    "54": "1 Timothy",
    "55": "2 Timothy",
    "56": "Titus",
    "57": "Philemon",
    "58": "Hebrews",
    "59": "James",
    "60": "1 Peter",
    "61": "2 Peter",
    "62": "1 John",
    "63": "2 John",
    "64": "3 John",
    "65": "Jude",
    "66": "Revelation",
  }
  return books[bookIdStr] || `Book ${bookIdStr}`
}
