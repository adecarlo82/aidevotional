import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    console.log("🧪 Simple webhook test started")

    const body = await request.json()
    console.log("📦 Received webhook body:", body)

    // Extract key information from the webhook
    const {
      type,
      data: { object },
    } = body

    // Extract subscription details
    const subscriptionId = object?.id || "unknown"
    const customerId = object?.customer || "unknown"
    const status = object?.status || "unknown"
    const userEmail = object?.metadata?.user_email || "unknown"

    // Simulate successful webhook processing without actually touching Supabase
    const mockResponse = {
      webhook_received: true,
      event_type: type,
      subscription: {
        id: subscriptionId,
        customer_id: customerId,
        status: status,
        user_email: userEmail,
      },
      would_create_user: userEmail !== "unknown",
      would_create_subscription: subscriptionId !== "unknown" && status === "active",
      timestamp: new Date().toISOString(),
      message: "Webhook simulation successful (without Supabase)",
    }

    console.log("✅ Mock webhook processing complete:", mockResponse)

    return NextResponse.json({
      success: true,
      data: mockResponse,
    })
  } catch (error) {
    console.error("❌ Simple webhook test error:", error)
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : String(error),
      },
      { status: 500 },
    )
  }
}
