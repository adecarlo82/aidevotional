export async function GET() {
  try {
    // Return the simplest possible response
    return new Response(
      JSON.stringify({
        message: "Basic API route is working",
        timestamp: new Date().toISOString(),
      }),
      {
        status: 200,
        headers: {
          "Content-Type": "application/json",
        },
      },
    )
  } catch (error) {
    // Simplest possible error handling
    return new Response(
      JSON.stringify({
        error: "API route error",
        message: error instanceof Error ? error.message : "Unknown error",
      }),
      {
        status: 500,
        headers: {
          "Content-Type": "application/json",
        },
      },
    )
  }
}
