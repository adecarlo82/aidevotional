import { type NextRequest, NextResponse } from "next/server"
import { bibleAPI } from "@/lib/bible-api"

export async function POST(request: NextRequest) {
  try {
    const { query } = await request.json()

    if (!query) {
      return NextResponse.json({ error: "Query is required" }, { status: 400 })
    }

    console.log(`🧪 Testing Local Database search for: "${query}"`)

    // Test local database search
    const verses = await bibleAPI.findVerses(query)
    console.log(`📊 Local database found: ${verses.length} verses`)

    return NextResponse.json({
      success: true,
      query,
      verses,
      totalFound: verses.length,
      source: "Local Bible Database",
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("❌ Local database text search test error:", error)

    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
        details: "Local database text search test failed",
      },
      { status: 500 },
    )
  }
}
