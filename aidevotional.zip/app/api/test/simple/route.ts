import { NextResponse } from "next/server"
import { stripe } from "@/lib/stripe"

export async function GET() {
  try {
    // Test Stripe connection by making a simple API call
    const products = await stripe.products.list({ limit: 1 })

    return NextResponse.json({
      success: true,
      message: "Stripe API connection successful",
      data: {
        apiVersion: "2024-06-20", // From our stripe config
        productsCount: products.data.length,
        hasConnection: true,
      },
    })
  } catch (error: any) {
    console.error("Stripe test error:", error)

    return NextResponse.json(
      {
        success: false,
        error: error.message || String(error),
        type: error.type || "unknown_error",
      },
      { status: 500 },
    )
  }
}
