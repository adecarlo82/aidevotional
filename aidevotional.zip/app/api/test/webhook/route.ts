import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

const supabaseAdmin = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

export async function POST(request: NextRequest) {
  try {
    const { userId, action } = await request.json()

    if (!userId) {
      return NextResponse.json({ error: "userId is required" }, { status: 400 })
    }

    if (action === "create_test_subscription") {
      // Create a test subscription record
      const { data, error } = await supabaseAdmin.from("user_subscriptions").upsert({
        user_id: userId,
        stripe_customer_id: `cus_test_${Date.now()}`,
        stripe_subscription_id: `sub_test_${Date.now()}`,
        status: "active",
        current_period_start: new Date().toISOString(),
        current_period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days from now
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })

      if (error) {
        return NextResponse.json({ error: "Failed to create test subscription", details: error }, { status: 500 })
      }

      return NextResponse.json({ success: true, data })
    }

    if (action === "cancel_test_subscription") {
      // Cancel test subscription
      const { data, error } = await supabaseAdmin
        .from("user_subscriptions")
        .update({
          status: "canceled",
          updated_at: new Date().toISOString(),
        })
        .eq("user_id", userId)

      if (error) {
        return NextResponse.json({ error: "Failed to cancel test subscription", details: error }, { status: 500 })
      }

      return NextResponse.json({ success: true, data })
    }

    return NextResponse.json({ error: "Invalid action" }, { status: 400 })
  } catch (error) {
    return NextResponse.json(
      { error: "Test webhook failed", details: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 },
    )
  }
}
