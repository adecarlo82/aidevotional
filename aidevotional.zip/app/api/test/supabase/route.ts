import { NextResponse } from "next/server"
import { supabase } from "@/lib/supabase"

export async function GET() {
  try {
    // Test 1: Check if Supabase client is initialized
    if (!supabase) {
      return NextResponse.json(
        {
          success: false,
          error: "Supabase client not initialized",
        },
        { status: 500 },
      )
    }

    // Test 2: Try to make a simple query
    const { data, error } = await supabase.from("user_subscriptions").select("count").limit(1)

    if (error) {
      console.error("Supabase query error:", error)
      return NextResponse.json(
        {
          success: false,
          error: error.message,
          details: error,
          clientInfo: {
            url: process.env.NEXT_PUBLIC_SUPABASE_URL ? "Set" : "Missing",
            anonKey: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ? "Set" : "Missing",
          },
        },
        { status: 500 },
      )
    }

    // Test 3: Check auth configuration
    const { data: authConfig, error: authError } = await supabase.auth.getSession()

    return NextResponse.json({
      success: true,
      message: "Supabase connection successful",
      data: {
        queryResult: data,
        authConfigured: !authError,
        hasSession: authConfig?.session ? true : false,
      },
    })
  } catch (error: any) {
    console.error("Supabase test error:", error)
    return NextResponse.json(
      {
        success: false,
        error: error.message || String(error),
        stack: error.stack,
        clientInfo: {
          url: process.env.NEXT_PUBLIC_SUPABASE_URL ? "Set" : "Missing",
          anonKey: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ? "Set" : "Missing",
        },
      },
      { status: 500 },
    )
  }
}
