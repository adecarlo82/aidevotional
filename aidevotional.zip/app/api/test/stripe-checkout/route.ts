import { NextResponse } from "next/server"
import { stripe } from "@/lib/stripe"

export async function POST(request: Request) {
  try {
    const { email } = await request.json()

    // Just test if we can create a checkout session
    // We won't actually use this session, just verify we can create one
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items: [
        {
          price_data: {
            currency: "usd",
            product_data: {
              name: "Test Product",
              description: "This is just a test product for API verification",
            },
            unit_amount: 1000, // $10.00
          },
          quantity: 1,
        },
      ],
      mode: "payment",
      success_url: `${process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"}/test-success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"}/test-cancel`,
      customer_email: email,
    })

    return NextResponse.json({
      success: true,
      message: "Checkout session created successfully",
      data: {
        sessionId: session.id,
        url: session.url,
        hasSession: true,
      },
    })
  } catch (error: any) {
    console.error("Stripe checkout test error:", error)
    return NextResponse.json(
      {
        success: false,
        error: error.message || String(error),
        type: error.type || "unknown_error",
      },
      { status: 500 },
    )
  }
}
