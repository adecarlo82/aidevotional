"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"

export default function ManualWebhookTest() {
  const [testEmail, setTestEmail] = useState("test@example.com")
  const [results, setResults] = useState<any[]>([])
  const [loading, setLoading] = useState(false)

  const handleApiCall = async (url: string, options: RequestInit = {}) => {
    try {
      const response = await fetch(url, options)
      const responseText = await response.text()

      let data
      try {
        data = JSON.parse(responseText)
      } catch (parseError) {
        data = {
          error: "Failed to parse JSON",
          responseText: responseText.substring(0, 500),
          parseError: parseError.toString(),
        }
      }

      return { ok: response.ok, status: response.status, data }
    } catch (error) {
      return {
        ok: false,
        status: 0,
        data: { error: error.toString() },
      }
    }
  }

  const checkEnvironment = async () => {
    setLoading(true)
    setResults([])

    try {
      console.log("🔧 Checking environment variables...")
      const result = await handleApiCall("/api/test/env-debug")
      setResults([{ step: "Environment Variables Check", success: result.ok, data: result.data }])
    } catch (error) {
      console.error("❌ Environment check error:", error)
      setResults([{ step: "Environment Error", success: false, data: { error: error.toString() } }])
    }

    setLoading(false)
  }

  const testSimpleWebhook = async () => {
    setLoading(true)
    setResults([])

    try {
      const mockSubscription = {
        id: "sub_test_" + Date.now(),
        customer: "cus_test_" + Date.now(),
        status: "active",
        current_period_start: Math.floor(Date.now() / 1000),
        current_period_end: Math.floor(Date.now() / 1000) + 30 * 24 * 60 * 60,
        metadata: {
          user_email: testEmail,
          signup_type: "premium_direct",
        },
      }

      console.log("🧪 Testing simple webhook (no Supabase)...")

      const result = await handleApiCall("/api/test/simple-webhook-test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: "customer.subscription.created",
          data: { object: mockSubscription },
        }),
      })

      setResults([{ step: "Simple Webhook Test", success: result.ok, data: result.data }])
    } catch (error) {
      console.error("❌ Simple webhook test error:", error)
      setResults([{ step: "Simple Webhook Error", success: false, data: { error: error.toString() } }])
    }

    setLoading(false)
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Manual Webhook Testing</CardTitle>
            <CardDescription>Test the webhook flow - with and without Supabase</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="email">Test Email</Label>
              <Input
                id="email"
                type="email"
                value={testEmail}
                onChange={(e) => setTestEmail(e.target.value)}
                placeholder="test@example.com"
              />
            </div>

            <div className="flex gap-2 flex-wrap">
              <Button onClick={checkEnvironment} disabled={loading} variant="secondary">
                {loading ? "Checking..." : "Check Environment"}
              </Button>
              <Button onClick={testSimpleWebhook} disabled={loading} variant="default">
                {loading ? "Testing..." : "Test Simple Webhook"}
              </Button>
            </div>

            {results.length > 0 && (
              <div className="space-y-3">
                <h3 className="font-semibold">Test Results:</h3>
                {results.map((result, index) => (
                  <Card
                    key={index}
                    className={`border-l-4 ${result.success ? "border-l-green-200" : "border-l-red-200"}`}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">{result.step}</span>
                        <Badge className={result.success ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}>
                          {result.success ? "Success" : "Failed"}
                        </Badge>
                      </div>
                      <details>
                        <summary className="text-sm text-gray-600 cursor-pointer">View Details</summary>
                        <pre className="text-xs bg-gray-100 p-2 rounded mt-2 overflow-auto max-h-40">
                          {JSON.stringify(result.data, null, 2)}
                        </pre>
                      </details>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Environment Variable Status</CardTitle>
            <CardDescription>Current status after refresh</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-sm space-y-2">
              <div>🔄 Page recreated after refresh</div>
              <div>🧪 Test "Check Environment" to see if env vars are now loaded</div>
              <div>✅ "Test Simple Webhook" works without environment variables</div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
