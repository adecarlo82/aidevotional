"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  BookOpen,
  Heart,
  Search,
  Play,
  CheckCircle,
  ArrowRight,
  Lightbulb,
  Target,
  Star,
  HelpCircle,
} from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { AuthModal } from "@/components/auth/auth-modal"
import { useAuth } from "@/components/auth/auth-provider"

const quickStartSteps = [
  {
    step: 1,
    title: "Choose Your Feature",
    description: "Start with Bible Search, Concordance, or Devotional Generator",
    icon: Target,
    action: "Go to Features",
    link: "/#features",
  },
  {
    step: 2,
    title: "Enter Your Query",
    description: "Type naturally - 'verses about hope' or 'John 3:16'",
    icon: Search,
    action: "Try a Search",
    link: "/#features",
  },
  {
    step: 3,
    title: "Explore Results",
    description: "Read verses, summaries, and related content",
    icon: BookOpen,
    action: "See Examples",
    link: "#examples",
  },
  {
    step: 4,
    title: "Deepen Your Study",
    description: "Generate devotionals and save your favorites (Premium)",
    icon: Heart,
    action: "Upgrade",
    link: "#premium",
  },
]

const tutorials = [
  {
    id: "bible-search",
    title: "Bible Verse Search",
    description: "Learn how to find any verse using natural language",
    duration: "3 min",
    difficulty: "Beginner",
    icon: BookOpen,
    steps: [
      "Navigate to the Bible Search tab on the home page",
      "Type your query in natural language (e.g., 'verses about love')",
      "Click Search or press Enter",
      "Browse through the results and read the AI-generated summary",
      "Click on any verse reference to see more context",
    ],
    examples: ["verses about God's love", "John 3:16", "Mark 2:2-4", "Psalm 23", "hope in difficult times"],
  },
  {
    id: "concordance",
    title: "Smart Concordance",
    description: "Discover biblical concepts and word meanings",
    duration: "4 min",
    difficulty: "Beginner",
    icon: Search,
    steps: [
      "Click on the Bible Concordance tab",
      "Enter a word or concept you want to study",
      "Review the AI-generated definition and explanation",
      "Explore the related verses and their contexts",
      "Use the cross-references to deepen your understanding",
    ],
    examples: ["faith", "righteousness", "covenant", "redemption", "grace"],
  },
  {
    id: "devotionals",
    title: "AI Devotional Generator",
    description: "Create personalized devotional studies",
    duration: "5 min",
    difficulty: "Intermediate",
    icon: Heart,
    steps: [
      "Select the Devotional Outline tab",
      "Enter a topic or life situation you're facing",
      "Wait for the AI to generate a structured devotional",
      "Read through the introduction, scripture study, and reflection questions",
      "Use the practical application steps in your daily life",
      "Save the devotional to your account (Premium feature)",
    ],
    examples: ["dealing with anxiety", "finding purpose", "growing in faith", "forgiveness", "trusting God's plan"],
  },
]

const tips = [
  {
    category: "Search Tips",
    icon: Lightbulb,
    items: [
      "Use natural language - ask questions like you would to a friend",
      "Try different phrasings if you don't find what you're looking for",
      "Include book names for more specific results (e.g., 'Romans about salvation')",
      "Use verse ranges like 'John 3:16-18' for multiple verses",
      "Search by themes like 'hope', 'love', or 'forgiveness'",
    ],
  },
  {
    category: "Study Tips",
    icon: BookOpen,
    items: [
      "Start with familiar verses and explore related passages",
      "Use the concordance to understand key biblical terms",
      "Generate devotionals on topics you're currently facing",
      "Read the AI summaries to get context and deeper insights",
      "Cross-reference multiple translations when studying",
    ],
  },
  {
    category: "Spiritual Growth",
    icon: Heart,
    items: [
      "Set aside regular time for Bible study using our tools",
      "Use devotional questions for personal reflection or group discussion",
      "Track your spiritual journey by saving meaningful content",
      "Share insights with your faith community",
      "Pray before and after your study sessions",
    ],
  },
]

const faqs = [
  {
    question: "Do I need to create an account to use AI Devotional?",
    answer:
      "No! All core features (Bible search, concordance, and devotional generation) are completely free and don't require an account. You only need to sign up if you want premium features like saving content and search history.",
  },
  {
    question: "Which Bible translation do you use?",
    answer:
      "We primarily use the Webster Bible translation, which provides clear, accessible language. Premium users will have access to multiple translations in the future.",
  },
  {
    question: "How accurate are the AI-generated results?",
    answer:
      "Our AI is trained on biblical scholarship and provides contextually relevant results. However, we always recommend comparing with traditional study resources and seeking guidance from spiritual mentors for important theological questions.",
  },
  {
    question: "Can I use this for group Bible study?",
    answer:
      "Our tools are perfect for group study preparation. Generate devotionals on topics your group is studying, or use the concordance to explore key themes together.",
  },
  {
    question: "Is my data secure?",
    answer:
      "Yes, we use enterprise-grade security to protect your information. We don't share your personal data or search history with third parties.",
  },
  {
    question: "What's included in the Premium subscription?",
    answer:
      "Premium includes saving unlimited devotionals, full search history, export to PDF/Word, priority support, and access to additional Bible translations.",
  },
]

export default function GetStartedPage() {
  const [activeTab, setActiveTab] = useState("quick-start")
  const [showAuthModal, setShowAuthModal] = useState(false)
  const { user } = useAuth()

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-amber-200 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-3">
            <Image src="/logo.png" alt="AI Devotional Logo" width={80} height={80} className="object-contain" />
          </Link>
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/" className="text-slate-700 hover:text-amber-700 transition-colors">
              Home
            </Link>
            <Link href="/features" className="text-slate-700 hover:text-amber-700 transition-colors">
              Features
            </Link>
            <Link href="/about" className="text-slate-700 hover:text-amber-700 transition-colors">
              About
            </Link>
            <Link href="/get-started" className="text-amber-700 font-medium">
              Get Started
            </Link>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-br from-green-50 to-blue-50">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-5xl font-bold text-slate-800 mb-6">
            Start Your
            <span className="text-green-600"> Spiritual Journey</span>
          </h1>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto mb-8">
            Learn how to make the most of AI Devotional's powerful Bible study tools. From your first search to advanced
            study techniques, we'll guide you every step of the way.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" asChild className="bg-green-600 hover:bg-green-700">
              <Link href="/#features">Start Using Now</Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="#quick-start">View Quick Start Guide</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="max-w-6xl mx-auto">
            <TabsList className="grid w-full grid-cols-4 mb-8">
              <TabsTrigger value="quick-start">Quick Start</TabsTrigger>
              <TabsTrigger value="tutorials">Tutorials</TabsTrigger>
              <TabsTrigger value="tips">Tips & Best Practices</TabsTrigger>
              <TabsTrigger value="faq">FAQ</TabsTrigger>
            </TabsList>

            {/* Quick Start Tab */}
            <TabsContent value="quick-start" id="quick-start">
              <div className="text-center mb-12">
                <h2 className="text-3xl font-bold text-slate-800 mb-4">Get Started in 4 Simple Steps</h2>
                <p className="text-slate-600 max-w-2xl mx-auto">
                  Follow this quick guide to start using AI Devotional effectively in just a few minutes
                </p>
              </div>

              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
                {quickStartSteps.map((step) => {
                  const IconComponent = step.icon
                  return (
                    <Card key={step.step} className="text-center relative">
                      <CardHeader>
                        <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                          <IconComponent className="w-6 h-6 text-green-600" />
                        </div>
                        <div className="absolute -top-3 -right-3 w-8 h-8 bg-green-600 text-white rounded-full flex items-center justify-center text-sm font-bold">
                          {step.step}
                        </div>
                        <CardTitle className="text-lg">{step.title}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-slate-600 mb-4">{step.description}</p>
                        <Button size="sm" variant="outline" asChild>
                          <Link href={step.link}>{step.action}</Link>
                        </Button>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>

              <div className="bg-green-50 border border-green-200 rounded-lg p-6 text-center">
                <h3 className="text-xl font-semibold text-green-800 mb-2">Ready to Begin?</h3>
                <p className="text-green-700 mb-4">
                  All features are free to use. No credit card required, no complicated setup.
                </p>
                <Button asChild className="bg-green-600 hover:bg-green-700">
                  <Link href="/#features">Start Your First Search</Link>
                </Button>
              </div>
            </TabsContent>

            {/* Tutorials Tab */}
            <TabsContent value="tutorials">
              <div className="text-center mb-12">
                <h2 className="text-3xl font-bold text-slate-800 mb-4">Step-by-Step Tutorials</h2>
                <p className="text-slate-600 max-w-2xl mx-auto">
                  Detailed guides for each feature to help you become a power user
                </p>
              </div>

              <div className="space-y-8">
                {tutorials.map((tutorial) => {
                  const IconComponent = tutorial.icon
                  return (
                    <Card key={tutorial.id}>
                      <CardHeader>
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                            <IconComponent className="w-6 h-6 text-blue-600" />
                          </div>
                          <div className="flex-1">
                            <CardTitle className="text-xl">{tutorial.title}</CardTitle>
                            <p className="text-slate-600">{tutorial.description}</p>
                          </div>
                          <div className="flex gap-2">
                            <Badge variant="secondary">{tutorial.duration}</Badge>
                            <Badge variant="outline">{tutorial.difficulty}</Badge>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="grid lg:grid-cols-2 gap-6">
                          <div>
                            <h4 className="font-semibold mb-3">Steps:</h4>
                            <ol className="space-y-2">
                              {tutorial.steps.map((step, index) => (
                                <li key={index} className="flex items-start gap-3">
                                  <span className="w-6 h-6 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-sm font-medium flex-shrink-0 mt-0.5">
                                    {index + 1}
                                  </span>
                                  <span className="text-slate-700">{step}</span>
                                </li>
                              ))}
                            </ol>
                          </div>
                          <div>
                            <h4 className="font-semibold mb-3">Try These Examples:</h4>
                            <div className="space-y-2">
                              {tutorial.examples.map((example, index) => (
                                <div key={index} className="bg-slate-50 rounded px-3 py-2">
                                  <code className="text-sm text-slate-700">"{example}"</code>
                                </div>
                              ))}
                            </div>
                            <Button size="sm" className="mt-4" asChild>
                              <Link href="/#features">
                                <Play className="w-4 h-4 mr-2" />
                                Try This Feature
                              </Link>
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            </TabsContent>

            {/* Tips Tab */}
            <TabsContent value="tips">
              <div className="text-center mb-12">
                <h2 className="text-3xl font-bold text-slate-800 mb-4">Tips & Best Practices</h2>
                <p className="text-slate-600 max-w-2xl mx-auto">
                  Expert advice to help you get the most out of your Bible study experience
                </p>
              </div>

              <div className="grid lg:grid-cols-3 gap-8">
                {tips.map((category, index) => {
                  const IconComponent = category.icon
                  return (
                    <Card key={index}>
                      <CardHeader>
                        <div className="flex items-center gap-3">
                          <IconComponent className="w-8 h-8 text-amber-600" />
                          <CardTitle className="text-xl">{category.category}</CardTitle>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-3">
                          {category.items.map((tip, tipIndex) => (
                            <li key={tipIndex} className="flex items-start gap-2">
                              <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                              <span className="text-slate-700 text-sm">{tip}</span>
                            </li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>

              <div className="mt-12 bg-amber-50 border border-amber-200 rounded-lg p-6">
                <h3 className="text-xl font-semibold text-amber-800 mb-4 flex items-center gap-2">
                  <Star className="w-5 h-5" />
                  Pro Tip: Make It Personal
                </h3>
                <p className="text-amber-700 mb-4">
                  The most effective Bible study happens when you connect Scripture to your personal life. Use our
                  devotional generator to explore topics you're currently facing, and don't be afraid to ask specific
                  questions about your circumstances.
                </p>
                <Button size="sm" variant="outline" asChild>
                  <Link href="/#features">Generate a Personal Devotional</Link>
                </Button>
              </div>
            </TabsContent>

            {/* FAQ Tab */}
            <TabsContent value="faq">
              <div className="text-center mb-12">
                <h2 className="text-3xl font-bold text-slate-800 mb-4">Frequently Asked Questions</h2>
                <p className="text-slate-600 max-w-2xl mx-auto">
                  Find answers to common questions about using AI Devotional
                </p>
              </div>

              <div className="max-w-4xl mx-auto space-y-6">
                {faqs.map((faq, index) => (
                  <Card key={index}>
                    <CardHeader>
                      <CardTitle className="text-lg flex items-center gap-3">
                        <HelpCircle className="w-5 h-5 text-blue-600" />
                        {faq.question}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-slate-700">{faq.answer}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <div className="mt-12 text-center">
                <h3 className="text-xl font-semibold text-slate-800 mb-4">Still Have Questions?</h3>
                <p className="text-slate-600 mb-6">
                  We're here to help! Reach out to our support team for personalized assistance.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button variant="outline" asChild>
                    <a href="mailto:support@aidevotional.com">Email Support</a>
                  </Button>
                  <Button variant="outline" asChild>
                    <Link href="/about#team">Contact Our Team</Link>
                  </Button>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Examples Section */}
      <section id="examples" className="py-16 bg-slate-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-slate-800 mb-4">See It in Action</h2>
            <p className="text-slate-600 max-w-2xl mx-auto">
              Watch how AI Devotional transforms simple queries into meaningful spiritual insights
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <Card>
              <CardHeader>
                <Search className="w-8 h-8 text-blue-600 mb-2" />
                <CardTitle>Bible Search Example</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div>
                    <span className="text-sm font-medium text-slate-600">Query:</span>
                    <div className="bg-slate-100 rounded p-2 mt-1">
                      <code className="text-sm">"verses about God's love"</code>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-400 mx-auto" />
                  <div>
                    <span className="text-sm font-medium text-slate-600">Results:</span>
                    <div className="bg-blue-50 rounded p-3 mt-1">
                      <p className="text-sm text-blue-800">John 3:16, Romans 8:38-39, 1 John 4:19</p>
                      <p className="text-xs text-blue-600 mt-2">+ AI-generated summary and context</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <BookOpen className="w-8 h-8 text-green-600 mb-2" />
                <CardTitle>Concordance Example</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div>
                    <span className="text-sm font-medium text-slate-600">Word:</span>
                    <div className="bg-slate-100 rounded p-2 mt-1">
                      <code className="text-sm">"faith"</code>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-400 mx-auto" />
                  <div>
                    <span className="text-sm font-medium text-slate-600">Study:</span>
                    <div className="bg-green-50 rounded p-3 mt-1">
                      <p className="text-sm text-green-800">Definition, key verses, themes</p>
                      <p className="text-xs text-green-600 mt-2">+ Cross-references and context</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <Heart className="w-8 h-8 text-amber-600 mb-2" />
                <CardTitle>Devotional Example</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div>
                    <span className="text-sm font-medium text-slate-600">Topic:</span>
                    <div className="bg-slate-100 rounded p-2 mt-1">
                      <code className="text-sm">"dealing with anxiety"</code>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-400 mx-auto" />
                  <div>
                    <span className="text-sm font-medium text-slate-600">Devotional:</span>
                    <div className="bg-amber-50 rounded p-3 mt-1">
                      <p className="text-sm text-amber-800">Structured study with Philippians 4:6-7</p>
                      <p className="text-xs text-amber-600 mt-2">+ Reflection questions & applications</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="text-center mt-8">
            <Button size="lg" asChild className="bg-slate-600 hover:bg-slate-700">
              <Link href="/#features">Try These Examples Yourself</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Premium CTA */}
      <section id="premium" className="py-16 bg-amber-600">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">Ready to Go Deeper?</h2>
          <p className="text-xl text-amber-100 mb-8 max-w-2xl mx-auto">
            Unlock premium features to save your devotionals, track your spiritual journey, and access advanced study
            tools.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              onClick={() => setShowAuthModal(true)}
              className="bg-white text-amber-600 hover:bg-amber-50"
            >
              {user ? "Upgrade to Premium" : "Sign Up for Premium"}
            </Button>
            <Button
              size="lg"
              variant="outline"
              asChild
              className="border-white text-white hover:bg-white hover:text-amber-600"
            >
              <Link href="/features#premium">Learn About Premium</Link>
            </Button>
          </div>
          <p className="text-amber-100 text-sm mt-4">$4.99/month • Cancel anytime • 30-day money-back guarantee</p>
        </div>
      </section>

      <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />
    </div>
  )
}
