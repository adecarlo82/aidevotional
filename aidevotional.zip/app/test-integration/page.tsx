"use client"

import { useAuth } from "@/components/auth/auth-provider"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useState } from "react"
import { CheckCircle, XCircle, Clock, CreditCard, Database, User } from "lucide-react"

interface TestResult {
  name: string
  status: "pending" | "success" | "error"
  message: string
  data?: any
}

export default function TestIntegrationPage() {
  const { user, loading } = useAuth()
  const [tests, setTests] = useState<TestResult[]>([])
  const [runningTests, setRunningTests] = useState(false)

  const updateTest = (name: string, status: TestResult["status"], message: string, data?: any) => {
    setTests((prev) => prev.map((test) => (test.name === name ? { ...test, status, message, data } : test)))
  }

  const runTests = async () => {
    if (!user) return

    setRunningTests(true)
    setTests([
      { name: "Auth Check", status: "pending", message: "Checking authentication..." },
      { name: "Supabase Connection", status: "pending", message: "Testing database connection..." },
      { name: "Subscription Status", status: "pending", message: "Checking subscription..." },
      { name: "Stripe Integration", status: "pending", message: "Testing Stripe connection..." },
      { name: "Premium Access", status: "pending", message: "Testing premium feature access..." },
    ])

    // Test 1: Auth Check
    try {
      if (user) {
        updateTest("Auth Check", "success", `Authenticated as ${user.email}`, {
          userId: user.id,
          email: user.email,
          createdAt: user.created_at,
        })
      } else {
        updateTest("Auth Check", "error", "No authenticated user found")
      }
    } catch (error) {
      updateTest("Auth Check", "error", `Auth error: ${error}`)
    }

    // Test 2: Supabase Connection
    try {
      const response = await fetch("/api/debug/subscription")
      const data = await response.json()

      if (response.ok) {
        updateTest("Supabase Connection", "success", "Database connection successful", data)
      } else {
        updateTest("Supabase Connection", "error", `Database error: ${data.error}`)
      }
    } catch (error) {
      updateTest("Supabase Connection", "error", `Connection failed: ${error}`)
    }

    // Test 3: Subscription Status
    try {
      const response = await fetch("/api/user/subscription")
      const data = await response.json()

      if (response.ok) {
        updateTest(
          "Subscription Status",
          "success",
          `Subscription check complete. Status: ${data.hasActiveSubscription ? "ACTIVE" : "INACTIVE"}`,
          data,
        )
      } else {
        updateTest("Subscription Status", "error", `Subscription check failed: ${data.error}`)
      }
    } catch (error) {
      updateTest("Subscription Status", "error", `Subscription check error: ${error}`)
    }

    // Test 4: Stripe Integration (test checkout creation)
    try {
      const response = await fetch("/api/stripe/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      })
      const data = await response.json()

      if (response.ok && data.url) {
        updateTest("Stripe Integration", "success", "Stripe checkout session created successfully", {
          checkoutUrl: data.url,
        })
      } else {
        updateTest("Stripe Integration", "error", `Stripe error: ${data.error}`)
      }
    } catch (error) {
      updateTest("Stripe Integration", "error", `Stripe integration error: ${error}`)
    }

    // Test 5: Premium Access
    try {
      const response = await fetch("/complete-devotional")
      if (response.ok) {
        updateTest("Premium Access", "success", "Premium pages accessible")
      } else {
        updateTest("Premium Access", "error", "Premium pages not accessible")
      }
    } catch (error) {
      updateTest("Premium Access", "error", `Premium access error: ${error}`)
    }

    setRunningTests(false)
  }

  const createTestSubscription = async () => {
    try {
      const response = await fetch("/api/stripe/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      })
      const data = await response.json()

      if (data.url) {
        window.open(data.url, "_blank")
      }
    } catch (error) {
      console.error("Error creating test subscription:", error)
    }
  }

  const getStatusIcon = (status: TestResult["status"]) => {
    switch (status) {
      case "success":
        return <CheckCircle className="w-5 h-5 text-green-500" />
      case "error":
        return <XCircle className="w-5 h-5 text-red-500" />
      case "pending":
        return <Clock className="w-5 h-5 text-yellow-500 animate-pulse" />
    }
  }

  const getStatusBadge = (status: TestResult["status"]) => {
    switch (status) {
      case "success":
        return <Badge className="bg-green-100 text-green-800">Success</Badge>
      case "error":
        return <Badge className="bg-red-100 text-red-800">Error</Badge>
      case "pending":
        return <Badge className="bg-yellow-100 text-yellow-800">Pending</Badge>
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-amber-600 mx-auto"></div>
          <p className="mt-2 text-slate-600">Loading...</p>
        </div>
      </div>
    )
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="text-center py-8">
            <User className="w-12 h-12 text-slate-400 mx-auto mb-4" />
            <p className="text-slate-600 mb-4">Please sign in to test the integration</p>
            <Button onClick={() => (window.location.href = "/")}>Go to Home & Sign In</Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-4xl mx-auto">
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="w-6 h-6" />
              Integration Test Suite
            </CardTitle>
            <CardDescription>Test the complete flow from app → Stripe → Supabase → app</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4 mb-6">
              <Button onClick={runTests} disabled={runningTests}>
                {runningTests ? "Running Tests..." : "Run All Tests"}
              </Button>
              <Button onClick={createTestSubscription} variant="outline">
                <CreditCard className="w-4 h-4 mr-2" />
                Create Test Subscription
              </Button>
              <Button variant="outline" onClick={() => (window.location.href = "/")}>
                Back to Home
              </Button>
            </div>

            {tests.length > 0 && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Test Results</h3>
                {tests.map((test, index) => (
                  <Card key={index}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-3">
                          {getStatusIcon(test.status)}
                          <span className="font-medium">{test.name}</span>
                        </div>
                        {getStatusBadge(test.status)}
                      </div>
                      <p className="text-sm text-slate-600 mb-2">{test.message}</p>
                      {test.data && (
                        <details className="mt-2">
                          <summary className="text-xs text-slate-400 cursor-pointer">View Details</summary>
                          <pre className="text-xs bg-slate-100 p-2 rounded mt-1 overflow-auto max-h-40">
                            {JSON.stringify(test.data, null, 2)}
                          </pre>
                        </details>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Test Instructions */}
        <Card>
          <CardHeader>
            <CardTitle>Testing Instructions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h4 className="font-semibold mb-2">1. Create Test Account</h4>
              <p className="text-sm text-slate-600">
                Sign up with a test email (e.g., test@example.com) using the sign-in modal on the home page.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-2">2. Test Stripe Integration</h4>
              <p className="text-sm text-slate-600 mb-2">
                Click "Create Test Subscription" to test the Stripe checkout flow. Use these test card numbers:
              </p>
              <ul className="text-sm text-slate-600 space-y-1 ml-4">
                <li>
                  • <code>4242 4242 4242 4242</code> - Successful payment
                </li>
                <li>
                  • <code>4000 0000 0000 0002</code> - Declined payment
                </li>
                <li>• Any future expiry date and any 3-digit CVC</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-2">3. Verify Database Updates</h4>
              <p className="text-sm text-slate-600">
                After completing a test subscription, check that the webhook properly updates your subscription status
                in Supabase.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-2">4. Test Premium Access</h4>
              <p className="text-sm text-slate-600">
                Try accessing premium features (/complete-devotional, /prayer-list, /reading-plan) to verify access
                control works correctly.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
