"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function StripeDebugPage() {
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [data, setData] = useState<any>(null)

  async function checkStripeEnv() {
    setLoading(true)
    setError(null)

    try {
      const response = await fetch("/api/debug/stripe-env")
      const result = await response.json()

      if (response.ok) {
        setData(result)
      } else {
        setError(result.message || "Error checking Stripe environment")
      }
    } catch (err: any) {
      setError(err.message || "Failed to check Stripe environment")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    checkStripeEnv()
  }, [])

  return (
    <div className="container py-10">
      <h1 className="text-3xl font-bold mb-6">Stripe Environment Debug</h1>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Stripe Configuration</CardTitle>
          <CardDescription>Check if your Stripe environment is properly configured</CardDescription>
        </CardHeader>

        <CardContent>
          {loading && <p>Loading Stripe configuration...</p>}

          {error && (
            <div className="p-4 bg-red-50 border border-red-200 rounded-md text-red-700 mb-4">
              <p className="font-semibold">Error:</p>
              <p>{error}</p>
            </div>
          )}

          {data && (
            <div className="space-y-4">
              <div className="p-4 bg-gray-50 rounded-md">
                <h3 className="font-medium mb-2">Environment</h3>
                <p>
                  <strong>Mode:</strong> {data.isTestMode ? "Test Mode ✅" : "Live Mode ⚠️"}
                </p>
                <p>
                  <strong>Secret Key:</strong> {data.envCheck.secretKeyPrefix}
                </p>
                <p>
                  <strong>Price ID:</strong> {data.envCheck.priceId}
                </p>
              </div>

              {data.balance && (
                <div className="p-4 bg-gray-50 rounded-md">
                  <h3 className="font-medium mb-2">Stripe Balance</h3>
                  <p>Available: {JSON.stringify(data.balance.available)}</p>
                  <p>Pending: {JSON.stringify(data.balance.pending)}</p>
                </div>
              )}

              {data.priceInfo && (
                <div className="p-4 bg-gray-50 rounded-md">
                  <h3 className="font-medium mb-2">Price Information</h3>
                  {data.priceInfo.exists ? (
                    <div>
                      <p className="text-green-600">✅ Price found in Stripe</p>
                      <p>
                        <strong>ID:</strong> {data.priceInfo.data?.id}
                      </p>
                      <p>
                        <strong>Amount:</strong>{" "}
                        {data.priceInfo.data?.unit_amount ? (data.priceInfo.data.unit_amount / 100).toFixed(2) : "N/A"}{" "}
                        {data.priceInfo.data?.currency?.toUpperCase()}
                      </p>
                      <p>
                        <strong>Recurring:</strong>{" "}
                        {data.priceInfo.data?.recurring
                          ? `${data.priceInfo.data.recurring.interval_count} ${data.priceInfo.data.recurring.interval}`
                          : "One-time"}
                      </p>
                    </div>
                  ) : (
                    <div className="text-red-600">
                      <p>❌ Price not found or error</p>
                      {data.priceInfo.error && <p>Error: {data.priceInfo.error}</p>}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </CardContent>

        <CardFooter>
          <Button onClick={checkStripeEnv} disabled={loading}>
            {loading ? "Checking..." : "Refresh"}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
