"use client"

import { useState } from "react"
import { SubscriptionGuard } from "@/components/subscription-guard"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar, BookOpen, Check, Clock, Target, TrendingUp } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

interface ReadingPlan {
  id: string
  name: string
  description: string
  duration: number // days
  type: "chronological" | "canonical" | "thematic" | "new-testament" | "psalms-proverbs"
  readings: ReadingDay[]
}

interface ReadingDay {
  day: number
  date: string
  passages: string[]
  completed: boolean
  notes?: string
}

const availablePlans: Omit<ReadingPlan, "readings">[] = [
  {
    id: "bible-year",
    name: "Bible in a Year",
    description:
      "Read through the entire Bible in 365 days with a mix of Old Testament, New Testament, Psalms, and Proverbs",
    duration: 365,
    type: "canonical",
  },
  {
    id: "chronological-year",
    name: "Chronological Bible Reading",
    description: "Read the Bible in the order events occurred historically",
    duration: 365,
    type: "chronological",
  },
  {
    id: "new-testament-90",
    name: "New Testament in 90 Days",
    description: "Focus on the New Testament with manageable daily readings",
    duration: 90,
    type: "new-testament",
  },
  {
    id: "psalms-proverbs-month",
    name: "Psalms & Proverbs Monthly",
    description: "Read through Psalms and Proverbs each month for wisdom and worship",
    duration: 31,
    type: "psalms-proverbs",
  },
]

export default function ReadingPlanPage() {
  const [currentPlan, setCurrentPlan] = useState<ReadingPlan | null>(null)
  const [selectedPlanId, setSelectedPlanId] = useState<string>("")
  const [startDate, setStartDate] = useState<string>(new Date().toISOString().split("T")[0])

  const startPlan = (planId: string) => {
    const planTemplate = availablePlans.find((p) => p.id === planId)
    if (!planTemplate) return

    const readings: ReadingDay[] = []
    const start = new Date(startDate)

    // Generate sample readings (in a real app, this would come from a comprehensive database)
    for (let i = 0; i < planTemplate.duration; i++) {
      const currentDate = new Date(start)
      currentDate.setDate(start.getDate() + i)

      let passages: string[] = []

      switch (planTemplate.type) {
        case "canonical":
          if (i < 100) passages = [`Genesis ${Math.floor(i / 2) + 1}:1-25`]
          else if (i < 200) passages = [`Matthew ${Math.floor((i - 100) / 3) + 1}:1-20`]
          else passages = [`Psalms ${i - 200 + 1}:1-10`]
          break
        case "new-testament":
          passages = [`Matthew ${Math.floor(i / 3) + 1}:${(i % 3) * 10 + 1}-${((i % 3) + 1) * 10}`]
          break
        case "psalms-proverbs":
          passages = [`Psalms ${(i % 31) + 1}`, `Proverbs ${(i % 31) + 1}`]
          break
        default:
          passages = [`Genesis ${i + 1}:1-25`]
      }

      readings.push({
        day: i + 1,
        date: currentDate.toISOString().split("T")[0],
        passages,
        completed: false,
      })
    }

    const newPlan: ReadingPlan = {
      ...planTemplate,
      readings,
    }

    setCurrentPlan(newPlan)
  }

  const markDayComplete = (day: number) => {
    if (!currentPlan) return

    setCurrentPlan((prev) => ({
      ...prev!,
      readings: prev!.readings.map((reading) =>
        reading.day === day ? { ...reading, completed: !reading.completed } : reading,
      ),
    }))
  }

  const getProgress = () => {
    if (!currentPlan) return 0
    const completed = currentPlan.readings.filter((r) => r.completed).length
    return (completed / currentPlan.readings.length) * 100
  }

  const getTodaysReading = () => {
    if (!currentPlan) return null
    const today = new Date().toISOString().split("T")[0]
    return currentPlan.readings.find((r) => r.date === today)
  }

  const getStreak = () => {
    if (!currentPlan) return 0
    let streak = 0
    const sortedReadings = [...currentPlan.readings].sort(
      (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime(),
    )

    for (let i = sortedReadings.length - 1; i >= 0; i--) {
      if (sortedReadings[i].completed) {
        streak++
      } else {
        break
      }
    }
    return streak
  }

  const todaysReading = getTodaysReading()
  const progress = getProgress()
  const streak = getStreak()

  return (
    <SubscriptionGuard featureName="Bible Reading Plan">
      <div className="min-h-screen bg-white">
        {/* Header */}
        <header className="bg-white/80 backdrop-blur-sm border-b border-amber-200 sticky top-0 z-50">
          <div className="container mx-auto px-4 py-4 flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-3">
              <Image src="/logo.png" alt="AI Devotional Logo" width={80} height={80} className="object-contain" />
            </Link>
            <nav className="hidden md:flex items-center space-x-6">
              <Link href="/" className="text-slate-700 hover:text-amber-700 transition-colors">
                Home
              </Link>
              <Link href="/complete-devotional" className="text-slate-700 hover:text-amber-700 transition-colors">
                Complete Devotional
              </Link>
              <Link href="/prayer-list" className="text-slate-700 hover:text-amber-700 transition-colors">
                Prayer List
              </Link>
              <Link href="/reading-plan" className="text-amber-700 font-medium">
                Reading Plan
              </Link>
            </nav>
          </div>
        </header>

        {/* Main Content */}
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-6xl mx-auto">
            {/* Page Header */}
            <div className="text-center mb-8">
              <div className="flex items-center justify-center gap-3 mb-4">
                <BookOpen className="w-8 h-8 text-green-600" />
                <h1 className="text-4xl font-bold text-slate-800">Bible Reading Plan</h1>
                <Badge className="bg-green-600">Premium</Badge>
              </div>
              <p className="text-xl text-slate-600 max-w-2xl mx-auto">
                Stay consistent in your Bible reading with personalized plans and progress tracking
              </p>
            </div>

            {!currentPlan ? (
              /* Plan Selection */
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Choose Your Reading Plan</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">Select a Plan</label>
                      <Select value={selectedPlanId} onValueChange={setSelectedPlanId}>
                        <SelectTrigger>
                          <SelectValue placeholder="Choose a reading plan..." />
                        </SelectTrigger>
                        <SelectContent>
                          {availablePlans.map((plan) => (
                            <SelectItem key={plan.id} value={plan.id}>
                              {plan.name} ({plan.duration} days)
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">Start Date</label>
                      <input
                        type="date"
                        value={startDate}
                        onChange={(e) => setStartDate(e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                      />
                    </div>

                    <Button
                      onClick={() => startPlan(selectedPlanId)}
                      disabled={!selectedPlanId}
                      className="w-full bg-green-600 hover:bg-green-700"
                    >
                      Start Reading Plan
                    </Button>
                  </CardContent>
                </Card>

                {/* Plan Details */}
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {availablePlans.map((plan) => (
                    <Card
                      key={plan.id}
                      className={`cursor-pointer transition-all ${selectedPlanId === plan.id ? "ring-2 ring-green-500" : ""}`}
                      onClick={() => setSelectedPlanId(plan.id)}
                    >
                      <CardHeader>
                        <CardTitle className="text-lg">{plan.name}</CardTitle>
                        <Badge variant="outline">{plan.duration} days</Badge>
                      </CardHeader>
                      <CardContent>
                        <p className="text-slate-600 text-sm">{plan.description}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            ) : (
              /* Active Plan Dashboard */
              <div className="space-y-6">
                {/* Progress Overview */}
                <div className="grid md:grid-cols-4 gap-4">
                  <Card>
                    <CardContent className="p-4 text-center">
                      <TrendingUp className="w-8 h-8 text-green-600 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-green-600">{progress.toFixed(0)}%</div>
                      <div className="text-sm text-slate-600">Complete</div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-4 text-center">
                      <Target className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-blue-600">{streak}</div>
                      <div className="text-sm text-slate-600">Day Streak</div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-4 text-center">
                      <Calendar className="w-8 h-8 text-amber-600 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-amber-600">
                        {currentPlan.readings.filter((r) => r.completed).length}
                      </div>
                      <div className="text-sm text-slate-600">Days Read</div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-4 text-center">
                      <Clock className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-purple-600">
                        {currentPlan.duration - currentPlan.readings.filter((r) => r.completed).length}
                      </div>
                      <div className="text-sm text-slate-600">Days Left</div>
                    </CardContent>
                  </Card>
                </div>

                {/* Progress Bar */}
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle>{currentPlan.name}</CardTitle>
                      <Button variant="outline" onClick={() => setCurrentPlan(null)}>
                        Change Plan
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Progress value={progress} className="mb-2" />
                    <p className="text-sm text-slate-600">
                      {currentPlan.readings.filter((r) => r.completed).length} of {currentPlan.readings.length} days
                      completed
                    </p>
                  </CardContent>
                </Card>

                {/* Today's Reading */}
                {todaysReading && (
                  <Card className="border-green-200">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Calendar className="w-5 h-5 text-green-600" />
                        Today's Reading - Day {todaysReading.day}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {todaysReading.passages.map((passage, index) => (
                          <div key={index} className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                            <span className="font-medium text-green-800">{passage}</span>
                            <Button
                              size="sm"
                              variant={todaysReading.completed ? "default" : "outline"}
                              onClick={() => markDayComplete(todaysReading.day)}
                              className={todaysReading.completed ? "bg-green-600 hover:bg-green-700" : ""}
                            >
                              {todaysReading.completed ? (
                                <>
                                  <Check className="w-4 h-4 mr-1" />
                                  Completed
                                </>
                              ) : (
                                "Mark Complete"
                              )}
                            </Button>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Reading History */}
                <Card>
                  <CardHeader>
                    <CardTitle>Reading History</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="max-h-96 overflow-y-auto space-y-2">
                      {currentPlan.readings.slice(0, 14).map((reading) => (
                        <div
                          key={reading.day}
                          className={`flex items-center justify-between p-3 rounded-lg border ${
                            reading.completed ? "bg-green-50 border-green-200" : "bg-gray-50 border-gray-200"
                          }`}
                        >
                          <div>
                            <div className="font-medium">Day {reading.day}</div>
                            <div className="text-sm text-slate-600">{reading.passages.join(", ")}</div>
                            <div className="text-xs text-slate-500">{new Date(reading.date).toLocaleDateString()}</div>
                          </div>
                          <Button
                            size="sm"
                            variant={reading.completed ? "default" : "outline"}
                            onClick={() => markDayComplete(reading.day)}
                          >
                            {reading.completed ? <Check className="w-4 h-4" /> : "Mark Complete"}
                          </Button>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </div>
        </div>
      </div>
    </SubscriptionGuard>
  )
}
