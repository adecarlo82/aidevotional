"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function ApiTestPage() {
  const [results, setResults] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const testApi = async (endpoint: string, name: string) => {
    setLoading(true)
    setError(null)
    setResults(null)

    try {
      console.log(`Testing ${name} at ${endpoint}`)

      const response = await fetch(endpoint)
      console.log(`Response status: ${response.status}`)

      const text = await response.text()
      console.log(`Response text: ${text}`)

      if (response.ok) {
        try {
          const data = JSON.parse(text)
          setResults({ endpoint, name, success: true, data })
        } catch (parseError) {
          setError(`Failed to parse JSON from ${name}: ${text}`)
        }
      } else {
        setError(`${name} failed with status ${response.status}: ${text}`)
      }
    } catch (err) {
      console.error(`Error testing ${name}:`, err)
      setError(`${name} error: ${err instanceof Error ? err.message : "Unknown error"}`)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto p-6">
      <Card>
        <CardHeader>
          <CardTitle>Bible API Test</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-4 flex-wrap">
            <Button onClick={() => testApi("/api/bible-test", "Basic API")} disabled={loading}>
              Test Basic API
            </Button>
            <Button
              onClick={() => testApi("/api/bible-test/rapidapi", "RapidAPI")}
              disabled={loading}
              variant="outline"
            >
              Test RapidAPI
            </Button>
          </div>

          {loading && (
            <div className="bg-blue-50 border border-blue-200 p-4 rounded-md">
              <p>Testing API... Check console for details.</p>
            </div>
          )}

          {error && (
            <div className="bg-red-50 border border-red-200 p-4 rounded-md">
              <h3 className="font-semibold text-red-700">Error:</h3>
              <p className="text-red-600">{error}</p>
            </div>
          )}

          {results && (
            <div className="bg-green-50 border border-green-200 p-4 rounded-md">
              <h3 className="font-semibold text-green-700">Success!</h3>
              <p>
                <strong>Endpoint:</strong> {results.endpoint}
              </p>
              <p>
                <strong>Test:</strong> {results.name}
              </p>
              <pre className="text-sm overflow-auto mt-2 bg-white p-2 rounded border">
                {JSON.stringify(results.data, null, 2)}
              </pre>
            </div>
          )}

          <div className="bg-gray-50 border border-gray-200 p-4 rounded-md">
            <h3 className="font-semibold text-gray-700">Manual Test URLs:</h3>
            <ul className="text-sm space-y-1 mt-2">
              <li>
                <a href="/api/bible-test" target="_blank" className="text-blue-600 hover:underline" rel="noreferrer">
                  /api/bible-test
                </a>
              </li>
              <li>
                <a
                  href="/api/bible-test/rapidapi"
                  target="_blank"
                  className="text-blue-600 hover:underline"
                  rel="noreferrer"
                >
                  /api/bible-test/rapidapi
                </a>
              </li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
