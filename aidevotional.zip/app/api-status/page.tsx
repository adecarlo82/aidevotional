"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function ApiStatus() {
  const [status, setStatus] = useState({
    rapidApi: {
      working: false,
      endpoints: {
        books: false,
        search: false,
        verse: false,
        chapter: false,
      },
      workingEndpoints: [] as string[],
    },
    localDb: {
      working: true,
    },
    lastChecked: "",
    error: null as string | null,
  })
  const [loading, setLoading] = useState(false)

  const checkStatus = async () => {
    setLoading(true)
    setStatus((prev) => ({ ...prev, error: null }))

    try {
      console.log("🔍 Checking API status...")

      // Test RapidAPI directly with a simple fetch
      const rapidApiTest = await testRapidApiDirectly()

      // Test local database by checking if it exists
      const localDbTest = await testLocalDatabase()

      setStatus({
        rapidApi: {
          working: rapidApiTest.success,
          endpoints: {
            books: rapidApiTest.endpoints?.books || false,
            search: rapidApiTest.endpoints?.search || false,
            verse: rapidApiTest.endpoints?.verse || false,
            chapter: rapidApiTest.endpoints?.chapter || false,
          },
          workingEndpoints: rapidApiTest.workingEndpoints || [],
        },
        localDb: {
          working: localDbTest.success,
        },
        lastChecked: new Date().toISOString(),
        error: null,
      })

      console.log("✅ Status check completed")
    } catch (error) {
      console.error("❌ Error checking API status:", error)
      setStatus((prev) => ({
        ...prev,
        error: error instanceof Error ? error.message : "Unknown error occurred",
        lastChecked: new Date().toISOString(),
      }))
    } finally {
      setLoading(false)
    }
  }

  // Test RapidAPI directly
  const testRapidApiDirectly = async () => {
    try {
      const response = await fetch("/api/bible-test/rapidapi")
      const data = await response.json()

      return {
        success: data.success || false,
        endpoints: data.endpoints || {},
        workingEndpoints: data.workingEndpoints || [],
        details: data.details || "No details available",
      }
    } catch (error) {
      console.error("RapidAPI test failed:", error)
      return {
        success: false,
        endpoints: {},
        workingEndpoints: [],
        details: "Failed to test RapidAPI",
      }
    }
  }

  // Test local database
  const testLocalDatabase = async () => {
    try {
      // Try to search for a common verse
      const response = await fetch("/api/ai/search-verses", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ query: "love" }),
      })

      const data = await response.json()

      return {
        success: data.verses && data.verses.length > 0,
        details: `Found ${data.verses?.length || 0} verses`,
      }
    } catch (error) {
      console.error("Local database test failed:", error)
      return {
        success: false,
        details: "Failed to test local database",
      }
    }
  }

  useEffect(() => {
    checkStatus()
  }, [])

  return (
    <div className="container mx-auto p-6">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">Bible API Status</h1>

        <div className="mb-6">
          <Button onClick={checkStatus} disabled={loading} className="w-full">
            {loading ? "Checking Status..." : "Refresh Status"}
          </Button>
        </div>

        {status.error && (
          <Card className="border-red-500 mb-6">
            <CardHeader>
              <CardTitle className="text-red-700">Error</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-red-600">{status.error}</p>
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className={status.rapidApi.working ? "border-green-500" : "border-red-500"}>
            <CardHeader>
              <CardTitle className="flex justify-between items-center">
                <span>RapidAPI Bible Service</span>
                <span
                  className={`px-2 py-1 rounded text-sm ${
                    status.rapidApi.working ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                  }`}
                >
                  {status.rapidApi.working ? "✅ Working" : "❌ Not Working"}
                </span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <h3 className="font-semibold">Endpoint Status:</h3>
                <ul className="space-y-1">
                  <li className="flex justify-between">
                    <span>Books Endpoint:</span>
                    <span>{status.rapidApi.endpoints.books ? "✅ Working" : "❌ Not Working"}</span>
                  </li>
                  <li className="flex justify-between">
                    <span>Search Endpoint:</span>
                    <span>{status.rapidApi.endpoints.search ? "✅ Working" : "❌ Not Working"}</span>
                  </li>
                  <li className="flex justify-between">
                    <span>Verse Endpoint:</span>
                    <span>{status.rapidApi.endpoints.verse ? "✅ Working" : "❌ Not Working"}</span>
                  </li>
                  <li className="flex justify-between">
                    <span>Chapter Endpoint:</span>
                    <span>{status.rapidApi.endpoints.chapter ? "✅ Working" : "❌ Not Working"}</span>
                  </li>
                </ul>

                {status.rapidApi.workingEndpoints.length > 0 && (
                  <div className="mt-4">
                    <h3 className="font-semibold">Working Endpoints:</h3>
                    <ul className="text-sm space-y-1 mt-2">
                      {status.rapidApi.workingEndpoints.map((endpoint, i) => (
                        <li key={i} className="bg-gray-50 p-2 rounded text-xs">
                          {endpoint}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <Card className={status.localDb.working ? "border-green-500" : "border-red-500"}>
            <CardHeader>
              <CardTitle className="flex justify-between items-center">
                <span>Local Bible Database</span>
                <span
                  className={`px-2 py-1 rounded text-sm ${
                    status.localDb.working ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                  }`}
                >
                  {status.localDb.working ? "✅ Working" : "❌ Not Working"}
                </span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p>The local Bible database serves as a reliable fallback when RapidAPI is unavailable.</p>
              <div className="mt-2 text-sm text-gray-600">
                Status: {status.localDb.working ? "Ready to serve verses" : "Database connection failed"}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="mt-6 p-4 bg-blue-50 rounded">
          <h3 className="font-bold mb-2">Current Search Flow:</h3>
          <ol className="list-decimal list-inside space-y-2">
            <li>
              Try RapidAPI Bible Service
              {status.rapidApi.working ? " (Currently Working)" : " (Currently Not Working)"}
            </li>
            <li>
              If RapidAPI fails, fall back to Local Bible Database
              {status.localDb.working ? " (Currently Working)" : " (Currently Not Working)"}
            </li>
            <li>Return results from whichever source succeeded</li>
          </ol>

          <div className="mt-4 text-sm text-gray-600">
            Last checked: {status.lastChecked ? new Date(status.lastChecked).toLocaleString() : "Never"}
          </div>
        </div>

        <div className="mt-6 p-4 bg-gray-50 rounded">
          <h3 className="font-bold mb-2">Test the System:</h3>
          <div className="space-y-2">
            <Button onClick={() => window.open("/get-started", "_blank")} variant="outline" className="w-full">
              🔍 Test Bible Search
            </Button>
            <Button onClick={() => window.open("/test-rapidapi-simple", "_blank")} variant="outline" className="w-full">
              🧪 Test RapidAPI Connection
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
