"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function TestRapidAPIPage() {
  const [results, setResults] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const runSimpleTest = async () => {
    setLoading(true)
    setError(null)
    setResults(null)

    try {
      console.log("🧪 Testing simple route...")

      const response = await fetch("/api/test/simple")
      console.log("📊 Simple test response status:", response.status)

      if (!response.ok) {
        throw new Error(`Simple test failed: ${response.status}`)
      }

      const data = await response.json()
      console.log("✅ Simple test data:", data)

      setResults({ simpleTest: data })
    } catch (err) {
      console.error("❌ Simple test error:", err)
      setError(`Simple test failed: ${err instanceof Error ? err.message : "Unknown error"}`)
    } finally {
      setLoading(false)
    }
  }

  const runRapidApiTest = async () => {
    setLoading(true)
    setError(null)

    try {
      console.log("🧪 Testing RapidAPI route...")

      const response = await fetch("/api/test/rapidapi")
      console.log("📊 RapidAPI test response status:", response.status)

      const responseText = await response.text()
      console.log("📊 RapidAPI test response text:", responseText)

      let data
      try {
        data = JSON.parse(responseText)
      } catch (parseError) {
        console.error("❌ JSON parse error:", parseError)
        throw new Error(`Invalid JSON response: ${responseText}`)
      }

      console.log("✅ RapidAPI test data:", data)

      setResults((prev: any) => ({
        ...prev,
        rapidApiTest: data,
      }))
    } catch (err) {
      console.error("❌ RapidAPI test error:", err)
      setError(`RapidAPI test failed: ${err instanceof Error ? err.message : "Unknown error"}`)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto p-6 max-w-4xl">
      <Card>
        <CardHeader>
          <CardTitle>API Route Testing</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-4">
            <Button onClick={runSimpleTest} disabled={loading} variant="outline">
              {loading ? "Testing..." : "Test Simple Route"}
            </Button>
            <Button onClick={runRapidApiTest} disabled={loading}>
              {loading ? "Testing..." : "Test RapidAPI Route"}
            </Button>
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <h3 className="font-semibold text-red-800">Error:</h3>
              <p className="text-red-700 font-mono text-sm">{error}</p>
            </div>
          )}

          {results && (
            <div className="space-y-4">
              {results.simpleTest && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <h3 className="font-semibold text-green-800">Simple Test Results:</h3>
                  <pre className="text-sm text-green-700 mt-2 overflow-auto">
                    {JSON.stringify(results.simpleTest, null, 2)}
                  </pre>
                </div>
              )}

              {results.rapidApiTest && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <h3 className="font-semibold text-blue-800">RapidAPI Test Results:</h3>
                  <pre className="text-sm text-blue-700 mt-2 overflow-auto">
                    {JSON.stringify(results.rapidApiTest, null, 2)}
                  </pre>

                  {results.rapidApiTest.rapidApiTest && (
                    <div className="mt-4">
                      <h4 className="font-semibold">RapidAPI Status:</h4>
                      <p className={results.rapidApiTest.rapidApiTest.success ? "text-green-600" : "text-red-600"}>
                        {results.rapidApiTest.rapidApiTest.success ? "✅ Working" : "❌ Failed"}
                      </p>
                      {results.rapidApiTest.rapidApiTest.error && (
                        <p className="text-red-600 text-sm">Error: {results.rapidApiTest.rapidApiTest.error}</p>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
            <h3 className="font-semibold text-gray-800">Instructions:</h3>
            <ol className="text-sm text-gray-700 mt-2 space-y-1">
              <li>1. First test the "Simple Route" to ensure API routes work</li>
              <li>2. Then test the "RapidAPI Route" to check the Bible API</li>
              <li>3. Check the browser console for detailed logs</li>
              <li>4. Look for specific error messages in the results</li>
            </ol>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
