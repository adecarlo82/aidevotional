"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { BookOpen, Heart, Brain, Bookmark, Clock, Shield, Zap, CheckCircle, Star } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { AuthModal } from "@/components/auth/auth-modal"
import { useAuth } from "@/components/auth/auth-provider"

const features = [
  {
    id: "ai-search",
    title: "Bible Verse Search",
    description: "Search scripture using natural language and get intelligent, contextual results",
    icon: Brain,
    category: "Core Features",
    tier: "free",
    highlights: [
      "Natural language queries like 'verses about hope'",
      "Intelligent verse matching and ranking",
      "Support for book, chapter, and verse ranges",
      "Webster Bible translation included",
      "Instant search results",
    ],
    demo: {
      input: "verses about God's love for us",
      output: "John 3:16, Romans 8:38-39, 1 John 4:19",
    },
  },
  {
    id: "concordance",
    title: "Bible Concordance",
    description: "Explore biblical concepts with AI-enhanced word studies and cross-references",
    icon: BookOpen,
    category: "Study Tools",
    tier: "free",
    highlights: [
      "Deep word and concept analysis",
      "Related verse discovery",
      "Thematic connections",
      "Biblical context explanations",
      "Cross-reference suggestions",
    ],
    demo: {
      input: "faith",
      output: "Hebrews 11:1, Romans 10:17, James 2:17",
    },
  },
  {
    id: "devotional-outline",
    title: "Devotional Outline",
    description: "Generate basic devotional outlines with scripture and reflection questions",
    icon: Heart,
    category: "Spiritual Growth",
    tier: "free",
    highlights: [
      "Basic devotional structure",
      "Scripture references included",
      "Simple reflection questions",
      "Topic-based content",
      "Quick generation",
    ],
    demo: {
      input: "dealing with anxiety",
      output: "Basic outline with Philippians 4:6-7",
    },
  },
  {
    id: "complete-devotional",
    title: "Complete Devotional",
    description: "Full-featured devotionals with detailed study, applications, and prayers",
    icon: Heart,
    category: "Premium Study",
    tier: "premium",
    highlights: [
      "Comprehensive devotional studies",
      "Detailed biblical commentary",
      "Multiple reflection questions",
      "Practical application steps",
      "Personalized prayers",
      "Save and organize content",
    ],
  },
  {
    id: "prayer-list",
    title: "Prayer List",
    description: "Organize and track your prayer requests with scripture-based encouragement",
    icon: Bookmark,
    category: "Prayer & Worship",
    tier: "premium",
    highlights: [
      "Organize prayer requests by category",
      "Track answered prayers",
      "Scripture verses for each request",
      "Prayer reminders and notifications",
      "Share prayer lists with others",
      "Export prayer journals",
    ],
  },
  {
    id: "reading-plan",
    title: "Bible Reading Plan",
    description: "Personalized Bible reading plans with progress tracking and insights",
    icon: Clock,
    category: "Spiritual Discipline",
    tier: "premium",
    highlights: [
      "Customizable reading schedules",
      "Progress tracking and streaks",
      "Daily reading reminders",
      "Reflection prompts for each reading",
      "Multiple plan options (chronological, thematic, etc.)",
      "Reading history and statistics",
    ],
  },
]

const comparisons = [
  { feature: "Bible Verse Search", free: "✅ Unlimited", premium: "✅ Unlimited" },
  { feature: "Bible Concordance", free: "✅ Unlimited", premium: "✅ Unlimited" },
  { feature: "Devotional Outline", free: "✅ Basic", premium: "✅ Basic" },
  { feature: "Complete Devotional", free: "❌", premium: "✅ Full Featured" },
  { feature: "Prayer List", free: "❌", premium: "✅ Unlimited" },
  { feature: "Bible Reading Plan", free: "❌", premium: "✅ Personalized" },
  { feature: "Save & Export", free: "❌", premium: "✅ All Formats" },
  { feature: "Priority Support", free: "❌", premium: "✅ Email & Chat" },
]

export default function FeaturesPage() {
  const [activeFeature, setActiveFeature] = useState("ai-search")
  const [showAuthModal, setShowAuthModal] = useState(false)
  const { user } = useAuth()

  const currentFeature = features.find((f) => f.id === activeFeature) || features[0]

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-amber-200 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-3">
            <Image src="/logo.png" alt="AI Devotional Logo" width={80} height={80} className="object-contain" />
          </Link>
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/" className="text-slate-700 hover:text-amber-700 transition-colors">
              Home
            </Link>
            <Link href="/features" className="text-amber-700 font-medium">
              Features
            </Link>
            <Link href="/about" className="text-slate-700 hover:text-amber-700 transition-colors">
              About
            </Link>
            <Link href="/get-started" className="text-slate-700 hover:text-amber-700 transition-colors">
              Get Started
            </Link>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-8 bg-gradient-to-br from-amber-50 to-blue-50">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-5xl font-bold text-slate-800 mb-6">
            Powerful Features for Your
            <span className="text-amber-600"> Spiritual Journey</span>
          </h1>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto mb-8">
            Discover how AI-powered tools can transform your Bible study experience with intelligent search,
            personalized devotionals, and comprehensive study resources.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" asChild className="bg-amber-600 hover:bg-amber-700">
              <Link href="/#features">Try Features Now</Link>
            </Button>
            <Button size="lg" variant="outline" onClick={() => setShowAuthModal(true)}>
              {user ? "Upgrade to Premium" : "Sign Up Free"}
            </Button>
          </div>
        </div>
      </section>

      {/* Interactive Feature Demo */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          <div className="text-center mb-6">
            <h2 className="text-3xl font-bold text-slate-800 mb-4">Experience Our Features</h2>
            <p className="text-slate-600 max-w-2xl mx-auto">
              Click on any feature below to see how it works and what makes it special
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {/* Feature List */}
            <div className="lg:col-span-1 space-y-3">
              {features.map((feature) => {
                const IconComponent = feature.icon
                return (
                  <button
                    key={feature.id}
                    onClick={() => setActiveFeature(feature.id)}
                    className={`w-full text-left p-4 rounded-lg border transition-all ${
                      activeFeature === feature.id
                        ? "border-amber-500 bg-amber-50 shadow-md"
                        : "border-gray-200 hover:border-amber-300 hover:bg-amber-25"
                    }`}
                  >
                    <div className="flex items-center gap-3 mb-2">
                      <IconComponent
                        className={`w-5 h-5 ${activeFeature === feature.id ? "text-amber-600" : "text-slate-500"}`}
                      />
                      <span className="font-semibold text-slate-800">{feature.title}</span>
                      <Badge variant={feature.tier === "premium" ? "default" : "secondary"} className="ml-auto">
                        {feature.tier}
                      </Badge>
                    </div>
                    <p className="text-sm text-slate-600">{feature.description}</p>
                  </button>
                )
              })}
            </div>

            {/* Feature Details */}
            <div className="lg:col-span-2">
              <Card className="h-full">
                <CardHeader>
                  <div className="flex items-center gap-3 mb-2">
                    <currentFeature.icon className="w-8 h-8 text-amber-600" />
                    <div>
                      <CardTitle className="text-2xl">{currentFeature.title}</CardTitle>
                      <p className="text-slate-600">{currentFeature.category}</p>
                    </div>
                    <Badge variant={currentFeature.tier === "premium" ? "default" : "secondary"} className="ml-auto">
                      {currentFeature.tier}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  <p className="text-slate-700 text-lg">{currentFeature.description}</p>

                  {/* Demo Section */}
                  {currentFeature.demo && (
                    <div className="bg-slate-50 rounded-lg p-4">
                      <h4 className="font-semibold mb-3 text-slate-800">Try it out:</h4>
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium text-slate-600">Input:</span>
                          <code className="bg-white px-2 py-1 rounded text-sm">{currentFeature.demo.input}</code>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium text-slate-600">Result:</span>
                          <code className="bg-white px-2 py-1 rounded text-sm">{currentFeature.demo.output}</code>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Highlights */}
                  <div>
                    <h4 className="font-semibold mb-3 text-slate-800">Key Features:</h4>
                    <ul className="space-y-2">
                      {currentFeature.highlights.map((highlight, index) => (
                        <li key={index} className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                          <span className="text-slate-700">{highlight}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {currentFeature.tier === "premium" && !user && (
                    <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Star className="w-5 h-5 text-amber-600" />
                        <span className="font-semibold text-amber-800">Premium Feature</span>
                      </div>
                      <p className="text-amber-700 text-sm mb-3">
                        This feature is available with a premium subscription. Sign up to unlock advanced capabilities!
                      </p>
                      <Button
                        size="sm"
                        onClick={() => setShowAuthModal(true)}
                        className="bg-amber-600 hover:bg-amber-700"
                      >
                        Upgrade to Premium
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Comparison */}
      <section className="py-8 bg-slate-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-6">
            <h2 className="text-3xl font-bold text-slate-800 mb-4">Free vs Premium</h2>
            <p className="text-slate-600 max-w-2xl mx-auto">
              All core features are completely free. Premium adds convenience and advanced capabilities.
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <Card>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-4 font-semibold text-slate-800">Feature</th>
                        <th className="text-center p-4 font-semibold text-slate-800">Free</th>
                        <th className="text-center p-4 font-semibold text-amber-700 bg-amber-50">Premium</th>
                      </tr>
                    </thead>
                    <tbody>
                      {comparisons.map((item, index) => (
                        <tr key={index} className="border-b last:border-b-0">
                          <td className="p-4 font-medium text-slate-700">{item.feature}</td>
                          <td className="p-4 text-center text-slate-600">{item.free}</td>
                          <td className="p-4 text-center text-amber-700 bg-amber-25">{item.premium}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>

            <div className="text-center mt-8">
              <Button size="lg" onClick={() => setShowAuthModal(true)} className="bg-amber-600 hover:bg-amber-700">
                {user ? "Upgrade to Premium - $4.99/month" : "Start Free Trial"}
              </Button>
              <p className="text-sm text-slate-500 mt-2">No credit card required for free features</p>
            </div>
          </div>
        </div>
      </section>

      {/* Technology Section */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          <div className="text-center mb-6">
            <h2 className="text-3xl font-bold text-slate-800 mb-4">Powered by Advanced AI</h2>
            <p className="text-slate-600 max-w-2xl mx-auto">
              Our platform combines cutting-edge artificial intelligence with deep biblical scholarship
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <Card>
              <CardHeader>
                <Brain className="w-12 h-12 text-blue-600 mb-4" />
                <CardTitle>Foundational AI Model</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600">
                  Advanced language understanding for natural query processing and intelligent content generation.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <Shield className="w-12 h-12 text-green-600 mb-4" />
                <CardTitle>Secure & Private</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600">
                  Your spiritual journey is personal. We use enterprise-grade security to protect your data.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <Zap className="w-12 h-12 text-amber-600 mb-4" />
                <CardTitle>Lightning Fast</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600">
                  Optimized for speed with intelligent caching and modern web technologies for instant results.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-8 bg-slate-800">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">Ready to Transform Your Bible Study?</h2>
          <p className="text-xl text-slate-300 mb-8 max-w-2xl mx-auto">
            Join thousands of believers who are deepening their faith with AI-powered Bible study tools.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" asChild className="bg-amber-600 hover:bg-amber-700">
              <Link href="/#features">Start Using Free Features</Link>
            </Button>
          </div>
        </div>
      </section>

      <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />
    </div>
  )
}
