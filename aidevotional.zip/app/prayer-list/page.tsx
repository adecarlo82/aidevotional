"use client"

import { useState } from "react"
import { SubscriptionGuard } from "@/components/subscription-guard"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Heart, Plus, Check, Trash2, BookOpen } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

interface PrayerRequest {
  id: string
  title: string
  description: string
  category: "personal" | "family" | "health" | "work" | "ministry" | "other"
  status: "active" | "answered" | "ongoing"
  scripture?: {
    reference: string
    text: string
  }
  createdAt: string
  answeredAt?: string
  notes: string[]
}

const categories = [
  { value: "personal", label: "Personal" },
  { value: "family", label: "Family" },
  { value: "health", label: "Health" },
  { value: "work", label: "Work" },
  { value: "ministry", label: "Ministry" },
  { value: "other", label: "Other" },
]

export default function PrayerListPage() {
  const [prayerRequests, setPrayerRequests] = useState<PrayerRequest[]>([])
  const [showAddForm, setShowAddForm] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [filterCategory, setFilterCategory] = useState<string>("all")
  const [filterStatus, setFilterStatus] = useState<string>("all")

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    category: "personal" as PrayerRequest["category"],
  })

  const addPrayerRequest = async () => {
    if (!formData.title.trim()) return

    const newRequest: PrayerRequest = {
      id: Date.now().toString(),
      title: formData.title,
      description: formData.description,
      category: formData.category,
      status: "active",
      createdAt: new Date().toISOString(),
      notes: [],
    }

    // Get relevant scripture for the prayer request
    try {
      const response = await fetch("/api/ai/prayer-scripture", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          topic: formData.title + " " + formData.description,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        if (data.scripture) {
          newRequest.scripture = data.scripture
        }
      }
    } catch (error) {
      console.error("Error fetching scripture:", error)
    }

    setPrayerRequests((prev) => [newRequest, ...prev])
    setFormData({ title: "", description: "", category: "personal" })
    setShowAddForm(false)
  }

  const markAsAnswered = (id: string) => {
    setPrayerRequests((prev) =>
      prev.map((request) =>
        request.id === id ? { ...request, status: "answered" as const, answeredAt: new Date().toISOString() } : request,
      ),
    )
  }

  const deletePrayerRequest = (id: string) => {
    setPrayerRequests((prev) => prev.filter((request) => request.id !== id))
  }

  const filteredRequests = prayerRequests.filter((request) => {
    const categoryMatch = filterCategory === "all" || request.category === filterCategory
    const statusMatch = filterStatus === "all" || request.status === filterStatus
    return categoryMatch && statusMatch
  })

  return (
    <SubscriptionGuard featureName="Prayer List">
      <div className="min-h-screen bg-white">
        {/* Header */}
        <header className="bg-white/80 backdrop-blur-sm border-b border-amber-200 sticky top-0 z-50">
          <div className="container mx-auto px-4 py-4 flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-3">
              <Image src="/logo.png" alt="AI Devotional Logo" width={80} height={80} className="object-contain" />
            </Link>
            <nav className="hidden md:flex items-center space-x-6">
              <Link href="/" className="text-slate-700 hover:text-amber-700 transition-colors">
                Home
              </Link>
              <Link href="/complete-devotional" className="text-slate-700 hover:text-amber-700 transition-colors">
                Complete Devotional
              </Link>
              <Link href="/prayer-list" className="text-amber-700 font-medium">
                Prayer List
              </Link>
              <Link href="/reading-plan" className="text-slate-700 hover:text-amber-700 transition-colors">
                Reading Plan
              </Link>
            </nav>
          </div>
        </header>

        {/* Main Content */}
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-4xl mx-auto">
            {/* Page Header */}
            <div className="text-center mb-8">
              <div className="flex items-center justify-center gap-3 mb-4">
                <Heart className="w-8 h-8 text-blue-600" />
                <h1 className="text-4xl font-bold text-slate-800">Prayer List</h1>
                <Badge className="bg-blue-600">Premium</Badge>
              </div>
              <p className="text-xl text-slate-600 max-w-2xl mx-auto">
                Organize your prayer requests with scripture-based encouragement and track God's faithfulness
              </p>
            </div>

            {/* Controls */}
            <div className="flex flex-col sm:flex-row gap-4 mb-6">
              <Button onClick={() => setShowAddForm(true)} className="bg-blue-600 hover:bg-blue-700">
                <Plus className="w-4 h-4 mr-2" />
                Add Prayer Request
              </Button>

              <div className="flex gap-2">
                <Select value={filterCategory} onValueChange={setFilterCategory}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {categories.map((cat) => (
                      <SelectItem key={cat.value} value={cat.value}>
                        {cat.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger className="w-32">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="answered">Answered</SelectItem>
                    <SelectItem value="ongoing">Ongoing</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Add Prayer Form */}
            {showAddForm && (
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle>Add New Prayer Request</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Prayer Request Title</label>
                    <Input
                      value={formData.title}
                      onChange={(e) => setFormData((prev) => ({ ...prev, title: e.target.value }))}
                      placeholder="e.g., Healing for mom, Job interview, Relationship guidance"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Description (Optional)</label>
                    <Textarea
                      value={formData.description}
                      onChange={(e) => setFormData((prev) => ({ ...prev, description: e.target.value }))}
                      placeholder="Additional details about your prayer request..."
                      rows={3}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Category</label>
                    <Select
                      value={formData.category}
                      onValueChange={(value) =>
                        setFormData((prev) => ({ ...prev, category: value as PrayerRequest["category"] }))
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((cat) => (
                          <SelectItem key={cat.value} value={cat.value}>
                            {cat.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex gap-2">
                    <Button onClick={addPrayerRequest} className="bg-blue-600 hover:bg-blue-700">
                      Add Prayer Request
                    </Button>
                    <Button variant="outline" onClick={() => setShowAddForm(false)}>
                      Cancel
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Prayer Requests List */}
            <div className="space-y-4">
              {filteredRequests.length === 0 ? (
                <Card>
                  <CardContent className="text-center py-12">
                    <Heart className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-gray-600 mb-2">No Prayer Requests</h3>
                    <p className="text-gray-500 mb-4">Start building your prayer list to track God's faithfulness</p>
                    <Button onClick={() => setShowAddForm(true)} className="bg-blue-600 hover:bg-blue-700">
                      Add Your First Prayer Request
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                filteredRequests.map((request) => (
                  <Card
                    key={request.id}
                    className={`${request.status === "answered" ? "bg-green-50 border-green-200" : ""}`}
                  >
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <CardTitle className="text-lg">{request.title}</CardTitle>
                            <Badge variant={request.status === "answered" ? "default" : "secondary"}>
                              {request.status}
                            </Badge>
                            <Badge variant="outline">
                              {categories.find((c) => c.value === request.category)?.label}
                            </Badge>
                          </div>
                          {request.description && <p className="text-slate-600 text-sm">{request.description}</p>}
                        </div>
                        <div className="flex gap-1">
                          {request.status === "active" && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => markAsAnswered(request.id)}
                              className="text-green-600 hover:text-green-700"
                            >
                              <Check className="w-4 h-4" />
                            </Button>
                          )}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => deletePrayerRequest(request.id)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      {request.scripture && (
                        <div className="bg-blue-50 border-l-4 border-blue-500 p-3 rounded-r-lg mb-3">
                          <div className="flex items-center gap-2 mb-1">
                            <BookOpen className="w-4 h-4 text-blue-600" />
                            <span className="font-medium text-blue-700">{request.scripture.reference}</span>
                          </div>
                          <p className="text-blue-700 text-sm italic">"{request.scripture.text}"</p>
                        </div>
                      )}
                      <div className="flex items-center justify-between text-xs text-slate-500">
                        <span>Added {new Date(request.createdAt).toLocaleDateString()}</span>
                        {request.answeredAt && (
                          <span className="text-green-600">
                            Answered {new Date(request.answeredAt).toLocaleDateString()}
                          </span>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>

            {/* Statistics */}
            {prayerRequests.length > 0 && (
              <Card className="mt-8">
                <CardHeader>
                  <CardTitle>Prayer Statistics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <div className="text-2xl font-bold text-blue-600">
                        {prayerRequests.filter((r) => r.status === "active").length}
                      </div>
                      <div className="text-sm text-slate-600">Active Prayers</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold text-green-600">
                        {prayerRequests.filter((r) => r.status === "answered").length}
                      </div>
                      <div className="text-sm text-slate-600">Answered Prayers</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold text-slate-600">{prayerRequests.length}</div>
                      <div className="text-sm text-slate-600">Total Requests</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </SubscriptionGuard>
  )
}
